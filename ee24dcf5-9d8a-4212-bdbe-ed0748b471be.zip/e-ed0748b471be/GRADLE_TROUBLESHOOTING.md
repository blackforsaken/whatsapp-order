
# Solución de Problemas de Gradle - Diagnóstico Rápido

## 🔍 Diagnóstico Automático

Ejecuta estos comandos para diagnosticar problemas:

### 1. Verificar Instalación de React Native

```bash
echo "Verificando React Native..."
if [ -d "node_modules/react-native" ]; then
    echo "✅ React Native está instalado"
    if [ -d "node_modules/react-native/react-native-gradle-plugin" ]; then
        echo "✅ react-native-gradle-plugin encontrado"
    else
        echo "❌ react-native-gradle-plugin NO encontrado"
        echo "Solución: npm install"
    fi
else
    echo "❌ React Native NO está instalado"
    echo "Solución: npm install"
fi
```

### 2. Verificar Versiones

```bash
echo "Versiones instaladas:"
echo "Node: $(node --version)"
echo "npm: $(npm --version)"
echo "Expo CLI: $(npx expo --version)"
echo "React Native: $(node -p "require('./node_modules/react-native/package.json').version")"
```

### 3. Limpiar Todo

```bash
echo "Limpiando proyecto..."
rm -rf android
rm -rf node_modules
rm -rf .expo
npm cache clean --force
echo "✅ Limpieza completa"
```

### 4. Reinstalar y Reconstruir

```bash
echo "Reinstalando dependencias..."
npm install
echo "✅ Dependencias instaladas"

echo "Ejecutando prebuild..."
npx expo prebuild -p android --clean
echo "✅ Prebuild completado"
```

## 🐛 Errores Comunes y Soluciones

### Error 1: "Could not find com.facebook.react:react-native-gradle-plugin"

**Causa:** El plugin de Gradle no puede encontrar el paquete de React Native.

**Solución:**
```bash
# Paso 1: Verificar que react-native esté instalado
npm list react-native

# Paso 2: Si no está, instalarlo
npm install react-native@0.81.4

# Paso 3: Limpiar y reconstruir
rm -rf android
npx expo prebuild -p android --clean
```

### Error 2: "Could not read script '/' as it is a directory"

**Causa:** Rutas incorrectas en settings.gradle.

**Solución:**
```bash
# El nuevo plugin withCustomGradle.js ya soluciona esto
# Solo necesitas ejecutar:
rm -rf android
npx expo prebuild -p android --clean
```

### Error 3: "Gradle daemon disappeared unexpectedly"

**Causa:** Problemas de memoria o configuración de Gradle.

**Solución:**
```bash
# Paso 1: Detener todos los daemons de Gradle
cd android 2>/dev/null && ./gradlew --stop; cd ..

# Paso 2: Limpiar caché de Gradle
rm -rf ~/.gradle/caches/

# Paso 3: Aumentar memoria de Gradle (crear/editar gradle.properties)
mkdir -p android
cat > android/gradle.properties << EOF
org.gradle.jvmargs=-Xmx4096m -XX:MaxMetaspaceSize=512m -XX:+HeapDumpOnOutOfMemoryError
org.gradle.daemon=true
org.gradle.parallel=true
org.gradle.configureondemand=true
android.useAndroidX=true
android.enableJetifier=true
EOF

# Paso 4: Reconstruir
npx expo prebuild -p android --clean
```

### Error 4: "Insecure protocols are not allowed"

**Causa:** Repositorios Maven usando HTTP en lugar de HTTPS.

**Solución:**
```bash
# El nuevo plugin withCustomGradle.js ya soluciona esto automáticamente
# Todos los repositorios ahora usan HTTPS
rm -rf android
npx expo prebuild -p android --clean
```

### Error 5: "Execution failed for task ':app:mergeReleaseResources'"

**Causa:** Recursos duplicados o conflictos.

**Solución:**
```bash
# Limpiar build
cd android
./gradlew clean
./gradlew --stop
cd ..

# Reconstruir
npx expo prebuild -p android --clean
```

## 🔧 Configuración Manual (Solo si el Plugin Falla)

Si por alguna razón el plugin automático no funciona, puedes configurar manualmente:

### android/settings.gradle

Agrega al final del archivo:

```groovy
// Resolución manual de react-native-gradle-plugin
def rnGradlePluginPath = null
try {
    def nodeCommand = ["node", "--print", "require.resolve('react-native/package.json')"]
    def rnPath = new File(nodeCommand.execute(null, rootDir).text.trim()).getParentFile()
    rnGradlePluginPath = new File(rnPath, "react-native-gradle-plugin")
    
    if (rnGradlePluginPath.exists()) {
        logger.quiet("Found react-native-gradle-plugin at: " + rnGradlePluginPath.absolutePath)
        includeBuild(rnGradlePluginPath)
    }
} catch (Exception e) {
    logger.error("Failed to locate react-native-gradle-plugin: " + e.getMessage())
}
```

### android/build.gradle

En la sección `buildscript { repositories {`:

```groovy
buildscript {
    repositories {
        google()
        mavenCentral()
        maven {
            url "https://repo1.maven.org/maven2/"
        }
    }
}

allprojects {
    repositories {
        google()
        mavenCentral()
        maven {
            url "https://repo1.maven.org/maven2/"
        }
    }
}
```

## 📊 Verificar que Todo Funciona

Después de aplicar las soluciones, verifica:

```bash
# 1. Verificar que el prebuild funciona
npx expo prebuild -p android --clean

# 2. Verificar que settings.gradle tiene la configuración correcta
cat android/settings.gradle | grep -A 10 "react-native-gradle-plugin"

# 3. Verificar que build.gradle tiene repositorios HTTPS
cat android/build.gradle | grep "https://repo1.maven.org"

# 4. Intentar build local
cd android
./gradlew assembleRelease --info
cd ..
```

## 🎯 Checklist de Verificación

Antes de intentar el build, verifica:

- [ ] `node_modules/react-native` existe
- [ ] `node_modules/react-native/react-native-gradle-plugin` existe
- [ ] `plugins/withCustomGradle.js` está actualizado
- [ ] `app.config.js` incluye el plugin `withCustomGradle`
- [ ] No hay carpeta `android/` antes de ejecutar prebuild
- [ ] Tienes suficiente espacio en disco (al menos 5GB libres)
- [ ] Tienes suficiente RAM (al menos 8GB recomendado)

## 🚨 Si Nada Funciona

Como último recurso:

```bash
# 1. Backup de tu código
cp -r . ../whatsapp-order-printer-backup

# 2. Limpiar TODO
rm -rf node_modules
rm -rf android
rm -rf ios
rm -rf .expo
rm -rf ~/.gradle/caches/
rm -rf ~/.expo/
rm package-lock.json

# 3. Reinstalar desde cero
npm install

# 4. Prebuild limpio
npx expo prebuild -p android --clean

# 5. Si aún falla, usar EAS Build (recomendado)
npm install -g eas-cli
eas login
eas build -p android --profile preview
```

## 📞 Obtener Ayuda

Si sigues teniendo problemas:

1. **Guarda los logs completos:**
   ```bash
   npx expo prebuild -p android --clean 2>&1 | tee prebuild.log
   ```

2. **Revisa el log** en busca de errores específicos

3. **Busca el error en:**
   - Documentación de Expo: https://docs.expo.dev
   - GitHub Issues de Expo: https://github.com/expo/expo/issues
   - Stack Overflow con tag `expo` y `react-native`

---

**Nota:** El plugin `withCustomGradle.js` actualizado debería resolver automáticamente todos estos problemas. Solo necesitas ejecutar `npx expo prebuild -p android --clean` después de actualizar los archivos.

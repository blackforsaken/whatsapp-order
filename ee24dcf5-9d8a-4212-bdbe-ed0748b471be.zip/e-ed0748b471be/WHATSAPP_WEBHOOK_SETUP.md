
# Guía de Configuración del Webhook de WhatsApp

## 🚨 Error: "No se pudo validar la URL de devolución de llamada o el token de verificación"

Este error ocurre cuando Meta no puede verificar tu webhook. Sigue estos pasos para solucionarlo:

## ✅ Pasos para Configurar el Webhook Correctamente

### 1. Verificar que la Edge Function esté desplegada

Primero, asegúrate de que la Edge Function `whatsapp-webhook` esté desplegada en Supabase:

1. Ve a [Supabase Dashboard](https://supabase.com/dashboard/project/stxrvyxkxclezgcijhio/functions)
2. Busca la función `whatsapp-webhook`
3. Si no existe o no está desplegada, despliégala usando el código proporcionado

### 2. Configurar el Token de Verificación en Supabase

**IMPORTANTE**: Debes configurar el token de verificación ANTES de intentar verificar el webhook en Meta.

1. Ve a [Supabase Dashboard → Settings → Edge Functions](https://supabase.com/dashboard/project/stxrvyxkxclezgcijhio/settings/functions)
2. En la sección "Secrets", agrega las siguientes variables:

```
WHATSAPP_VERIFY_TOKEN=tu_token_personalizado_aqui
WHATSAPP_ACCESS_TOKEN=tu_token_de_acceso_de_meta
WHATSAPP_PHONE_NUMBER_ID=tu_id_de_numero_de_telefono
```

**Nota sobre WHATSAPP_VERIFY_TOKEN**: 
- Puedes usar cualquier texto que quieras (ejemplo: `mi_token_secreto_123`)
- Debe ser el MISMO token que usarás en Meta
- Guárdalo en un lugar seguro, lo necesitarás en el siguiente paso

### 3. Configurar el Webhook en Meta for Developers

Ahora configura el webhook en Meta:

1. Ve a [Meta for Developers](https://developers.facebook.com/apps)
2. Selecciona tu aplicación
3. En el menú lateral, busca "WhatsApp" → "Configuration"
4. En la sección "Webhook", haz clic en "Edit" o "Configure"

### 4. Ingresar la URL del Webhook

En el campo "Callback URL", ingresa:

```
https://stxrvyxkxclezgcijhio.supabase.co/functions/v1/whatsapp-webhook
```

**Verifica que**:
- ✅ La URL comience con `https://` (no `http://`)
- ✅ No haya espacios al inicio o al final
- ✅ El ID del proyecto sea correcto: `stxrvyxkxclezgcijhio`
- ✅ La ruta termine en `/whatsapp-webhook`

### 5. Ingresar el Token de Verificación

En el campo "Verify Token", ingresa el MISMO token que configuraste en Supabase en el paso 2.

**Ejemplo**:
- Si en Supabase pusiste: `WHATSAPP_VERIFY_TOKEN=mi_token_secreto_123`
- En Meta debes poner: `mi_token_secreto_123`

### 6. Verificar el Webhook

1. Haz clic en "Verify and Save"
2. Meta enviará una solicitud GET a tu webhook
3. Si todo está correcto, verás un mensaje de éxito ✅

### 7. Suscribirse a Eventos

Después de verificar el webhook, debes suscribirte a los eventos:

1. En la misma página de configuración del webhook
2. Busca la sección "Webhook fields"
3. Suscríbete a los siguientes eventos:
   - ✅ `messages` (obligatorio)
   - ✅ `message_status` (opcional pero recomendado)

4. Haz clic en "Save" o "Subscribe"

## 🔍 Solución de Problemas

### Problema 1: "Token de verificación no coincide"

**Causa**: El token en Meta no coincide con el token en Supabase.

**Solución**:
1. Ve a Supabase → Settings → Edge Functions → Secrets
2. Verifica el valor de `WHATSAPP_VERIFY_TOKEN`
3. Copia ese valor exacto
4. Pégalo en Meta (sin espacios adicionales)
5. Intenta verificar nuevamente

### Problema 2: "No se puede conectar a la URL"

**Causa**: La Edge Function no está desplegada o la URL es incorrecta.

**Solución**:
1. Verifica que la URL sea exactamente:
   ```
   https://stxrvyxkxclezgcijhio.supabase.co/functions/v1/whatsapp-webhook
   ```
2. Ve a Supabase Dashboard → Edge Functions
3. Verifica que `whatsapp-webhook` esté en estado "Active"
4. Si no está desplegada, despliégala
5. Espera 1-2 minutos y vuelve a intentar

### Problema 3: "Error 403 Forbidden"

**Causa**: El token de verificación no está configurado en Supabase.

**Solución**:
1. Ve a Supabase → Settings → Edge Functions → Secrets
2. Asegúrate de que `WHATSAPP_VERIFY_TOKEN` esté configurado
3. El valor NO debe estar vacío
4. Guarda los cambios
5. Espera 30 segundos
6. Intenta verificar nuevamente en Meta

### Problema 4: "Error 500 Internal Server Error"

**Causa**: Error en la Edge Function.

**Solución**:
1. Ve a Supabase → Edge Functions → whatsapp-webhook → Logs
2. Busca errores en los logs
3. Verifica que todas las variables de entorno estén configuradas
4. Redespliega la Edge Function
5. Intenta verificar nuevamente

## 🧪 Probar la Verificación Manualmente

Puedes probar la verificación manualmente usando curl:

```bash
curl "https://stxrvyxkxclezgcijhio.supabase.co/functions/v1/whatsapp-webhook?hub.mode=subscribe&hub.verify_token=TU_TOKEN_AQUI&hub.challenge=TEST_CHALLENGE"
```

**Reemplaza**:
- `TU_TOKEN_AQUI` con tu token de verificación
- Deberías recibir como respuesta: `TEST_CHALLENGE`

Si recibes `TEST_CHALLENGE`, significa que tu webhook está funcionando correctamente.

Si recibes `Forbidden`, significa que el token no coincide.

## 📋 Checklist de Verificación

Antes de intentar verificar el webhook en Meta, asegúrate de que:

- [ ] La Edge Function `whatsapp-webhook` está desplegada en Supabase
- [ ] `WHATSAPP_VERIFY_TOKEN` está configurado en Supabase
- [ ] El token NO está vacío
- [ ] La URL del webhook es correcta
- [ ] La URL comienza con `https://`
- [ ] No hay espacios en la URL
- [ ] El token en Meta coincide EXACTAMENTE con el de Supabase
- [ ] Has esperado al menos 30 segundos después de configurar las variables

## ✅ Confirmación de Éxito

Sabrás que el webhook está configurado correctamente cuando:

1. ✅ Meta muestra "Webhook verified" o "Verificado"
2. ✅ Puedes suscribirte a eventos
3. ✅ En los logs de Supabase ves: "Webhook verified successfully"
4. ✅ Al enviar un mensaje de prueba, recibes confirmación

## 🎯 Próximos Pasos

Una vez que el webhook esté verificado:

1. Configura `WHATSAPP_ACCESS_TOKEN` en Supabase
2. Configura `WHATSAPP_PHONE_NUMBER_ID` en Supabase
3. Guarda la configuración en la app (pantalla de configuración de WhatsApp)
4. Envía un mensaje de prueba
5. Verifica que el pedido se cree en la app

## 📞 Soporte Adicional

Si después de seguir todos estos pasos aún tienes problemas:

1. Revisa los logs de la Edge Function en Supabase
2. Verifica que todas las variables de entorno estén configuradas
3. Intenta con un token de verificación diferente
4. Espera 5 minutos y vuelve a intentar
5. Contacta al soporte con los logs de error

## 🔗 Enlaces Útiles

- [Supabase Edge Functions](https://supabase.com/dashboard/project/stxrvyxkxclezgcijhio/functions)
- [Supabase Secrets](https://supabase.com/dashboard/project/stxrvyxkxclezgcijhio/settings/functions)
- [Meta for Developers](https://developers.facebook.com/apps)
- [WhatsApp API Docs](https://developers.facebook.com/docs/whatsapp/cloud-api/guides/set-up-webhooks)

## 💡 Consejos Importantes

1. **El token de verificación es sensible a mayúsculas/minúsculas**: `MiToken` ≠ `mitoken`
2. **No uses espacios en el token**: `mi token` ❌ → `mi_token` ✅
3. **Guarda el token en un lugar seguro**: Lo necesitarás si reconfiguras el webhook
4. **Espera después de cambios**: Los cambios en variables de entorno pueden tardar 30-60 segundos
5. **Revisa los logs**: Los logs de Supabase te dirán exactamente qué está fallando

## 🎉 ¡Listo!

Si seguiste todos estos pasos, tu webhook debería estar verificado y funcionando correctamente. ¡Ahora puedes empezar a recibir pedidos por WhatsApp! 🚀


# Gradle Dependency Resolution Fix

## Problem
The build was failing with the error:
```
Could not find com.facebook.react:react-native-gradle-plugin:.
Required by:
    root project : > project :expo-module-gradle-plugin
```

This error occurred because the `react-native-gradle-plugin` was not being properly resolved by Gradle.

## Root Cause
The issue was in the `android/settings.gradle` file where:
1. The autolinking scripts were wrapped in try-catch blocks that silently failed
2. The `react-native-gradle-plugin` was being included conditionally with error handling that prevented proper resolution
3. The `expo-module-gradle-plugin` couldn't find the required dependency

## Solution Applied

### 1. Fixed `android/settings.gradle`
- Removed error handling wrappers that were hiding failures
- Applied autolinking scripts directly without try-catch blocks
- Properly included the `react-native-gradle-plugin` as a composite build
- Added `pluginManagement` block for proper plugin resolution

### 2. Simplified `android/build.gradle`
- Removed insecure jcenter repository reference
- Kept only essential repositories (google, mavenCentral)
- Ensured React Native and JSC repositories are properly configured

### 3. Updated `android/gradle.properties`
- Added `org.gradle.configuration-cache=false` to avoid issues with Expo autolinking
- Enabled Gradle caching and daemon for better performance
- Kept all existing Expo and React Native configurations

### 4. Simplified `plugins/withCustomGradle.js`
- Removed problematic settings.gradle modifications
- Kept only essential build.gradle repository configuration

## What Changed

### Before
The settings.gradle file had complex error handling that prevented proper dependency resolution:
```groovy
try {
    def rnGradlePluginPackageJson = ["node", "--print", "require.resolve('react-native-gradle-plugin/package.json')"].execute(null, rootDir).text.trim()
    if (rnGradlePluginPackageJson && !rnGradlePluginPackageJson.isEmpty() && rnGradlePluginPackageJson != "/" && !rnGradlePluginPackageJson.startsWith("Error")) {
        // ... complex logic
    }
} catch (Exception e) {
    logger.warn("Could not include react-native-gradle-plugin: ${e.message}")
}
```

### After
Direct and straightforward dependency resolution:
```groovy
// Include React Native Gradle Plugin
includeBuild(new File(["node", "--print", "require.resolve('react-native-gradle-plugin/package.json')"].execute(null, rootDir).text.trim()).getParentFile())
```

## Testing
After applying these changes:
1. Clean the build: `cd android && ./gradlew clean`
2. Rebuild: `cd .. && npx expo run:android`

## Why This Works
1. **Direct Resolution**: The plugin is now directly included without conditional logic
2. **Proper Plugin Management**: The `pluginManagement` block ensures Gradle can find all necessary plugins
3. **No Silent Failures**: Removed try-catch blocks that were hiding real errors
4. **Correct Repository Order**: Repositories are configured in the right order for dependency resolution

## Additional Notes
- The Gradle version (8.14.3) is compatible with React Native 0.81.4 and Expo SDK 54
- Configuration cache is disabled to prevent issues with Expo's autolinking
- All Expo and React Native features remain functional (new architecture, Hermes, etc.)

## If Issues Persist
If you still encounter build issues:

1. **Clear Gradle cache**:
   ```bash
   cd android
   ./gradlew clean
   rm -rf .gradle
   cd ..
   ```

2. **Clear node_modules and reinstall**:
   ```bash
   rm -rf node_modules
   npm install
   ```

3. **Rebuild native code**:
   ```bash
   npx expo prebuild --clean
   npx expo run:android
   ```

4. **Check for conflicting dependencies**:
   ```bash
   cd android
   ./gradlew app:dependencies
   ```

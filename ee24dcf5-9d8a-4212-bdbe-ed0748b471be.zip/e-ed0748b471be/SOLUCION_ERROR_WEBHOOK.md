
# 🔧 Solución al Error de Validación del Webhook de Meta

## 📌 El Problema

Estás recibiendo este error de Meta:
> "No se pudo validar la URL de devolución de llamada o el token de verificación. Verifica la información proporcionada o vuelve a intentarlo más tarde."

## ✅ La Solución (Paso a Paso)

### Paso 1: Desplegar la Edge Function

La Edge Function `whatsapp-webhook` debe estar desplegada en Supabase. He creado el código completo en:
```
supabase/functions/whatsapp-webhook/index.ts
```

**Cómo desplegarla**:
1. Ve a [Supabase Dashboard → Edge Functions](https://supabase.com/dashboard/project/stxrvyxkxclezgcijhio/functions)
2. Busca `whatsapp-webhook`
3. Si no existe, créala con el código proporcionado
4. Si existe, actualízala con el nuevo código
5. Asegúrate de que el estado sea "Active"

### Paso 2: Configurar el Token de Verificación

**IMPORTANTE**: Debes hacer esto ANTES de intentar verificar en Meta.

1. Ve a [Supabase → Settings → Edge Functions](https://supabase.com/dashboard/project/stxrvyxkxclezgcijhio/settings/functions)
2. En la sección "Secrets", agrega:

```
WHATSAPP_VERIFY_TOKEN=tu_token_personalizado
```

**Ejemplo**:
```
WHATSAPP_VERIFY_TOKEN=mi_token_secreto_2024
```

**Notas**:
- Puedes usar cualquier texto que quieras
- NO uses espacios
- Guárdalo, lo necesitarás para Meta
- Debe ser el MISMO en Supabase y en Meta

### Paso 3: Probar el Webhook Manualmente

Antes de configurar en Meta, prueba que funcione:

Abre tu navegador y ve a (reemplaza `TU_TOKEN` con tu token real):
```
https://stxrvyxkxclezgcijhio.supabase.co/functions/v1/whatsapp-webhook?hub.mode=subscribe&hub.verify_token=TU_TOKEN&hub.challenge=TEST123
```

**Resultado esperado**: Deberías ver `TEST123` en la página.

Si ves `TEST123`, ¡tu webhook está funcionando! Continúa al Paso 4.

Si ves `Forbidden`, el token no coincide. Verifica el token en Supabase.

### Paso 4: Configurar en Meta for Developers

Ahora sí, configura el webhook en Meta:

1. Ve a [Meta for Developers](https://developers.facebook.com/apps)
2. Selecciona tu aplicación
3. En el menú lateral: WhatsApp → Configuration
4. En la sección "Webhook", haz clic en "Edit"

**Ingresa estos valores**:

**Callback URL** (copiar exactamente):
```
https://stxrvyxkxclezgcijhio.supabase.co/functions/v1/whatsapp-webhook
```

**Verify Token**:
- Ingresa el MISMO token que configuraste en Supabase
- Debe coincidir EXACTAMENTE (mayúsculas/minúsculas)
- Sin espacios al inicio o al final

5. Haz clic en "Verify and Save"
6. Deberías ver un mensaje de éxito ✅

### Paso 5: Suscribirse a Eventos

Después de verificar:

1. En la misma página, busca "Webhook fields"
2. Marca estas casillas:
   - ✅ `messages`
   - ✅ `message_status`
3. Haz clic en "Subscribe"

### Paso 6: Configurar Tokens de Acceso

Para que el sistema funcione completamente, también necesitas:

1. En Meta for Developers → WhatsApp → Configuration
2. Copia el "Access Token"
3. Copia el "Phone Number ID"

4. Ve a [Supabase → Settings → Edge Functions](https://supabase.com/dashboard/project/stxrvyxkxclezgcijhio/settings/functions)
5. Agrega:

```
WHATSAPP_ACCESS_TOKEN=tu_token_de_acceso
WHATSAPP_PHONE_NUMBER_ID=tu_phone_number_id
```

6. En la app, ve a Perfil → Configuración de WhatsApp
7. Ingresa los mismos valores
8. Haz clic en "Guardar Configuración"

### Paso 7: Probar el Sistema Completo

Envía un mensaje de prueba desde tu teléfono al número de WhatsApp Business:

```
2 pizzas $10
1 refresco $2
```

**Deberías**:
- ✅ Recibir confirmación en WhatsApp (en menos de 5 segundos)
- ✅ Ver el pedido en la app
- ✅ Recibir una notificación push

## 🔍 Verificación Rápida

Usa este checklist para verificar que todo esté bien:

- [ ] Edge Function `whatsapp-webhook` desplegada
- [ ] `WHATSAPP_VERIFY_TOKEN` configurado en Supabase
- [ ] Prueba manual del webhook exitosa (ves `TEST123`)
- [ ] Webhook verificado en Meta (mensaje de éxito)
- [ ] Eventos suscritos (`messages` y `message_status`)
- [ ] `WHATSAPP_ACCESS_TOKEN` configurado
- [ ] `WHATSAPP_PHONE_NUMBER_ID` configurado
- [ ] Configuración guardada en la app
- [ ] Mensaje de prueba enviado
- [ ] Confirmación recibida en WhatsApp
- [ ] Pedido aparece en la app

## ❌ Problemas Comunes

### "Forbidden" al probar manualmente
- **Causa**: Token no coincide
- **Solución**: Verifica que el token en la URL sea exactamente el mismo que en Supabase

### "404 Not Found"
- **Causa**: Edge Function no desplegada
- **Solución**: Despliega la Edge Function

### Meta dice "Could not validate"
- **Causa**: URL incorrecta o token no coincide
- **Solución**: 
  1. Verifica la URL exacta
  2. Verifica que el token coincida
  3. Espera 30 segundos después de configurar variables
  4. Intenta nuevamente

### Webhook verifica pero no recibe mensajes
- **Causa**: No estás suscrito a eventos
- **Solución**: Suscríbete a `messages` en Meta

### No crea pedidos
- **Causa**: Formato de mensaje incorrecto
- **Solución**: Usa formato simple: `2 pizzas $10`

### No envía confirmación
- **Causa**: Tokens de acceso no configurados
- **Solución**: Configura `WHATSAPP_ACCESS_TOKEN` y `WHATSAPP_PHONE_NUMBER_ID`

## 📚 Documentos de Ayuda

He creado varios documentos para ayudarte:

1. **WHATSAPP_WEBHOOK_SETUP.md**: Guía completa de configuración
2. **WHATSAPP_VERIFICATION_CHECKLIST.md**: Checklist detallado
3. **WHATSAPP_QUICK_TEST.md**: Pruebas rápidas
4. **Este documento**: Solución al error específico

## 🎯 Resumen Ultra-Rápido

1. Despliega Edge Function
2. Configura `WHATSAPP_VERIFY_TOKEN` en Supabase
3. Prueba en navegador (debes ver `TEST123`)
4. Configura webhook en Meta con la misma URL y token
5. Verifica en Meta
6. Suscríbete a eventos
7. Configura tokens de acceso
8. Prueba enviando mensaje

## 📞 ¿Necesitas Más Ayuda?

Si después de seguir estos pasos aún tienes problemas:

1. Revisa los logs en: https://supabase.com/dashboard/project/stxrvyxkxclezgcijhio/functions/whatsapp-webhook/logs
2. Busca mensajes de error
3. Verifica que todas las variables estén configuradas
4. Intenta con un token diferente
5. Espera 5 minutos y vuelve a intentar

## ✅ Confirmación de Éxito

Sabrás que todo funciona cuando:
- ✅ Meta muestra "Webhook verified"
- ✅ Puedes suscribirte a eventos
- ✅ Envías mensaje y recibes confirmación
- ✅ El pedido aparece en la app
- ✅ Recibes notificación push

¡Buena suerte! 🚀

---

**Nota**: El webhook URL es:
```
https://stxrvyxkxclezgcijhio.supabase.co/functions/v1/whatsapp-webhook
```

**No olvides**: El token de verificación debe ser EXACTAMENTE el mismo en Supabase y en Meta.


import { createClient } from '@supabase/supabase-js';
import { Database } from '@/types/database.types';
import Constants from 'expo-constants';

// Production Supabase configuration
const supabaseUrl = 'https://stxrvyxkxclezgcijhio.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InN0eHJ2eXhreGNsZXpnY2lqaGlvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjAzNTg3NTksImV4cCI6MjA3NTkzNDc1OX0.sUEXLtt-wqYFt7hfP6gekmyNLGmNyqmW9ppdlvNVq1s';

// Get environment from build configuration
const APP_ENV = Constants.expoConfig?.extra?.APP_ENV || 'production';
const isDevelopment = APP_ENV === 'development';

// Configure Supabase client with production-ready settings
export const supabase = createClient<Database>(supabaseUrl, supabaseAnonKey, {
  auth: {
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: false,
    storage: undefined, // Use default AsyncStorage
    storageKey: 'pedidos-whatsapp-auth',
    flowType: 'pkce', // Use PKCE flow for better security
  },
  global: {
    headers: {
      'x-app-version': Constants.expoConfig?.version || '1.0.0',
      'x-app-platform': Constants.platform?.ios ? 'ios' : 'android',
    },
  },
  db: {
    schema: 'public',
  },
  realtime: {
    params: {
      eventsPerSecond: 10, // Rate limit for production
    },
  },
});

// Log configuration in development only
if (isDevelopment) {
  console.log('Supabase initialized:', {
    url: supabaseUrl,
    environment: APP_ENV,
    version: Constants.expoConfig?.version,
  });
}

// Export environment check
export const isProduction = APP_ENV === 'production';
export const isPreview = APP_ENV === 'preview';
export const isDev = isDevelopment;

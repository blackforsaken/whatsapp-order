
# ⚡ Quick Build Reference Card

## 🎯 Build Rápido (Elige Uno)

### EAS Build (Recomendado) ⭐
```bash
eas build -p android --profile preview
```

### Build Local
```bash
npx expo prebuild -p android --clean
cd android && ./gradlew assembleRelease && cd ..
```

---

## 🔧 Solución Rápida de Errores

### Error de Gradle
```bash
rm -rf android && npx expo prebuild -p android --clean
```

### Error de Dependencias
```bash
rm -rf node_modules && npm install
```

### Error de Daemon
```bash
cd android && ./gradlew --stop && cd .. && rm -rf android
```

---

## 📱 Instalar APK

### Con ADB
```bash
adb install android/app/build/outputs/apk/release/app-release.apk
```

### Ubicación del APK
```
android/app/build/outputs/apk/release/app-release.apk
```

---

## ✅ Verificación Rápida

```bash
# Verificar plugin aplicado
cat android/settings.gradle | grep "react-native-gradle-plugin"

# Verificar repositorios
cat android/build.gradle | grep "mavenCentral"
```

---

## 📊 Info del Build

- **Tiempo:** 10-15 minutos
- **Tamaño APK:** 30-45 MB
- **Android Mínimo:** 6.0 (API 23)
- **Android Target:** 14 (API 34)

---

## 🆘 Ayuda Rápida

**Documentación completa:**
- `BUILD_READY_CHECKLIST.md`
- `EJECUTAR_BUILD.md`
- `ESTADO_ACTUAL_BUILD.md`

**Estado:** ✅ LISTO PARA BUILD

---

## 🚀 Comando Todo-en-Uno

```bash
rm -rf android && npx expo prebuild -p android --clean && cd android && ./gradlew assembleRelease && cd .. && echo "✅ APK listo!"
```

---

**¡Listo para construir!** 🎉

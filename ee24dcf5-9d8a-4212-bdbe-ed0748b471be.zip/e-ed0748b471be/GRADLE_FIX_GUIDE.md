
# Gradle Build Error Fix - Insecure Repository

## Problem
The build was failing with the following error:
```
Using insecure protocols with repositories, without explicit opt-in, is unsupported.
Switch Maven repository 'BintrayJCenter(http://jcenter.bintray.com/)' to redirect to a secure protocol (like HTTPS)
```

This error occurs because the `react-native-bluetooth-escpos-printer` library uses the deprecated JCenter repository with an insecure HTTP protocol, which is no longer supported by Gradle 8.14.3 without explicit configuration.

## Solution Implemented

### 1. Custom Gradle Configuration Files
Created three key Android Gradle configuration files:

- **`android/build.gradle`**: Top-level build configuration that:
  - Uses HTTPS for JCenter: `https://jcenter.bintray.com/`
  - Adds Maven Central as a fallback repository
  - Configures proper repository order for dependency resolution

- **`android/gradle.properties`**: Project-wide Gradle settings including:
  - Memory settings for the Gradle daemon
  - AndroidX and Jetifier configuration
  - Proguard and resource shrinking settings
  - New Architecture and Hermes engine flags

- **`android/settings.gradle`**: Module configuration that:
  - Sets up Expo autolinking
  - Configures React Native native modules
  - Includes the app module

### 2. Custom Expo Config Plugin
Created `plugins/withCustomGradle.js` to automatically inject the correct repository configuration during the prebuild process. This ensures that even after running `expo prebuild`, the correct Gradle configuration is maintained.

### 3. App Configuration
Updated `app.json` to maintain all existing configuration while ensuring compatibility with the new Gradle setup.

## How It Works

1. **HTTPS Migration**: Changed JCenter from HTTP to HTTPS protocol
2. **Fallback Repositories**: Added Maven Central as a fallback for dependencies that were on JCenter
3. **Repository Order**: Configured repositories in the correct order:
   - React Native local repositories
   - Google Maven
   - Maven Central
   - JCenter (HTTPS)
   - Maven Central fallback

## Building the APK

After these changes, you can build your APK using:

```bash
# Clean any existing Android build
rm -rf android/

# Run prebuild to generate Android project
npx expo prebuild -p android --clean

# Build the APK
cd android && ./gradlew assembleRelease
```

The APK will be generated at:
```
android/app/build/outputs/apk/release/app-release.apk
```

## Why This Fix Works

1. **Secure Protocol**: Uses HTTPS instead of HTTP for JCenter, satisfying Gradle's security requirements
2. **Backward Compatibility**: Maintains support for legacy dependencies that still reference JCenter
3. **Future-Proof**: Includes Maven Central as the primary repository, which is the recommended replacement for JCenter
4. **Expo Integration**: The custom config plugin ensures the fix persists across prebuilds

## Alternative Solutions Considered

### Option 1: Allow Insecure Protocol (NOT RECOMMENDED)
```gradle
maven {
    url "http://jcenter.bintray.com/"
    allowInsecureProtocol = true
}
```
This was rejected because it compromises security and is not recommended for production builds.

### Option 2: Replace the Library
Consider replacing `react-native-bluetooth-escpos-printer` with a more actively maintained alternative. However, this would require significant code changes.

## Troubleshooting

If you still encounter issues:

1. **Clean the build**:
   ```bash
   cd android && ./gradlew clean
   ```

2. **Clear Gradle cache**:
   ```bash
   rm -rf ~/.gradle/caches/
   ```

3. **Verify repository URLs**: Ensure all repository URLs in `android/build.gradle` use HTTPS

4. **Check dependency versions**: Some very old dependencies might not be available on Maven Central

## Additional Notes

- JCenter was officially deprecated in 2021 and is now read-only
- Most libraries have migrated to Maven Central
- The HTTPS version of JCenter still works but is not receiving updates
- Consider migrating away from libraries that still depend on JCenter when possible

## References

- [Gradle Documentation on Repository Security](https://docs.gradle.org/current/userguide/declaring_repositories.html#sec:handling_credentials)
- [JCenter Deprecation Announcement](https://jfrog.com/blog/into-the-sunset-bintray-jcenter-gocenter-and-chartcenter/)
- [Expo Build Properties Plugin](https://docs.expo.dev/versions/latest/sdk/build-properties/)

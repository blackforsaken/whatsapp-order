
import React, { useEffect, useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Pressable,
  Animated,
  Platform,
} from 'react-native';
import { IconSymbol } from '@/components/IconSymbol';
import { colors } from '@/styles/commonStyles';
import { InAppNotification, InAppNotificationService } from '@/services/InAppNotificationService';
import { useRouter } from 'expo-router';

export function NotificationBanner() {
  const router = useRouter();
  const [notification, setNotification] = useState<InAppNotification | null>(null);
  const [slideAnim] = useState(new Animated.Value(-100));

  const showBanner = useCallback(() => {
    Animated.sequence([
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 300,
        useNativeDriver: true,
      }),
      Animated.delay(4000),
      Animated.timing(slideAnim, {
        toValue: -100,
        duration: 300,
        useNativeDriver: true,
      }),
    ]).start(() => {
      setNotification(null);
    });
  }, [slideAnim]);

  useEffect(() => {
    const unsubscribe = InAppNotificationService.addListener((newNotification) => {
      setNotification(newNotification);
      showBanner();
    });

    return unsubscribe;
  }, [showBanner]);

  const handlePress = () => {
    if (notification?.orderId) {
      router.push(`/order/${notification.orderId}`);
    }
    hideBanner();
  };

  const hideBanner = () => {
    Animated.timing(slideAnim, {
      toValue: -100,
      duration: 200,
      useNativeDriver: true,
    }).start(() => {
      setNotification(null);
    });
  };

  if (!notification) {
    return null;
  }

  const getIcon = () => {
    switch (notification.type) {
      case 'new_order':
        return { name: 'cart.fill' as const, color: colors.success };
      case 'order_status_change':
        return { name: 'arrow.triangle.2.circlepath' as const, color: colors.info };
      case 'system':
        return { name: 'info.circle.fill' as const, color: colors.warning };
      default:
        return { name: 'bell.fill' as const, color: colors.primary };
    }
  };

  const icon = getIcon();

  return (
    <Animated.View
      style={[
        styles.container,
        {
          transform: [{ translateY: slideAnim }],
        },
      ]}
    >
      <Pressable
        style={({ pressed }) => [
          styles.banner,
          pressed && styles.bannerPressed,
        ]}
        onPress={handlePress}
      >
        <View style={[styles.iconContainer, { backgroundColor: icon.color + '20' }]}>
          <IconSymbol name={icon.name} size={24} color={icon.color} />
        </View>
        <View style={styles.content}>
          <Text style={styles.title} numberOfLines={1}>
            {notification.title}
          </Text>
          <Text style={styles.message} numberOfLines={2}>
            {notification.message}
          </Text>
        </View>
        <Pressable style={styles.closeButton} onPress={hideBanner}>
          <IconSymbol name="xmark" size={18} color={colors.textSecondary} />
        </Pressable>
      </Pressable>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    top: Platform.OS === 'ios' ? 50 : 10,
    left: 16,
    right: 16,
    zIndex: 9999,
  },
  banner: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 12,
    gap: 12,
    boxShadow: '0px 4px 12px rgba(0, 0, 0, 0.15)',
    elevation: 8,
    borderWidth: 1,
    borderColor: colors.border,
  },
  bannerPressed: {
    opacity: 0.8,
  },
  iconContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  content: {
    flex: 1,
  },
  title: {
    fontSize: 14,
    fontWeight: '700',
    color: colors.text,
    marginBottom: 2,
  },
  message: {
    fontSize: 13,
    color: colors.textSecondary,
    lineHeight: 18,
  },
  closeButton: {
    padding: 4,
  },
});

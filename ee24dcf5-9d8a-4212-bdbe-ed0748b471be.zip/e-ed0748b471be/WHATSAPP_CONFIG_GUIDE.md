
# Guía de Configuración de WhatsApp Business

Esta guía te ayudará a configurar WhatsApp Business API para recibir pedidos automáticamente en tu aplicación.

## 📋 Requisitos Previos

1. Una cuenta de Meta for Developers
2. Una aplicación de WhatsApp Business configurada
3. Un número de teléfono de WhatsApp Business
4. Rol de **Administrador** en la aplicación

## 🚀 Configuración Paso a Paso

### 1. Obtener Credenciales de WhatsApp

#### A. Acceder a Meta for Developers
1. Ve a [Meta for Developers](https://developers.facebook.com/)
2. Inicia sesión con tu cuenta de Facebook
3. Selecciona tu aplicación de WhatsApp Business

#### B. Obtener el Token de Acceso
1. En el panel de tu aplicación, ve a **WhatsApp > Inicio rápido**
2. Copia el **Token de acceso temporal** (válido por 24 horas)
3. Para un token permanente:
   - Ve a **Configuración > Básica**
   - Genera un **Token de acceso del sistema**
   - Guárdalo en un lugar seguro

#### C. Obtener el ID del Número de Teléfono
1. En **WhatsApp > Inicio rápido**
2. Busca **ID del número de teléfono**
3. Copia el número (formato: 123456789012345)

#### D. Crear un Token de Verificación
1. Crea una cadena de texto segura y única
2. Ejemplo: `mi_token_secreto_2024`
3. Este token lo usarás para verificar el webhook

### 2. Configurar en la Aplicación

#### A. Acceder a la Configuración
1. Abre la aplicación
2. Ve a **Perfil** (última pestaña)
3. Toca **WhatsApp Business** (solo visible para administradores)

#### B. Completar el Formulario
1. **Token de Verificación**: Ingresa el token que creaste
2. **Token de Acceso**: Pega el token de acceso de WhatsApp
3. **ID del Número de Teléfono**: Pega el ID del número
4. **URL del Webhook**: Ya está configurada automáticamente
5. Toca **Guardar Configuración**

### 3. Configurar el Webhook en Meta

#### A. Configurar la URL del Webhook
1. En Meta for Developers, ve a **WhatsApp > Configuración**
2. En la sección **Webhook**, haz clic en **Configurar**
3. Ingresa la URL del webhook:
   ```
   https://stxrvyxkxclezgcijhio.supabase.co/functions/v1/whatsapp-webhook
   ```
4. Ingresa el **Token de verificación** que creaste
5. Haz clic en **Verificar y guardar**

#### B. Suscribirse a Eventos
1. En la misma sección de Webhook
2. Haz clic en **Administrar**
3. Suscríbete a los siguientes campos:
   - ✅ **messages** (obligatorio)
   - ✅ **message_status** (opcional, para seguimiento)
4. Guarda los cambios

## 📱 Formato de Pedidos por WhatsApp

Los clientes deben enviar sus pedidos en el siguiente formato:

```
Nombre: Juan Pérez
Dirección: Calle Principal 123, Depto 4B
Pedido:
- 2 Tomates
- 1 Lechuga
- 3 Papas
Notas: Sin cebolla, por favor
```

### Reglas del Formato

- **Nombre**: Obligatorio. Si no se proporciona, se usa "Cliente [últimos 4 dígitos del teléfono]"
- **Dirección**: Obligatorio. Si no se proporciona, se usa "No especificada"
- **Pedido**: Obligatorio. Debe tener al menos un producto
  - Formato: `- [cantidad] [nombre del producto]`
  - También acepta: `- [nombre del producto] x [cantidad]`
  - Si no se especifica cantidad, se asume 1
- **Notas**: Opcional. Cualquier información adicional

### Ejemplos Válidos

**Ejemplo 1: Formato completo**
```
Nombre: María González
Dirección: Av. Libertador 456
Pedido:
- 2 Lechugas
- 1 Tomate
- 5 Zanahorias
Notas: Entregar después de las 6 PM
```

**Ejemplo 2: Sin cantidad específica**
```
Nombre: Pedro Sánchez
Dirección: Calle 7 #89
Pedido:
- Lechuga
- Tomate
- Cebolla
```

**Ejemplo 3: Formato alternativo de cantidad**
```
Nombre: Ana López
Dirección: Pasaje Los Olivos 12
Pedido:
- Papas x 3
- Tomates x 2
- Lechuga x 1
```

## ✅ Verificar la Configuración

### 1. Probar el Webhook
1. Envía un mensaje de prueba al número de WhatsApp Business
2. Usa el formato de pedido correcto
3. Deberías recibir una confirmación automática

### 2. Verificar en la Aplicación
1. Ve a la pantalla de **Pedidos**
2. El nuevo pedido debería aparecer con estado **Pendiente**
3. El pedido tendrá el número de orden con prefijo `WA-`

### 3. Mensaje de Confirmación
El cliente recibirá un mensaje como:
```
✅ ¡Pedido recibido!

Pedido #WA-12345
Nombre: Juan PéPerfect! Now let me create a comprehensive documentation file for the WhatsApp configuration:

<write file="WHATSAPP_CONFIG_GUIDE.md">
# Guía de Configuración de WhatsApp Business

Esta guía te ayudará a configurar WhatsApp Business API para recibir pedidos automáticamente en tu aplicación.

## 📋 Requisitos Previos

- Cuenta de Meta for Developers
- Aplicación de WhatsApp Business configurada
- Número de teléfono de WhatsApp Business verificado
- Rol de **Administrador** en la aplicación

## 🔧 Configuración Paso a Paso

### 1. Obtener Credenciales de WhatsApp

1. Ve a [Meta for Developers](https://developers.facebook.com/)
2. Accede a tu aplicación de WhatsApp Business
3. En el panel de WhatsApp, encontrarás:
   - **Token de Acceso Temporal** (Access Token)
   - **ID del Número de Teléfono** (Phone Number ID)

> **Nota:** El token de acceso temporal expira después de 24 horas. Para producción, debes generar un token permanente.

### 2. Crear Token de Verificación

El token de verificación es una cadena personalizada que tú defines. Debe ser:
- Único y seguro
- Difícil de adivinar
- Al menos 20 caracteres
- Puede contener letras, números y símbolos

**Ejemplo:** `mi_token_super_secreto_2024_xyz123`

### 3. Configurar en la Aplicación

1. Abre la aplicación y ve a **Perfil**
2. Toca **WhatsApp Business** (solo visible para administradores)
3. Completa el formulario:
   - **Token de Verificación:** El token que creaste
   - **Token de Acceso:** El token de Meta for Developers
   - **ID del Número de Teléfono:** El ID de tu número de WhatsApp Business
4. Toca **Guardar Configuración**

### 4. Configurar Webhook en Meta for Developers

1. En Meta for Developers, ve a **WhatsApp > Configuración**
2. En la sección **Webhook**, haz clic en **Configurar**
3. Ingresa la URL del webhook:
   ```
   https://stxrvyxkxclezgcijhio.supabase.co/functions/v1/whatsapp-webhook
   ```
4. Ingresa el **Token de Verificación** que creaste
5. Haz clic en **Verificar y Guardar**

### 5. Suscribirse a Eventos

1. En la configuración del webhook, busca **Campos de Webhook**
2. Suscríbete a los siguientes eventos:
   - ✅ **messages** (Mensajes)
   - ✅ **message_status** (Estado de mensajes)

## 📱 Formato de Pedidos por WhatsApp

Los clientes deben enviar sus pedidos en el siguiente formato:

```
Nombre: Juan Pérez
Dirección: Calle Principal 123, Depto 4B
Pedido:
- 2 Tomates
- 1 Lechuga
- 3 Papas
Notas: Sin cebolla por favor
```

### Reglas de Formato

- **Nombre:** Obligatorio. Si no se proporciona, se usa "Cliente [últimos 4 dígitos del teléfono]"
- **Dirección:** Obligatorio. Si no se proporciona, se usa "No especificada"
- **Pedido:** Obligatorio. Debe tener al menos un producto
  - Formato: `- [cantidad] [nombre del producto]`
  - También acepta: `- [nombre del producto] x [cantidad]`
  - Si no se especifica cantidad, se asume 1
- **Notas:** Opcional. Cualquier información adicional

### Ejemplos Válidos

**Ejemplo 1 - Formato completo:**
```
Nombre: María González
Dirección: Av. Libertador 456
Pedido:
- 2 Tomates
- 1 Lechuga
- 3 Papas
Notas: Entregar antes de las 6pm
```

**Ejemplo 2 - Sin cantidad específica:**
```
Nombre: Pedro López
Dirección: Calle 7 #123
Pedido:
- Tomates
- Lechuga
- Papas
```

**Ejemplo 3 - Formato alternativo:**
```
Nombre: Ana Silva
Dirección: Pasaje Los Olivos 89
Pedido:
- Tomates x 2
- Lechuga x 1
- Papas x 3
```

## ✅ Verificar Configuración

### Prueba de Webhook

1. En Meta for Developers, ve a **WhatsApp > Configuración > Webhook**
2. Haz clic en **Probar** junto a tu webhook
3. Deberías ver un mensaje de éxito

### Prueba de Pedido

1. Envía un mensaje de prueba al número de WhatsApp Business
2. Usa el formato de pedido especificado arriba
3. Deberías recibir:
   - Confirmación automática por WhatsApp
   - El pedido aparecerá en la aplicación con estado "Pendiente"
   - Notificación push a todos los usuarios activos

## 🔒 Seguridad

### Tokens de Acceso

- **Nunca compartas** tus tokens de acceso
- Los tokens se almacenan de forma segura en la base de datos
- Solo los administradores pueden ver y modificar la configuración
- Los tokens están protegidos con Row Level Security (RLS)

### Tokens Permanentes

Para producción, genera un token de acceso permanente:

1. En Meta for Developers, ve a **Configuración del Sistema**
2. Genera un **Token de Acceso del Sistema**
3. Guarda el token de forma segura
4. Actualiza la configuración en la aplicación

## 🚨 Solución de Problemas

### El webhook no se verifica

- ✅ Verifica que la URL del webhook sea correcta
- ✅ Asegúrate de que el token de verificación coincida exactamente
- ✅ Revisa que la configuración esté guardada en la aplicación

### No se reciben mensajes

- ✅ Verifica que estés suscrito a los eventos "messages"
- ✅ Confirma que el token de acceso sea válido
- ✅ Revisa los logs en Supabase Edge Functions
- ✅ Asegúrate de que el número de WhatsApp esté verificado

### Los pedidos no se crean

- ✅ Verifica el formato del mensaje
- ✅ Revisa los logs de la Edge Function
- ✅ Confirma que la base de datos esté accesible
- ✅ Verifica los permisos RLS de las tablas

### Mensajes de error comunes

**"WhatsApp configuration not found"**
- La configuración no está guardada o no está activa
- Solución: Guarda la configuración en la aplicación

**"Could not parse order from message"**
- El formato del mensaje no es correcto
- Solución: Envía un mensaje con el formato especificado

**"Error creating order"**
- Problema con la base de datos
- Solución: Revisa los logs y permisos de la base de datos

## 📊 Monitoreo

### Ver Logs

1. Ve a [Supabase Dashboard](https://supabase.com/dashboard)
2. Selecciona tu proyecto
3. Ve a **Edge Functions > whatsapp-webhook > Logs**
4. Revisa los logs en tiempo real

### Métricas

- Número de mensajes recibidos
- Pedidos creados exitosamente
- Errores de parsing
- Tiempos de respuesta

## 🔄 Actualización de Configuración

Para actualizar la configuración:

1. Ve a **Perfil > WhatsApp Business**
2. Modifica los campos necesarios
3. Toca **Guardar Configuración**
4. Los cambios se aplican inmediatamente

> **Nota:** No necesitas reconfigurar el webhook en Meta for Developers a menos que cambies el token de verificación.

## 📞 Soporte

Si tienes problemas con la configuración:

1. Revisa esta guía completa
2. Verifica los logs en Supabase
3. Consulta la documentación de Meta for Developers
4. Contacta al soporte técnico

## 🎯 Mejores Prácticas

1. **Tokens Seguros:** Usa tokens largos y complejos
2. **Tokens Permanentes:** Para producción, usa tokens permanentes
3. **Monitoreo:** Revisa los logs regularmente
4. **Pruebas:** Realiza pruebas antes de usar en producción
5. **Respaldo:** Guarda una copia de tus tokens de forma segura
6. **Actualizaciones:** Mantén la configuración actualizada
7. **Capacitación:** Enseña a los clientes el formato correcto de pedidos

## 📚 Recursos Adicionales

- [Documentación de WhatsApp Business API](https://developers.facebook.com/docs/whatsapp)
- [Guía de Webhooks de Meta](https://developers.facebook.com/docs/graph-api/webhooks)
- [Supabase Edge Functions](https://supabase.com/docs/guides/functions)

---

**Última actualización:** Enero 2025
**Versión:** 1.0.0

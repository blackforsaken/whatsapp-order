
# 🧪 Prueba Rápida del Webhook de WhatsApp

## Prueba 1: Verificar que el Webhook Responde

### Opción A: Usando el Navegador

Copia y pega esta URL en tu navegador (reemplaza `TU_TOKEN` con tu token real):

```
https://stxrvyxkxclezgcijhio.supabase.co/functions/v1/whatsapp-webhook?hub.mode=subscribe&hub.verify_token=TU_TOKEN&hub.challenge=TEST123
```

**Resultado esperado**: Deberías ver `TEST123` en la página.

### Opción B: Usando curl (Terminal/CMD)

```bash
curl "https://stxrvyxkxclezgcijhio.supabase.co/functions/v1/whatsapp-webhook?hub.mode=subscribe&hub.verify_token=TU_TOKEN&hub.challenge=TEST123"
```

**Resultado esperado**: Deberías ver `TEST123` en la terminal.

### Opción C: Usando PowerShell (Windows)

```powershell
Invoke-WebRequest -Uri "https://stxrvyxkxclezgcijhio.supabase.co/functions/v1/whatsapp-webhook?hub.mode=subscribe&hub.verify_token=TU_TOKEN&hub.challenge=TEST123"
```

## Prueba 2: Verificar Variables de Entorno

1. Ve a: https://supabase.com/dashboard/project/stxrvyxkxclezgcijhio/settings/functions
2. Verifica que existan:
   - `WHATSAPP_VERIFY_TOKEN`
   - `WHATSAPP_ACCESS_TOKEN`
   - `WHATSAPP_PHONE_NUMBER_ID`

## Prueba 3: Verificar en Meta

1. Ve a: https://developers.facebook.com/apps
2. Selecciona tu app
3. WhatsApp → Configuration → Webhook
4. Ingresa:
   - **Callback URL**: `https://stxrvyxkxclezgcijhio.supabase.co/functions/v1/whatsapp-webhook`
   - **Verify Token**: El mismo valor que `WHATSAPP_VERIFY_TOKEN` en Supabase
5. Haz clic en "Verify and Save"

## ✅ Si Todo Funciona

Deberías ver:
- ✅ En el navegador/terminal: `TEST123`
- ✅ En Meta: "Webhook verified" o mensaje de éxito
- ✅ En Supabase logs: "Webhook verified successfully"

## ❌ Si Algo Falla

### Error: "Forbidden"
- **Causa**: El token no coincide
- **Solución**: Verifica que el token en la URL sea exactamente el mismo que en Supabase

### Error: "404 Not Found"
- **Causa**: La Edge Function no existe o no está desplegada
- **Solución**: Despliega la Edge Function `whatsapp-webhook`

### Error: "500 Internal Server Error"
- **Causa**: Error en la Edge Function
- **Solución**: Revisa los logs en Supabase

### Error en Meta: "Could not validate callback URL"
- **Causa**: La URL es incorrecta o el token no coincide
- **Solución**: 
  1. Verifica que la URL sea exactamente: `https://stxrvyxkxclezgcijhio.supabase.co/functions/v1/whatsapp-webhook`
  2. Verifica que el token coincida
  3. Espera 30 segundos y vuelve a intentar

## 🎯 Valores Correctos

Para tu referencia:

**Webhook URL** (copiar exactamente):
```
https://stxrvyxkxclezgcijhio.supabase.co/functions/v1/whatsapp-webhook
```

**Verify Token**: 
- Debe ser el mismo valor que configuraste en Supabase como `WHATSAPP_VERIFY_TOKEN`
- Ejemplo: `mi_token_secreto_2024`

## 📞 Siguiente Paso

Una vez que el webhook esté verificado:
1. Suscríbete a los eventos `messages` y `message_status` en Meta
2. Configura `WHATSAPP_ACCESS_TOKEN` y `WHATSAPP_PHONE_NUMBER_ID` en Supabase
3. Guarda la configuración en la app
4. Envía un mensaje de prueba: `2 pizzas $10`
5. Verifica que recibas confirmación en WhatsApp
6. Verifica que el pedido aparezca en la app

¡Buena suerte! 🚀


# Implementación de Notificaciones WhatsApp

## Resumen de Cambios

Se ha implementado un sistema completo de notificaciones por WhatsApp para confirmar a los clientes cuando:
1. Su pedido ha sido recibido
2. El estado de su pedido cambia

## Componentes Implementados

### 1. Edge Function: `whatsapp-webhook` (Actualizada)

**Ubicación:** `supabase/functions/whatsapp-webhook/index.ts`

**Mejoras:**
- ✅ Envía mensaje de confirmación inmediata cuando se recibe un pedido por WhatsApp
- ✅ Mensaje mejorado con formato más claro y profesional
- ✅ Incluye número de pedido y lista de productos
- ✅ Informa al cliente que los precios se asignarán después
- ✅ Logs mejorados para debugging

**Mensaje de Confirmación:**
```
✅ ¡Pedido Recibido!

Hola [Nombre], hemos recibido tu pedido correctamente.

📋 Número de pedido: WA-1234567890

📦 Productos solicitados:
• 2x Tomates
• 1x Lechuga
• 3x Papas

💰 Los precios se asignarán y te confirmaremos el total cuando tu pedido esté en preparación.

Te mantendremos informado sobre el estado de tu pedido. ⏰

¡Gracias por tu preferencia! 😊
```

### 2. Edge Function: `send-whatsapp-status` (Nueva)

**Ubicación:** `supabase/functions/send-whatsapp-status/index.ts`

**Funcionalidad:**
- Envía notificaciones de cambio de estado a clientes de WhatsApp
- Mensajes personalizados según el estado del pedido
- Incluye detalles del pedido y precios cuando están disponibles

**Estados Soportados:**

#### Estado: Preparando (preparing)
```
👨‍🍳 Actualización de Pedido

Hola [Nombre],

Tu pedido WA-1234567890 ha cambiado de estado:

📊 Estado: En Preparación

Estamos preparando tu pedido con mucho cuidado.

📦 Detalle del pedido:
• 2x Tomates - $2,000
• 1x Lechuga - $1,500
• 3x Papas - $3,000

💰 Total: $6,500

Te avisaremos cuando esté listo. ⏰
```

#### Estado: Listo (ready)
```
✅ Actualización de Pedido

Hola [Nombre],

Tu pedido WA-1234567890 ha cambiado de estado:

📊 Estado: Listo para Retirar/Entregar

¡Tu pedido está listo! 🎉

💰 Total a pagar: $6,500

Puedes pasar a recogerlo o esperar la entrega.
¡Gracias por tu preferencia! 😊
```

#### Estado: Entregado (delivered)
```
🎉 Actualización de Pedido

Hola [Nombre],

Tu pedido WA-1234567890 ha cambiado de estado:

📊 Estado: Entregado

¡Tu pedido ha sido entregado! 🎉

Esperamos que disfrutes tus productos frescos.

¡Gracias por tu compra! Esperamos verte pronto. 😊
```

#### Estado: Cancelado (cancelled)
```
❌ Actualización de Pedido

Hola [Nombre],

Tu pedido WA-1234567890 ha cambiado de estado:

📊 Estado: Cancelado

Lamentablemente tu pedido ha sido cancelado. 😔

Si tienes alguna pregunta, no dudes en contactarnos.
Disculpa las molestias.
```

### 3. OrderService (Actualizado)

**Ubicación:** `services/OrderService.ts`

**Cambios:**
- ✅ Nuevo método privado `sendWhatsAppStatusNotification()`
- ✅ Integrado en `updateOrderStatus()` para enviar notificaciones automáticamente
- ✅ Solo envía notificaciones para pedidos con source='whatsapp'
- ✅ Manejo de errores que no interrumpe la actualización del estado

**Flujo de Notificación:**
1. Se actualiza el estado del pedido en la base de datos
2. Se envían notificaciones push a los usuarios de la app
3. Si el pedido es de WhatsApp, se llama a la Edge Function `send-whatsapp-status`
4. La Edge Function envía el mensaje al cliente por WhatsApp

## Configuración Requerida

### 1. WhatsApp Business API

Asegúrate de tener configurado en `whatsapp_config`:
- ✅ `access_token`: Token de acceso de WhatsApp Business API
- ✅ `phone_number_id`: ID del número de teléfono de WhatsApp Business
- ✅ `verify_token`: Token de verificación del webhook
- ✅ `is_active`: true

### 2. Supabase Edge Functions

Las siguientes funciones deben estar desplegadas:
- ✅ `whatsapp-webhook` (versión 14)
- ✅ `send-whatsapp-status` (versión 1)

### 3. Configuración de Seguridad

En `supabase/config.toml`:
```toml
[functions.whatsapp-webhook]
verify_jwt = false  # Público para Meta

[functions.send-whatsapp-status]
verify_jwt = true   # Protegido, solo llamadas internas
```

## Flujo Completo de un Pedido por WhatsApp

### 1. Cliente Envía Pedido
```
Cliente → WhatsApp → Meta → Webhook
```

### 2. Webhook Procesa y Confirma
```
Webhook → Base de Datos (crea pedido)
       → WhatsApp API (envía confirmación)
       → Push Notifications (notifica staff)
```

### 3. Staff Cambia Estado a "Preparando"
```
App → OrderService.updateOrderStatus()
   → Base de Datos (actualiza estado)
   → Push Notifications (notifica staff)
   → send-whatsapp-status (notifica cliente)
      → WhatsApp API (envía actualización con precios)
```

### 4. Staff Cambia Estado a "Listo"
```
App → OrderService.updateOrderStatus()
   → Base de Datos (actualiza estado)
   → Push Notifications (notifica staff)
   → send-whatsapp-status (notifica cliente)
      → WhatsApp API (envía actualización)
```

### 5. Staff Cambia Estado a "Entregado"
```
App → OrderService.updateOrderStatus()
   → Base de Datos (actualiza estado)
   → Push Notifications (notifica staff)
   → send-whatsapp-status (notifica cliente)
      → WhatsApp API (envía confirmación de entrega)
```

## Pruebas

### Probar Confirmación de Recepción

1. Envía un mensaje de WhatsApp al número configurado:
   ```
   2 tomates
   1 lechuga
   3 papas
   ```

2. Verifica que recibes:
   - ✅ Mensaje de confirmación por WhatsApp
   - ✅ Pedido aparece en la app con estado "Pendiente"
   - ✅ Notificación push en la app

### Probar Notificaciones de Estado

1. Abre el pedido en la app
2. Cambia el estado a "Preparando"
   - ✅ Agrega precios a los productos
   - ✅ Verifica que el cliente recibe mensaje con precios
3. Cambia el estado a "Listo"
   - ✅ Verifica que el cliente recibe mensaje de pedido listo
4. Cambia el estado a "Entregado"
   - ✅ Verifica que el cliente recibe mensaje de confirmación

## Logs y Debugging

### Ver Logs de Webhook
```
Supabase Dashboard → Edge Functions → whatsapp-webhook → Logs
```

### Ver Logs de Notificaciones de Estado
```
Supabase Dashboard → Edge Functions → send-whatsapp-status → Logs
```

### Logs en la App
Los logs se imprimen en la consola cuando:
- Se actualiza el estado de un pedido
- Se envía una notificación de WhatsApp
- Ocurre un error en el proceso

## Solución de Problemas

### El cliente no recibe la confirmación inicial

**Posibles causas:**
1. WhatsApp config no está activa en la base de datos
2. Token de acceso inválido o expirado
3. Número de teléfono no tiene permisos

**Solución:**
- Verifica la configuración en `app/whatsapp-config.tsx`
- Revisa los logs de `whatsapp-webhook`
- Confirma que el número de WhatsApp Business está activo

### El cliente no recibe notificaciones de cambio de estado

**Posibles causas:**
1. El pedido no tiene `source='whatsapp'`
2. La Edge Function `send-whatsapp-status` no está desplegada
3. Error en la configuración de WhatsApp

**Solución:**
- Verifica que el pedido fue creado por WhatsApp
- Revisa los logs de `send-whatsapp-status`
- Confirma que la configuración de WhatsApp está activa

### Los mensajes se envían pero no llegan

**Posibles causas:**
1. El número del cliente no está registrado en WhatsApp
2. El número del cliente bloqueó el número de negocio
3. Límites de tasa de Meta alcanzados

**Solución:**
- Verifica que el número del cliente es válido
- Revisa el estado de la cuenta de WhatsApp Business en Meta
- Consulta los límites de mensajería en Meta for Developers

## Características Adicionales

### Formato de Mensajes
- ✅ Uso de emojis para mejor experiencia visual
- ✅ Formato con negritas (*texto*) para destacar información importante
- ✅ Estructura clara y fácil de leer
- ✅ Mensajes personalizados según el estado

### Seguridad
- ✅ Solo pedidos de WhatsApp reciben notificaciones de WhatsApp
- ✅ Validación de configuración antes de enviar mensajes
- ✅ Manejo de errores que no interrumpe el flujo principal
- ✅ Logs detallados para auditoría

### Escalabilidad
- ✅ Edge Functions serverless (escalan automáticamente)
- ✅ Procesamiento asíncrono de notificaciones
- ✅ No bloquea la actualización del estado del pedido
- ✅ Manejo de múltiples pedidos simultáneos

## Próximos Pasos Sugeridos

1. **Plantillas de WhatsApp Business:**
   - Crear plantillas aprobadas por Meta para mensajes más ricos
   - Incluir botones de acción (confirmar recepción, etc.)

2. **Notificaciones Proactivas:**
   - Recordatorios automáticos si el pedido lleva mucho tiempo en un estado
   - Encuestas de satisfacción después de la entrega

3. **Integración con Ubicación:**
   - Enviar ubicación del negocio cuando el pedido está listo
   - Tracking de entrega en tiempo real

4. **Analytics:**
   - Métricas de tasa de entrega de mensajes
   - Tiempo promedio entre estados
   - Satisfacción del cliente

## Soporte

Para más información sobre la API de WhatsApp Business:
- [Documentación oficial de Meta](https://developers.facebook.com/docs/whatsapp/cloud-api)
- [Guía de configuración de webhooks](https://developers.facebook.com/docs/whatsapp/cloud-api/guides/set-up-webhooks)
- [Referencia de API](https://developers.facebook.com/docs/whatsapp/cloud-api/reference)

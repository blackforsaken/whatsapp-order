
import React, { useEffect, useCallback } from 'react';
import { Platform, ActivityIndicator, View } from 'react-native';
import { Stack, useRouter, useSegments } from 'expo-router';
import { NativeTabs, Icon, Label } from 'expo-router/unstable-native-tabs';
import FloatingTabBar, { TabBarItem } from '@/components/FloatingTabBar';
import { colors } from '@/styles/commonStyles';
import { useAuth } from '@/contexts/AuthContext';

export default function TabLayout() {
  const { session, loading } = useAuth();
  const router = useRouter();
  const segments = useSegments();

  const handleAuthRedirect = useCallback(() => {
    if (loading) return;

    const inAuthGroup = segments[0] === 'auth';

    if (!session && !inAuthGroup) {
      // Redirect to login if not authenticated
      router.replace('/auth/login');
    } else if (session && inAuthGroup) {
      // Redirect to home if authenticated and in auth screens
      router.replace('/(tabs)/(home)');
    }
  }, [session, loading, segments, router]);

  useEffect(() => {
    handleAuthRedirect();
  }, [handleAuthRedirect]);

  if (loading) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: colors.background }}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  const tabs: TabBarItem[] = [
    {
      name: '(home)',
      title: 'Pedidos',
      icon: 'cart.fill',
      route: '/(tabs)/(home)',
    },
    {
      name: 'profile',
      title: 'Perfil',
      icon: 'person.fill',
      route: '/(tabs)/profile',
    },
  ];

  if (Platform.OS === 'ios') {
    return (
      <NativeTabs>
        <NativeTabs.Screen
          name="(home)"
          options={{
            tabBarIcon: ({ color }) => <Icon name="cart.fill" color={color} />,
            tabBarLabel: ({ color }) => <Label color={color}>Pedidos</Label>,
          }}
        />
        <NativeTabs.Screen
          name="profile"
          options={{
            tabBarIcon: ({ color }) => <Icon name="person.fill" color={color} />,
            tabBarLabel: ({ color }) => <Label color={color}>Perfil</Label>,
          }}
        />
      </NativeTabs>
    );
  }

  return (
    <>
      <Stack screenOptions={{ headerShown: false }}>
        <Stack.Screen name="(home)" />
        <Stack.Screen name="profile" />
      </Stack>
      <FloatingTabBar tabs={tabs} />
    </>
  );
}

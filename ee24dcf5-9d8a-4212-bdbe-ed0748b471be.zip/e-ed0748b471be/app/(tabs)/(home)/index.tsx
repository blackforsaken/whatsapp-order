
import React, { useState, useEffect, useCallback } from "react";
import { Stack, useRouter } from "expo-router";
import { ScrollView, Pressable, StyleSheet, View, Text, Platform, RefreshControl, ActivityIndicator } from "react-native";
import { IconSymbol } from "@/components/IconSymbol";
import { colors } from "@/styles/commonStyles";
import { Order, OrderStatus } from "@/types/Order";
import { useAutoPrint } from "@/hooks/useAutoPrint";
import { usePrinter } from "@/contexts/PrinterContext";
import { OrderService } from "@/services/OrderService";
import { NotificationService } from "@/services/NotificationService";
import { useAuth } from "@/contexts/AuthContext";
import * as Notifications from 'expo-notifications';

const getStatusColor = (status: OrderStatus): string => {
  switch (status) {
    case 'pending':
      return colors.warning;
    case 'preparing':
      return colors.info;
    case 'ready':
      return colors.success;
    case 'delivered':
      return colors.secondary;
    case 'cancelled':
      return colors.danger;
    default:
      return colors.secondary;
  }
};

const getStatusText = (status: OrderStatus): string => {
  switch (status) {
    case 'pending':
      return 'Pendiente';
    case 'preparing':
      return 'Preparando';
    case 'ready':
      return 'Listo';
    case 'delivered':
      return 'Entregado';
    case 'cancelled':
      return 'Cancelado';
    default:
      return status;
  }
};

const formatTime = (date: Date): string => {
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffMins = Math.floor(diffMs / 60000);
  
  if (diffMins < 1) return 'Ahora mismo';
  if (diffMins < 60) return `Hace ${diffMins} min`;
  
  const diffHours = Math.floor(diffMins / 60);
  if (diffHours < 24) return `Hace ${diffHours}h`;
  
  return date.toLocaleDateString('es-ES', { day: '2-digit', month: '2-digit' });
};

const formatCurrency = (amount: number): string => {
  return `$${amount.toLocaleString('es-CL', { minimumFractionDigits: 0, maximumFractionDigits: 0 })}`;
};

export default function HomeScreen() {
  const router = useRouter();
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);
  const { isConnected } = usePrinter();
  const { session } = useAuth();
  
  // Enable auto-printing for new orders
  useAutoPrint(orders);

  const loadOrders = useCallback(async () => {
    try {
      setLoading(true);
      const fetchedOrders = await OrderService.getOrders();
      console.log('Pedidos cargados:', fetchedOrders.length);
      setOrders(fetchedOrders);
    } catch (error) {
      console.error('Error al cargar pedidos:', error);
    } finally {
      setLoading(false);
    }
  }, []);

  const loadUnreadCount = useCallback(async () => {
    try {
      const count = await NotificationService.getUnreadCount();
      setUnreadCount(count);
    } catch (error) {
      console.error('Error loading unread count:', error);
    }
  }, []);

  useEffect(() => {
    if (session) {
      loadOrders();
      loadUnreadCount();
      
      // Subscribe to new orders
      const unsubscribeNew = OrderService.subscribeToNewOrders((newOrder) => {
        console.log('🆕 Nuevo pedido recibido en UI:', newOrder.orderNumber);
        setOrders((prev) => [newOrder, ...prev]);
        // Reload orders to ensure consistency
        loadOrders();
      });

      // Subscribe to order updates
      const unsubscribeUpdates = OrderService.subscribeToOrderUpdates((updatedOrder) => {
        console.log('🔄 Pedido actualizado en UI:', updatedOrder.orderNumber);
        setOrders((prev) =>
          prev.map((order) => (order.id === updatedOrder.id ? updatedOrder : order))
        );
      });

      return () => {
        unsubscribeNew();
        unsubscribeUpdates();
      };
    }
  }, [session, loadOrders, loadUnreadCount]);

  useEffect(() => {
    // Subscribe to notification received events
    const unsubscribeReceived = NotificationService.subscribeToNotifications((notification) => {
      console.log('Notification received:', notification);
      loadUnreadCount();
      // Reload orders if it's an order-related notification
      const data = notification.request.content.data;
      if (data?.type === 'new_order') {
        loadOrders();
      }
    });

    // Subscribe to notification response events (when user taps notification)
    const unsubscribeResponse = NotificationService.subscribeToNotificationResponse((response) => {
      console.log('Notification tapped:', response);
      const data = response.notification.request.content.data;
      
      // Navigate to order if orderId is present
      if (data?.orderId) {
        router.push(`/order/${data.orderId}`);
      }
    });

    return () => {
      unsubscribeReceived();
      unsubscribeResponse();
    };
  }, [loadOrders, loadUnreadCount, router]);

  const onRefresh = async () => {
    setRefreshing(true);
    await Promise.all([loadOrders(), loadUnreadCount()]);
    setRefreshing(false);
  };

  const renderHeaderRight = () => (
    <View style={styles.headerRightContainer}>
      <Pressable
        onPress={() => router.push('/notifications')}
        style={styles.headerButtonContainer}
      >
        <View style={{ position: 'relative' }}>
          <IconSymbol 
            name="bell.fill" 
            color={unreadCount > 0 ? colors.warning : colors.textSecondary} 
            size={22} 
          />
          {unreadCount > 0 && (
            <View style={styles.notificationBadge}>
              <Text style={styles.notificationBadgeText}>
                {unreadCount > 99 ? '99+' : unreadCount}
              </Text>
            </View>
          )}
        </View>
      </Pressable>
      <Pressable
        onPress={() => router.push('/printer-settings')}
        style={styles.headerButtonContainer}
      >
        <IconSymbol 
          name="printer.fill" 
          color={isConnected ? colors.success : colors.textSecondary} 
          size={22} 
        />
      </Pressable>
    </View>
  );

  const renderHeaderLeft = () => (
    <Pressable
      onPress={() => console.log('Abrir filtro')}
      style={styles.headerButtonContainer}
    >
      <IconSymbol name="line.3.horizontal.decrease.circle" color={colors.primary} size={24} />
    </Pressable>
  );

  const handleOrderPress = (orderId: string) => {
    console.log('Pedido presionado:', orderId);
    router.push(`/order/${orderId}`);
  };

  const handleCreateOrder = () => {
    console.log('Navegar a crear pedido');
    router.push('/new-order');
  };

  if (loading && !refreshing) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={colors.primary} />
        <Text style={styles.loadingText}>Cargando pedidos...</Text>
      </View>
    );
  }

  return (
    <>
      {Platform.OS === 'ios' && (
        <Stack.Screen
          options={{
            title: "Pedidos - Verdurería",
            headerRight: renderHeaderRight,
            headerLeft: renderHeaderLeft,
          }}
        />
      )}
      <View style={styles.container}>
        <ScrollView
          style={styles.scrollView}
          contentContainerStyle={[
            styles.listContainer,
            Platform.OS !== 'ios' && styles.listContainerWithTabBar
          ]}
          showsVerticalScrollIndicator={false}
          stickyHeaderIndices={[0]}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={onRefresh}
              tintColor={colors.primary}
            />
          }
        >
          {/* Sticky Title Section */}
          <View style={styles.stickyHeaderWrapper}>
            <View style={styles.titleContainer}>
              <Text style={styles.mainTitle}>SISTEMA DE GESTIÓN DE PEDIDOS</Text>
              <View style={styles.titleUnderline} />
            </View>
          </View>

          {/* Orders Content */}
          <View>
            {orders.length === 0 ? (
              <View style={styles.emptyContainer}>
                <IconSymbol name="cart" size={64} color={colors.textSecondary} />
                <Text style={styles.emptyTitle}>No hay pedidos</Text>
                <Text style={styles.emptySubtitle}>Los nuevos pedidos de verduras y frutas aparecerán aquí</Text>
                <Pressable
                  style={({ pressed }) => [
                    styles.emptyCreateButton,
                    pressed && styles.emptyCreateButtonPressed,
                  ]}
                  onPress={handleCreateOrder}
                >
                  <IconSymbol name="plus.circle.fill" size={20} color={colors.card} />
                  <Text style={styles.emptyCreateButtonText}>Crear Pedido Manual</Text>
                </Pressable>
              </View>
            ) : (
              orders.map((order) => (
                <Pressable
                  key={order.id}
                  style={({ pressed }) => [
                    styles.orderCard,
                    pressed && styles.orderCardPressed,
                  ]}
                  onPress={() => handleOrderPress(order.id)}
                >
                  <View style={styles.orderHeader}>
                    <View style={styles.orderHeaderLeft}>
                      <Text style={styles.orderNumber}>{order.orderNumber}</Text>
                      <Text style={styles.orderTime}>{formatTime(order.createdAt)}</Text>
                    </View>
                    <View style={[styles.statusBadge, { backgroundColor: getStatusColor(order.status) }]}>
                      <Text style={styles.statusText}>{getStatusText(order.status)}</Text>
                    </View>
                  </View>

                  <View style={styles.customerInfo}>
                    <View style={styles.customerRow}>
                      <IconSymbol name="person.fill" size={16} color={colors.textSecondary} />
                      <Text style={styles.customerName}>{order.customerName}</Text>
                    </View>
                    <View style={styles.customerRow}>
                      <IconSymbol name="phone.fill" size={16} color={colors.textSecondary} />
                      <Text style={styles.customerPhone}>{order.customerPhone}</Text>
                    </View>
                  </View>

                  <View style={styles.orderFooter}>
                    <View style={styles.itemsCount}>
                      <IconSymbol name="cart.fill" size={16} color={colors.textSecondary} />
                      <Text style={styles.itemsCountText}>
                        {order.items.length} {order.items.length === 1 ? 'producto' : 'productos'}
                      </Text>
                    </View>
                    <Text style={styles.totalAmount}>{formatCurrency(order.totalAmount)}</Text>
                  </View>

                  {order.notes && (
                    <View style={styles.notesContainer}>
                      <IconSymbol name="note.text" size={14} color={colors.textSecondary} />
                      <Text style={styles.notesText} numberOfLines={1}>{order.notes}</Text>
                    </View>
                  )}
                </Pressable>
              ))
            )}
          </View>
        </ScrollView>

        {/* Floating Action Button */}
        <Pressable
          style={({ pressed }) => [
            styles.fab,
            pressed && styles.fabPressed,
          ]}
          onPress={handleCreateOrder}
        >
          <IconSymbol name="plus" size={28} color={colors.card} />
        </Pressable>
      </View>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: colors.background,
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: colors.textSecondary,
  },
  scrollView: {
    flex: 1,
  },
  listContainer: {
    paddingVertical: 0,
    paddingHorizontal: 0,
  },
  listContainerWithTabBar: {
    paddingBottom: 100,
  },
  stickyHeaderWrapper: {
    backgroundColor: colors.background,
    paddingHorizontal: 16,
    paddingTop: 16,
    paddingBottom: 8,
    borderBottomWidth: 1,
    borderBottomColor: colors.highlight,
  },
  titleContainer: {
    alignItems: 'center',
    paddingVertical: 16,
    paddingHorizontal: 16,
    backgroundColor: colors.card,
    borderRadius: 16,
    boxShadow: '0px 4px 12px rgba(0, 123, 255, 0.15)',
    elevation: 3,
  },
  mainTitle: {
    fontSize: 20,
    fontWeight: '800',
    color: colors.primary,
    textAlign: 'center',
    letterSpacing: 0.5,
    lineHeight: 28,
  },
  titleUnderline: {
    width: 60,
    height: 4,
    backgroundColor: colors.primary,
    borderRadius: 2,
    marginTop: 12,
  },
  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 80,
    paddingHorizontal: 16,
  },
  emptyTitle: {
    fontSize: 20,
    fontWeight: '600',
    color: colors.text,
    marginTop: 16,
  },
  emptySubtitle: {
    fontSize: 14,
    color: colors.textSecondary,
    marginTop: 8,
    marginBottom: 24,
    textAlign: 'center',
  },
  emptyCreateButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: colors.primary,
    paddingHorizontal: 24,
    paddingVertical: 14,
    borderRadius: 12,
    boxShadow: '0px 4px 12px rgba(0, 123, 255, 0.3)',
    elevation: 4,
  },
  emptyCreateButtonPressed: {
    opacity: 0.8,
    transform: [{ scale: 0.96 }],
  },
  emptyCreateButtonText: {
    fontSize: 16,
    fontWeight: '700',
    color: colors.card,
  },
  orderCard: {
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    marginHorizontal: 16,
    boxShadow: '0px 2px 8px rgba(0, 0, 0, 0.08)',
    elevation: 2,
  },
  orderCardPressed: {
    opacity: 0.7,
    transform: [{ scale: 0.98 }],
  },
  orderHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  orderHeaderLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  orderNumber: {
    fontSize: 18,
    fontWeight: '700',
    color: colors.text,
  },
  orderTime: {
    fontSize: 14,
    color: colors.textSecondary,
  },
  statusBadge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
  },
  statusText: {
    fontSize: 12,
    fontWeight: '600',
    color: colors.card,
  },
  customerInfo: {
    gap: 8,
    marginBottom: 12,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: colors.highlight,
  },
  customerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  customerName: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.text,
  },
  customerPhone: {
    fontSize: 14,
    color: colors.textSecondary,
  },
  orderFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  itemsCount: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  itemsCountText: {
    fontSize: 14,
    color: colors.textSecondary,
  },
  totalAmount: {
    fontSize: 20,
    fontWeight: '700',
    color: colors.primary,
  },
  notesContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginTop: 8,
    paddingTop: 8,
    borderTopWidth: 1,
    borderTopColor: colors.highlight,
  },
  notesText: {
    fontSize: 13,
    color: colors.textSecondary,
    fontStyle: 'italic',
    flex: 1,
  },
  headerButtonContainer: {
    padding: 6,
  },
  headerRightContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  notificationBadge: {
    position: 'absolute',
    top: -4,
    right: -4,
    minWidth: 16,
    height: 16,
    borderRadius: 8,
    backgroundColor: colors.danger,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 4,
  },
  notificationBadgeText: {
    fontSize: 9,
    fontWeight: '700',
    color: colors.card,
  },
  fab: {
    position: 'absolute',
    right: 20,
    bottom: Platform.OS === 'ios' ? 90 : 80,
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
    boxShadow: '0px 4px 16px rgba(0, 123, 255, 0.4)',
    elevation: 8,
  },
  fabPressed: {
    opacity: 0.8,
    transform: [{ scale: 0.92 }],
  },
});


import { Stack, useRouter } from 'expo-router';
import { printerService, PrinterDevice, PrinterSettings, PrinterDiagnostics } from '@/services/BluetoothPrinterService';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Pressable,
  Alert,
  ActivityIndicator,
  Platform,
  Switch,
  TextInput,
  Modal,
} from 'react-native';
import React, { useState, useEffect, useCallback } from 'react';
import { IconSymbol } from '@/components/IconSymbol';
import { colors } from '@/styles/commonStyles';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { SafeAreaView } from 'react-native-safe-area-context';

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  content: {
    padding: 20,
  },
  section: {
    marginBottom: 30,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 15,
  },
  sectionDescription: {
    fontSize: 14,
    color: colors.textSecondary,
    marginBottom: 15,
    lineHeight: 20,
  },
  statusCard: {
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 20,
    marginBottom: 15,
  },
  statusRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  statusLabel: {
    fontSize: 16,
    color: colors.textSecondary,
    marginLeft: 10,
    flex: 1,
  },
  statusValue: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.text,
  },
  connectedDevice: {
    fontSize: 14,
    color: colors.textSecondary,
    marginTop: 5,
  },
  button: {
    backgroundColor: colors.primary,
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    marginBottom: 10,
  },
  buttonSecondary: {
    backgroundColor: colors.card,
    borderColor: colors.border,
    borderWidth: 1,
  },
  buttonDanger: {
    backgroundColor: '#ef4444',
  },
  buttonSuccess: {
    backgroundColor: '#10b981',
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
  buttonTextSecondary: {
    color: colors.text,
  },
  buttonDisabled: {
    opacity: 0.5,
  },
  deviceList: {
    marginTop: 15,
  },
  deviceItem: {
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 16,
    marginBottom: 10,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  deviceInfo: {
    flex: 1,
  },
  deviceName: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 4,
  },
  deviceAddress: {
    fontSize: 14,
    color: colors.textSecondary,
  },
  emptyState: {
    padding: 40,
    alignItems: 'center',
  },
  emptyStateText: {
    fontSize: 16,
    color: colors.textSecondary,
    textAlign: 'center',
    marginTop: 10,
  },
  warningCard: {
    backgroundColor: '#fef3c7',
    borderRadius: 12,
    padding: 16,
    marginBottom: 15,
    flexDirection: 'row',
    alignItems: 'flex-start',
  },
  warningText: {
    fontSize: 14,
    color: '#92400e',
    marginLeft: 10,
    flex: 1,
  },
  errorCard: {
    backgroundColor: '#fee2e2',
    borderRadius: 12,
    padding: 16,
    marginBottom: 15,
    flexDirection: 'row',
    alignItems: 'flex-start',
  },
  errorText: {
    fontSize: 14,
    color: '#991b1b',
    marginLeft: 10,
    flex: 1,
  },
  successCard: {
    backgroundColor: '#d1fae5',
    borderRadius: 12,
    padding: 16,
    marginBottom: 15,
    flexDirection: 'row',
    alignItems: 'flex-start',
  },
  successText: {
    fontSize: 14,
    color: '#065f46',
    marginLeft: 10,
    flex: 1,
  },
  infoCard: {
    backgroundColor: '#dbeafe',
    borderRadius: 12,
    padding: 16,
    marginBottom: 15,
    flexDirection: 'row',
    alignItems: 'flex-start',
  },
  infoText: {
    fontSize: 14,
    color: '#1e40af',
    marginLeft: 10,
    flex: 1,
    lineHeight: 20,
  },
  settingCard: {
    backgroundColor: colors.card,
    borderRadius: 12,
    marginBottom: 12,
    overflow: 'hidden',
  },
  settingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
  },
  settingLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
    gap: 12,
  },
  settingTextContainer: {
    flex: 1,
  },
  settingLabel: {
    fontSize: 16,
    fontWeight: '500',
    color: colors.text,
  },
  settingDescription: {
    fontSize: 13,
    color: colors.textSecondary,
    marginTop: 2,
  },
  pickerButton: {
    backgroundColor: colors.card,
    borderRadius: 8,
    padding: 12,
    borderWidth: 1,
    borderColor: colors.border,
  },
  pickerButtonText: {
    fontSize: 16,
    color: colors.text,
  },
  input: {
    backgroundColor: colors.card,
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    color: colors.text,
    borderWidth: 1,
    borderColor: colors.border,
    marginTop: 8,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    backgroundColor: colors.card,
    borderRadius: 16,
    padding: 24,
    width: '85%',
    maxHeight: '80%',
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 20,
  },
  modalOption: {
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  modalOptionText: {
    fontSize: 16,
    color: colors.text,
  },
  modalOptionSelected: {
    backgroundColor: colors.primary + '20',
  },
  modalButtons: {
    flexDirection: 'row',
    gap: 12,
    marginTop: 20,
  },
  modalButton: {
    flex: 1,
    padding: 14,
    borderRadius: 8,
    alignItems: 'center',
  },
  diagnosticsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  diagnosticsLabel: {
    fontSize: 14,
    color: colors.textSecondary,
  },
  diagnosticsValue: {
    fontSize: 14,
    fontWeight: '500',
    color: colors.text,
  },
  tabContainer: {
    flexDirection: 'row',
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 4,
    marginBottom: 20,
  },
  tab: {
    flex: 1,
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderRadius: 8,
    alignItems: 'center',
  },
  tabActive: {
    backgroundColor: colors.primary,
  },
  tabText: {
    fontSize: 14,
    fontWeight: '500',
    color: colors.textSecondary,
  },
  tabTextActive: {
    color: '#fff',
  },
});

type TabType = 'connection' | 'formatting' | 'troubleshooting';

export default function PrinterSettingsScreen() {
  const [activeTab, setActiveTab] = useState<TabType>('connection');
  const [isScanning, setIsScanning] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const [isPrinting, setIsPrinting] = useState(false);
  const [isRunningDiagnostics, setIsRunningDiagnostics] = useState(false);
  const [devices, setDevices] = useState<PrinterDevice[]>([]);
  const [connectedDevice, setConnectedDevice] = useState<PrinterDevice | null>(null);
  const [bluetoothAvailable, setBluetoothAvailable] = useState<boolean | null>(null);
  const [initializationError, setInitializationError] = useState<string | null>(null);
  const [diagnostics, setDiagnostics] = useState<PrinterDiagnostics | null>(null);
  
  // Settings state
  const [settings, setSettings] = useState<PrinterSettings>({
    printerModel: 'generic_80mm',
    paperWidth: 80,
    fontSize: 'normal',
    printHeader: true,
    printFooter: true,
    headerText: 'VERDURERIA',
    footerText: 'Gracias por su pedido!',
    lineSpacing: 1,
    boldTitles: true,
    autoCutEnabled: true,
  });

  // Modal states
  const [showModelPicker, setShowModelPicker] = useState(false);
  const [showPaperWidthPicker, setShowPaperWidthPicker] = useState(false);
  const [showFontSizePicker, setShowFontSizePicker] = useState(false);
  const [showLineSpacingPicker, setShowLineSpacingPicker] = useState(false);

  const router = useRouter();
  const { user } = useAuth();

  const printerModels = [
    { value: 'generic_80mm', label: 'Genérica 80mm' },
    { value: 'generic_58mm', label: 'Genérica 58mm' },
    { value: 'epson_tm', label: 'Epson TM Series' },
    { value: 'star_tsp', label: 'Star TSP Series' },
    { value: 'custom', label: 'Personalizada' },
  ];

  const paperWidths = [
    { value: 58, label: '58mm' },
    { value: 80, label: '80mm' },
  ];

  const fontSizes = [
    { value: 'small', label: 'Pequeño' },
    { value: 'normal', label: 'Normal' },
    { value: 'large', label: 'Grande' },
  ];

  const lineSpacings = [
    { value: 1, label: '1x (Compacto)' },
    { value: 2, label: '2x (Normal)' },
    { value: 3, label: '3x (Espaciado)' },
  ];

  const checkBluetoothAvailability = useCallback(async () => {
    console.log('🔍 Checking Bluetooth availability...');
    const available = printerService.isBluetoothAvailable();
    setBluetoothAvailable(available);
    
    if (!available) {
      if (Platform.OS === 'web') {
        setInitializationError('Bluetooth no está disponible en la versión web. Por favor, usa la app en Android o iOS.');
      } else {
        setInitializationError('La librería de Bluetooth no está disponible. Asegúrate de haber instalado la app mediante APK (no Expo Go).');
      }
    } else {
      setInitializationError(null);
      try {
        const initialized = await printerService.initialize();
        if (!initialized) {
          setInitializationError('No se pudo inicializar Bluetooth. Asegúrate de que Bluetooth esté habilitado en tu dispositivo.');
        }
      } catch (error) {
        console.error('Error initializing Bluetooth:', error);
        setInitializationError('Error al inicializar Bluetooth: ' + (error instanceof Error ? error.message : 'Error desconocido'));
      }
    }
  }, []);

  const loadSettings = useCallback(async () => {
    try {
      const { data, error } = await supabase
        .from('user_settings')
        .select('*')
        .eq('user_id', user?.id)
        .maybeSingle();

      if (error && error.code !== 'PGRST116') {
        throw error;
      }

      if (data) {
        const loadedSettings: PrinterSettings = {
          printerModel: data.printer_model || 'generic_80mm',
          paperWidth: data.paper_width || 80,
          fontSize: (data.font_size || 'normal') as 'small' | 'normal' | 'large',
          printHeader: data.print_header ?? true,
          printFooter: data.print_footer ?? true,
          headerText: data.header_text || 'VERDURERIA',
          footerText: data.footer_text || 'Gracias por su pedido!',
          lineSpacing: data.line_spacing || 1,
          boldTitles: data.bold_titles ?? true,
          autoCutEnabled: data.auto_cut_enabled ?? true,
        };
        
        setSettings(loadedSettings);
        printerService.updateSettings(loadedSettings);
      }
    } catch (error) {
      console.error('Error loading settings:', error);
    }
  }, [user?.id]);

  const saveSettings = async (newSettings: Partial<PrinterSettings>) => {
    try {
      const updatedSettings = { ...settings, ...newSettings };
      setSettings(updatedSettings);
      printerService.updateSettings(updatedSettings);

      const { error } = await supabase
        .from('user_settings')
        .upsert({
          user_id: user?.id,
          printer_model: updatedSettings.printerModel,
          paper_width: updatedSettings.paperWidth,
          font_size: updatedSettings.fontSize,
          print_header: updatedSettings.printHeader,
          print_footer: updatedSettings.printFooter,
          header_text: updatedSettings.headerText,
          footer_text: updatedSettings.footerText,
          line_spacing: updatedSettings.lineSpacing,
          bold_titles: updatedSettings.boldTitles,
          auto_cut_enabled: updatedSettings.autoCutEnabled,
          updated_at: new Date().toISOString(),
        });

      if (error) throw error;

      console.log('✅ Settings saved successfully');
    } catch (error) {
      console.error('Error saving settings:', error);
      Alert.alert('Error', 'No se pudo guardar la configuración');
    }
  };

  const initializeBluetooth = useCallback(async () => {
    await checkBluetoothAvailability();
    const device = printerService.getConnectedDevice();
    setConnectedDevice(device);
    await loadSettings();
  }, [checkBluetoothAvailability, loadSettings]);

  useEffect(() => {
    initializeBluetooth();
  }, [initializeBluetooth]);

  const handleScanDevices = async () => {
    if (!bluetoothAvailable) {
      Alert.alert(
        'Bluetooth No Disponible',
        initializationError || 'Bluetooth no está disponible en este dispositivo.',
        [{ text: 'OK' }]
      );
      return;
    }

    setIsScanning(true);
    setDevices([]);

    try {
      console.log('🔍 Starting device scan...');
      const foundDevices = await printerService.scanForPrinters();
      console.log('Found devices:', foundDevices);
      setDevices(foundDevices);

      if (foundDevices.length === 0) {
        Alert.alert(
          'No se encontraron impresoras',
          'Asegúrate de que:\n\n- Bluetooth esté habilitado\n- La impresora esté encendida\n- La impresora esté emparejada en la configuración de Android\n- Los permisos de ubicación estén otorgados',
          [{ text: 'OK' }]
        );
      }
    } catch (error) {
      console.error('Error scanning devices:', error);
      Alert.alert(
        'Error',
        'No se pudo escanear dispositivos Bluetooth. ' + (error instanceof Error ? error.message : 'Error desconocido'),
        [{ text: 'OK' }]
      );
    } finally {
      setIsScanning(false);
    }
  };

  const handleConnectDevice = async (device: PrinterDevice) => {
    setIsConnecting(true);

    try {
      console.log('🔄 Connecting to device:', device);
      const success = await printerService.connectToPrinter(device);

      if (success) {
        setConnectedDevice(device);
        Alert.alert(
          'Conectado',
          `Conectado exitosamente a ${device.name}`,
          [{ text: 'OK' }]
        );
      } else {
        Alert.alert(
          'Error de Conexión',
          `No se pudo conectar a ${device.name}. Intenta nuevamente.`,
          [{ text: 'OK' }]
        );
      }
    } catch (error) {
      console.error('Error connecting to device:', error);
      Alert.alert(
        'Error',
        'Error al conectar con la impresora: ' + (error instanceof Error ? error.message : 'Error desconocido'),
        [{ text: 'OK' }]
      );
    } finally {
      setIsConnecting(false);
    }
  };

  const handleDisconnect = async () => {
    try {
      await printerService.disconnect();
      setConnectedDevice(null);
      Alert.alert('Desconectado', 'Impresora desconectada exitosamente', [
        { text: 'OK' },
      ]);
    } catch (error) {
      console.error('Error disconnecting:', error);
      Alert.alert(
        'Error',
        'Error al desconectar la impresora: ' + (error instanceof Error ? error.message : 'Error desconocido'),
        [{ text: 'OK' }]
      );
    }
  };

  const handlePrintTest = async () => {
    if (!connectedDevice) {
      Alert.alert('Error', 'No hay impresora conectada', [{ text: 'OK' }]);
      return;
    }

    setIsPrinting(true);

    try {
      console.log('🖨️ Printing test receipt...');
      const success = await printerService.printTest();

      if (success) {
        Alert.alert(
          'Éxito',
          'Recibo de prueba impreso correctamente',
          [{ text: 'OK' }]
        );
      } else {
        Alert.alert(
          'Error',
          'No se pudo imprimir el recibo de prueba. Verifica la conexión.',
          [{ text: 'OK' }]
        );
      }
    } catch (error) {
      console.error('Error printing test:', error);
      Alert.alert(
        'Error',
        'Error al imprimir: ' + (error instanceof Error ? error.message : 'Error desconocido'),
        [{ text: 'OK' }]
      );
    } finally {
      setIsPrinting(false);
    }
  };

  const handleRunDiagnostics = async () => {
    setIsRunningDiagnostics(true);
    try {
      const result = await printerService.runDiagnostics();
      setDiagnostics(result);
      
      if (result.lastError) {
        Alert.alert('Diagnóstico Completado', `Se encontraron problemas:\n\n${result.lastError}`, [{ text: 'OK' }]);
      } else if (result.isConnected) {
        Alert.alert('Diagnóstico Completado', 'Todo funciona correctamente. La impresora está lista para usar.', [{ text: 'OK' }]);
      } else {
        Alert.alert('Diagnóstico Completado', 'No hay impresora conectada. Escanea y conecta una impresora primero.', [{ text: 'OK' }]);
      }
    } catch (error) {
      console.error('Error running diagnostics:', error);
      Alert.alert('Error', 'Error al ejecutar diagnósticos', [{ text: 'OK' }]);
    } finally {
      setIsRunningDiagnostics(false);
    }
  };

  const renderConnectionTab = () => (
    <>
      {/* Bluetooth Status */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Estado de Bluetooth</Text>

        {bluetoothAvailable === null ? (
          <View style={styles.statusCard}>
            <ActivityIndicator size="large" color={colors.primary} />
            <Text style={[styles.statusLabel, { textAlign: 'center', marginTop: 10 }]}>
              Verificando disponibilidad de Bluetooth...
            </Text>
          </View>
        ) : bluetoothAvailable === false ? (
          <View style={styles.errorCard}>
            <IconSymbol name="exclamationmark.triangle.fill" size={24} color="#991b1b" />
            <Text style={styles.errorText}>{initializationError}</Text>
          </View>
        ) : (
          <View style={styles.successCard}>
            <IconSymbol name="checkmark.circle.fill" size={24} color="#065f46" />
            <Text style={styles.successText}>
              Bluetooth disponible y listo para usar
            </Text>
          </View>
        )}

        {Platform.OS !== 'web' && bluetoothAvailable && (
          <View style={styles.infoCard}>
            <IconSymbol name="info.circle.fill" size={24} color="#1e40af" />
            <Text style={styles.infoText}>
              <Text style={{ fontWeight: '600' }}>Consejos:{'\n'}</Text>
              - Asegúrate de que Bluetooth esté habilitado{'\n'}
              - Empareja la impresora en Configuración de Android primero{'\n'}
              - Otorga permisos de ubicación cuando se soliciten{'\n'}
              - La impresora debe estar encendida y cerca
            </Text>
          </View>
        )}

        <View style={styles.statusCard}>
          <View style={styles.statusRow}>
            <IconSymbol
              name={connectedDevice ? 'checkmark.circle.fill' : 'xmark.circle.fill'}
              size={24}
              color={connectedDevice ? '#10b981' : '#ef4444'}
            />
            <Text style={styles.statusLabel}>Estado de Conexión:</Text>
            <Text style={styles.statusValue}>
              {connectedDevice ? 'Conectado' : 'Desconectado'}
            </Text>
          </View>

          {connectedDevice && (
            <View style={{ marginTop: 10, paddingTop: 10, borderTopWidth: 1, borderTopColor: colors.border }}>
              <Text style={styles.connectedDevice}>
                <Text style={{ fontWeight: '600' }}>Impresora: </Text>
                {connectedDevice.name}
              </Text>
              <Text style={styles.connectedDevice}>
                <Text style={{ fontWeight: '600' }}>Dirección: </Text>
                {connectedDevice.address}
              </Text>
            </View>
          )}
        </View>
      </View>

      {/* Actions */}
      {bluetoothAvailable && (
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Acciones</Text>

          {!connectedDevice ? (
            <Pressable
              style={[styles.button, isScanning && styles.buttonDisabled]}
              onPress={handleScanDevices}
              disabled={isScanning}
            >
              {isScanning ? (
                <ActivityIndicator color="#fff" />
              ) : (
                <Text style={styles.buttonText}>Escanear Impresoras</Text>
              )}
            </Pressable>
          ) : (
            <>
              <Pressable
                style={[styles.button, isPrinting && styles.buttonDisabled]}
                onPress={handlePrintTest}
                disabled={isPrinting}
              >
                {isPrinting ? (
                  <ActivityIndicator color="#fff" />
                ) : (
                  <Text style={styles.buttonText}>Imprimir Prueba</Text>
                )}
              </Pressable>

              <Pressable
                style={[styles.button, styles.buttonDanger]}
                onPress={handleDisconnect}
              >
                <Text style={styles.buttonText}>Desconectar</Text>
              </Pressable>
            </>
          )}
        </View>
      )}

      {/* Device List */}
      {devices.length > 0 && (
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Impresoras Disponibles</Text>
          <View style={styles.deviceList}>
            {devices.map((device) => (
              <Pressable
                key={device.address}
                style={styles.deviceItem}
                onPress={() => handleConnectDevice(device)}
                disabled={isConnecting}
              >
                <View style={styles.deviceInfo}>
                  <Text style={styles.deviceName}>{device.name}</Text>
                  <Text style={styles.deviceAddress}>{device.address}</Text>
                </View>
                {isConnecting ? (
                  <ActivityIndicator color={colors.primary} />
                ) : (
                  <IconSymbol name="chevron.right" size={20} color={colors.textSecondary} />
                )}
              </Pressable>
            ))}
          </View>
        </View>
      )}

      {/* Empty State */}
      {!isScanning && devices.length === 0 && !connectedDevice && bluetoothAvailable && (
        <View style={styles.emptyState}>
          <IconSymbol name="printer" size={64} color={colors.textSecondary} />
          <Text style={styles.emptyStateText}>
            No hay impresoras escaneadas.{'\n'}
            Presiona &quot;Escanear Impresoras&quot; para buscar dispositivos disponibles.
          </Text>
        </View>
      )}
    </>
  );

  const renderFormattingTab = () => (
    <>
      {/* Printer Model */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Modelo de Impresora</Text>
        <Text style={styles.sectionDescription}>
          Selecciona el modelo de tu impresora para optimizar la compatibilidad
        </Text>
        
        <Pressable
          style={styles.pickerButton}
          onPress={() => setShowModelPicker(true)}
        >
          <Text style={styles.pickerButtonText}>
            {printerModels.find(m => m.value === settings.printerModel)?.label || 'Seleccionar'}
          </Text>
        </Pressable>
      </View>

      {/* Paper Width */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Ancho de Papel</Text>
        <Text style={styles.sectionDescription}>
          Configura el ancho del papel de tu impresora
        </Text>
        
        <Pressable
          style={styles.pickerButton}
          onPress={() => setShowPaperWidthPicker(true)}
        >
          <Text style={styles.pickerButtonText}>
            {paperWidths.find(w => w.value === settings.paperWidth)?.label || 'Seleccionar'}
          </Text>
        </Pressable>
      </View>

      {/* Font Size */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Tamaño de Fuente</Text>
        <Text style={styles.sectionDescription}>
          Ajusta el tamaño del texto en los recibos
        </Text>
        
        <Pressable
          style={styles.pickerButton}
          onPress={() => setShowFontSizePicker(true)}
        >
          <Text style={styles.pickerButtonText}>
            {fontSizes.find(f => f.value === settings.fontSize)?.label || 'Seleccionar'}
          </Text>
        </Pressable>
      </View>

      {/* Line Spacing */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Espaciado de Líneas</Text>
        <Text style={styles.sectionDescription}>
          Controla el espacio entre líneas en los recibos
        </Text>
        
        <Pressable
          style={styles.pickerButton}
          onPress={() => setShowLineSpacingPicker(true)}
        >
          <Text style={styles.pickerButtonText}>
            {lineSpacings.find(l => l.value === settings.lineSpacing)?.label || 'Seleccionar'}
          </Text>
        </Pressable>
      </View>

      {/* Header & Footer */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Encabezado y Pie de Página</Text>
        
        <View style={styles.settingCard}>
          <View style={styles.settingRow}>
            <View style={styles.settingLeft}>
              <IconSymbol name="doc.text" size={22} color={colors.primary} />
              <View style={styles.settingTextContainer}>
                <Text style={styles.settingLabel}>Imprimir Encabezado</Text>
                <Text style={styles.settingDescription}>
                  Mostrar encabezado en los recibos
                </Text>
              </View>
            </View>
            <Switch
              value={settings.printHeader}
              onValueChange={(value) => saveSettings({ printHeader: value })}
              trackColor={{ false: colors.border, true: colors.primary }}
              thumbColor={colors.card}
            />
          </View>
        </View>

        {settings.printHeader && (
          <TextInput
            style={styles.input}
            value={settings.headerText}
            onChangeText={(text) => saveSettings({ headerText: text })}
            placeholder="Texto del encabezado"
            placeholderTextColor={colors.textSecondary}
          />
        )}

        <View style={[styles.settingCard, { marginTop: 12 }]}>
          <View style={styles.settingRow}>
            <View style={styles.settingLeft}>
              <IconSymbol name="doc.text" size={22} color={colors.primary} />
              <View style={styles.settingTextContainer}>
                <Text style={styles.settingLabel}>Imprimir Pie de Página</Text>
                <Text style={styles.settingDescription}>
                  Mostrar pie de página en los recibos
                </Text>
              </View>
            </View>
            <Switch
              value={settings.printFooter}
              onValueChange={(value) => saveSettings({ printFooter: value })}
              trackColor={{ false: colors.border, true: colors.primary }}
              thumbColor={colors.card}
            />
          </View>
        </View>

        {settings.printFooter && (
          <TextInput
            style={styles.input}
            value={settings.footerText}
            onChangeText={(text) => saveSettings({ footerText: text })}
            placeholder="Texto del pie de página"
            placeholderTextColor={colors.textSecondary}
          />
        )}
      </View>

      {/* Additional Options */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Opciones Adicionales</Text>

        <View style={styles.settingCard}>
          <View style={styles.settingRow}>
            <View style={styles.settingLeft}>
              <IconSymbol name="bold" size={22} color={colors.primary} />
              <View style={styles.settingTextContainer}>
                <Text style={styles.settingLabel}>Títulos en Negrita</Text>
                <Text style={styles.settingDescription}>
                  Usar texto en negrita para títulos
                </Text>
              </View>
            </View>
            <Switch
              value={settings.boldTitles}
              onValueChange={(value) => saveSettings({ boldTitles: value })}
              trackColor={{ false: colors.border, true: colors.primary }}
              thumbColor={colors.card}
            />
          </View>
        </View>

        <View style={styles.settingCard}>
          <View style={styles.settingRow}>
            <View style={styles.settingLeft}>
              <IconSymbol name="scissors" size={22} color={colors.primary} />
              <View style={styles.settingTextContainer}>
                <Text style={styles.settingLabel}>Autocorte de Papel</Text>
                <Text style={styles.settingDescription}>
                  Cortar papel automáticamente después de imprimir
                </Text>
              </View>
            </View>
            <Switch
              value={settings.autoCutEnabled}
              onValueChange={(value) => saveSettings({ autoCutEnabled: value })}
              trackColor={{ false: colors.border, true: colors.primary }}
              thumbColor={colors.card}
            />
          </View>
        </View>
      </View>
    </>
  );

  const renderTroubleshootingTab = () => (
    <>
      {/* Diagnostics */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Diagnóstico de Impresora</Text>
        <Text style={styles.sectionDescription}>
          Ejecuta un diagnóstico completo para verificar el estado de la conexión y detectar problemas
        </Text>

        <Pressable
          style={[styles.button, styles.buttonSuccess, isRunningDiagnostics && styles.buttonDisabled]}
          onPress={handleRunDiagnostics}
          disabled={isRunningDiagnostics}
        >
          {isRunningDiagnostics ? (
            <ActivityIndicator color="#fff" />
          ) : (
            <Text style={styles.buttonText}>Ejecutar Diagnóstico</Text>
          )}
        </Pressable>

        {diagnostics && (
          <View style={styles.statusCard}>
            <View style={styles.diagnosticsRow}>
              <Text style={styles.diagnosticsLabel}>Bluetooth Habilitado:</Text>
              <Text style={[styles.diagnosticsValue, { color: diagnostics.bluetoothEnabled ? '#10b981' : '#ef4444' }]}>
                {diagnostics.bluetoothEnabled ? 'Sí' : 'No'}
              </Text>
            </View>
            <View style={styles.diagnosticsRow}>
              <Text style={styles.diagnosticsLabel}>Impresora Conectada:</Text>
              <Text style={[styles.diagnosticsValue, { color: diagnostics.isConnected ? '#10b981' : '#ef4444' }]}>
                {diagnostics.isConnected ? 'Sí' : 'No'}
              </Text>
            </View>
            {diagnostics.deviceName && (
              <View style={styles.diagnosticsRow}>
                <Text style={styles.diagnosticsLabel}>Nombre del Dispositivo:</Text>
                <Text style={styles.diagnosticsValue}>{diagnostics.deviceName}</Text>
              </View>
            )}
            {diagnostics.deviceAddress && (
              <View style={styles.diagnosticsRow}>
                <Text style={styles.diagnosticsLabel}>Dirección MAC:</Text>
                <Text style={styles.diagnosticsValue}>{diagnostics.deviceAddress}</Text>
              </View>
            )}
            <View style={styles.diagnosticsRow}>
              <Text style={styles.diagnosticsLabel}>Última Impresión:</Text>
              <Text style={[styles.diagnosticsValue, { color: diagnostics.lastPrintSuccess ? '#10b981' : '#ef4444' }]}>
                {diagnostics.lastPrintSuccess ? 'Exitosa' : 'Fallida'}
              </Text>
            </View>
            {diagnostics.lastPrintTime && (
              <View style={styles.diagnosticsRow}>
                <Text style={styles.diagnosticsLabel}>Hora de Última Impresión:</Text>
                <Text style={styles.diagnosticsValue}>
                  {diagnostics.lastPrintTime.toLocaleTimeString('es-CL')}
                </Text>
              </View>
            )}
            <View style={styles.diagnosticsRow}>
              <Text style={styles.diagnosticsLabel}>Errores Totales:</Text>
              <Text style={styles.diagnosticsValue}>{diagnostics.errorCount}</Text>
            </View>
            {diagnostics.lastError && (
              <View style={[styles.diagnosticsRow, { borderBottomWidth: 0 }]}>
                <Text style={styles.diagnosticsLabel}>Último Error:</Text>
                <Text style={[styles.diagnosticsValue, { color: '#ef4444', flex: 1, textAlign: 'right' }]}>
                  {diagnostics.lastError}
                </Text>
              </View>
            )}
          </View>
        )}
      </View>

      {/* Common Issues */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Problemas Comunes</Text>

        <View style={styles.infoCard}>
          <IconSymbol name="exclamationmark.triangle.fill" size={24} color="#1e40af" />
          <View style={{ flex: 1, marginLeft: 10 }}>
            <Text style={[styles.infoText, { fontWeight: '600', marginBottom: 8 }]}>
              No se encuentra la impresora:
            </Text>
            <Text style={styles.infoText}>
              - Verifica que Bluetooth esté habilitado{'\n'}
              - Empareja la impresora en Configuración de Android{'\n'}
              - Asegúrate de que la impresora esté encendida{'\n'}
              - Otorga permisos de ubicación a la app
            </Text>
          </View>
        </View>

        <View style={styles.infoCard}>
          <IconSymbol name="exclamationmark.triangle.fill" size={24} color="#1e40af" />
          <View style={{ flex: 1, marginLeft: 10 }}>
            <Text style={[styles.infoText, { fontWeight: '600', marginBottom: 8 }]}>
              La impresión falla o se corta:
            </Text>
            <Text style={styles.infoText}>
              - Verifica que el papel esté correctamente instalado{'\n'}
              - Comprueba que la batería de la impresora esté cargada{'\n'}
              - Intenta desactivar el autocorte si tu impresora no lo soporta{'\n'}
              - Reduce el tamaño de fuente si el texto se corta
            </Text>
          </View>
        </View>

        <View style={styles.infoCard}>
          <IconSymbol name="exclamationmark.triangle.fill" size={24} color="#1e40af" />
          <View style={{ flex: 1, marginLeft: 10 }}>
            <Text style={[styles.infoText, { fontWeight: '600', marginBottom: 8 }]}>
              Conexión se pierde frecuentemente:
            </Text>
            <Text style={styles.infoText}>
              - Mantén la impresora cerca del dispositivo{'\n'}
              - Evita obstáculos entre el dispositivo y la impresora{'\n'}
              - Verifica que no haya interferencias de otros dispositivos{'\n'}
              - Reinicia tanto la impresora como el dispositivo
            </Text>
          </View>
        </View>
      </View>

      {/* Reset Settings */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Restablecer Configuración</Text>
        <Text style={styles.sectionDescription}>
          Restaura todas las configuraciones de impresora a sus valores predeterminados
        </Text>

        <Pressable
          style={[styles.button, styles.buttonDanger]}
          onPress={() => {
            Alert.alert(
              'Restablecer Configuración',
              '¿Estás seguro de que deseas restablecer todas las configuraciones de impresora a sus valores predeterminados?',
              [
                { text: 'Cancelar', style: 'cancel' },
                {
                  text: 'Restablecer',
                  style: 'destructive',
                  onPress: () => {
                    const defaultSettings: PrinterSettings = {
                      printerModel: 'generic_80mm',
                      paperWidth: 80,
                      fontSize: 'normal',
                      printHeader: true,
                      printFooter: true,
                      headerText: 'VERDURERIA',
                      footerText: 'Gracias por su pedido!',
                      lineSpacing: 1,
                      boldTitles: true,
                      autoCutEnabled: true,
                    };
                    saveSettings(defaultSettings);
                    Alert.alert('Éxito', 'Configuración restablecida correctamente');
                  },
                },
              ]
            );
          }}
        >
          <Text style={styles.buttonText}>Restablecer a Valores Predeterminados</Text>
        </Pressable>
      </View>
    </>
  );

  return (
    <View style={styles.container}>
      <Stack.Screen
        options={{
          title: 'Configuración de Impresora',
          headerStyle: {
            backgroundColor: colors.background,
          },
          headerTintColor: colors.text,
        }}
      />

      <SafeAreaView style={styles.container} edges={['bottom']}>
        {/* Tabs */}
        <View style={{ paddingHorizontal: 20, paddingTop: 20 }}>
          <View style={styles.tabContainer}>
            <Pressable
              style={[styles.tab, activeTab === 'connection' && styles.tabActive]}
              onPress={() => setActiveTab('connection')}
            >
              <Text style={[styles.tabText, activeTab === 'connection' && styles.tabTextActive]}>
                Conexión
              </Text>
            </Pressable>
            <Pressable
              style={[styles.tab, activeTab === 'formatting' && styles.tabActive]}
              onPress={() => setActiveTab('formatting')}
            >
              <Text style={[styles.tabText, activeTab === 'formatting' && styles.tabTextActive]}>
                Formato
              </Text>
            </Pressable>
            <Pressable
              style={[styles.tab, activeTab === 'troubleshooting' && styles.tabActive]}
              onPress={() => setActiveTab('troubleshooting')}
            >
              <Text style={[styles.tabText, activeTab === 'troubleshooting' && styles.tabTextActive]}>
                Solución
              </Text>
            </Pressable>
          </View>
        </View>

        <ScrollView style={styles.content}>
          {activeTab === 'connection' && renderConnectionTab()}
          {activeTab === 'formatting' && renderFormattingTab()}
          {activeTab === 'troubleshooting' && renderTroubleshootingTab()}
        </ScrollView>
      </SafeAreaView>

      {/* Printer Model Picker Modal */}
      <Modal
        visible={showModelPicker}
        transparent
        animationType="fade"
        onRequestClose={() => setShowModelPicker(false)}
      >
        <Pressable style={styles.modalOverlay} onPress={() => setShowModelPicker(false)}>
          <Pressable style={styles.modalContent} onPress={(e) => e.stopPropagation()}>
            <Text style={styles.modalTitle}>Seleccionar Modelo</Text>
            <ScrollView>
              {printerModels.map((model) => (
                <Pressable
                  key={model.value}
                  style={[
                    styles.modalOption,
                    settings.printerModel === model.value && styles.modalOptionSelected,
                  ]}
                  onPress={() => {
                    saveSettings({ printerModel: model.value });
                    setShowModelPicker(false);
                  }}
                >
                  <Text style={styles.modalOptionText}>{model.label}</Text>
                </Pressable>
              ))}
            </ScrollView>
            <View style={styles.modalButtons}>
              <Pressable
                style={[styles.modalButton, styles.buttonSecondary]}
                onPress={() => setShowModelPicker(false)}
              >
                <Text style={styles.buttonTextSecondary}>Cancelar</Text>
              </Pressable>
            </View>
          </Pressable>
        </Pressable>
      </Modal>

      {/* Paper Width Picker Modal */}
      <Modal
        visible={showPaperWidthPicker}
        transparent
        animationType="fade"
        onRequestClose={() => setShowPaperWidthPicker(false)}
      >
        <Pressable style={styles.modalOverlay} onPress={() => setShowPaperWidthPicker(false)}>
          <Pressable style={styles.modalContent} onPress={(e) => e.stopPropagation()}>
            <Text style={styles.modalTitle}>Seleccionar Ancho de Papel</Text>
            <ScrollView>
              {paperWidths.map((width) => (
                <Pressable
                  key={width.value}
                  style={[
                    styles.modalOption,
                    settings.paperWidth === width.value && styles.modalOptionSelected,
                  ]}
                  onPress={() => {
                    saveSettings({ paperWidth: width.value });
                    setShowPaperWidthPicker(false);
                  }}
                >
                  <Text style={styles.modalOptionText}>{width.label}</Text>
                </Pressable>
              ))}
            </ScrollView>
            <View style={styles.modalButtons}>
              <Pressable
                style={[styles.modalButton, styles.buttonSecondary]}
                onPress={() => setShowPaperWidthPicker(false)}
              >
                <Text style={styles.buttonTextSecondary}>Cancelar</Text>
              </Pressable>
            </View>
          </Pressable>
        </Pressable>
      </Modal>

      {/* Font Size Picker Modal */}
      <Modal
        visible={showFontSizePicker}
        transparent
        animationType="fade"
        onRequestClose={() => setShowFontSizePicker(false)}
      >
        <Pressable style={styles.modalOverlay} onPress={() => setShowFontSizePicker(false)}>
          <Pressable style={styles.modalContent} onPress={(e) => e.stopPropagation()}>
            <Text style={styles.modalTitle}>Seleccionar Tamaño de Fuente</Text>
            <ScrollView>
              {fontSizes.map((size) => (
                <Pressable
                  key={size.value}
                  style={[
                    styles.modalOption,
                    settings.fontSize === size.value && styles.modalOptionSelected,
                  ]}
                  onPress={() => {
                    saveSettings({ fontSize: size.value as 'small' | 'normal' | 'large' });
                    setShowFontSizePicker(false);
                  }}
                >
                  <Text style={styles.modalOptionText}>{size.label}</Text>
                </Pressable>
              ))}
            </ScrollView>
            <View style={styles.modalButtons}>
              <Pressable
                style={[styles.modalButton, styles.buttonSecondary]}
                onPress={() => setShowFontSizePicker(false)}
              >
                <Text style={styles.buttonTextSecondary}>Cancelar</Text>
              </Pressable>
            </View>
          </Pressable>
        </Pressable>
      </Modal>

      {/* Line Spacing Picker Modal */}
      <Modal
        visible={showLineSpacingPicker}
        transparent
        animationType="fade"
        onRequestClose={() => setShowLineSpacingPicker(false)}
      >
        <Pressable style={styles.modalOverlay} onPress={() => setShowLineSpacingPicker(false)}>
          <Pressable style={styles.modalContent} onPress={(e) => e.stopPropagation()}>
            <Text style={styles.modalTitle}>Seleccionar Espaciado</Text>
            <ScrollView>
              {lineSpacings.map((spacing) => (
                <Pressable
                  key={spacing.value}
                  style={[
                    styles.modalOption,
                    settings.lineSpacing === spacing.value && styles.modalOptionSelected,
                  ]}
                  onPress={() => {
                    saveSettings({ lineSpacing: spacing.value });
                    setShowLineSpacingPicker(false);
                  }}
                >
                  <Text style={styles.modalOptionText}>{spacing.label}</Text>
                </Pressable>
              ))}
            </ScrollView>
            <View style={styles.modalButtons}>
              <Pressable
                style={[styles.modalButton, styles.buttonSecondary]}
                onPress={() => setShowLineSpacingPicker(false)}
              >
                <Text style={styles.buttonTextSecondary}>Cancelar</Text>
              </Pressable>
            </View>
          </Pressable>
        </Pressable>
      </Modal>
    </View>
  );
}

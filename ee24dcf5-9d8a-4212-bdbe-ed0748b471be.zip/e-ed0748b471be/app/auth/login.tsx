
import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  Pressable,
  Alert,
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
} from 'react-native';
import { useRouter } from 'expo-router';
import { useAuth } from '@/contexts/AuthContext';
import { colors } from '@/styles/commonStyles';
import { IconSymbol } from '@/components/IconSymbol';
import { SafeAreaView } from 'react-native-safe-area-context';
import { supabase } from '@/lib/supabase';

interface UserCredential {
  email: string;
  password: string;
  fullName: string;
  role: string;
}

export default function LoginScreen() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [availableUsers, setAvailableUsers] = useState<UserCredential[]>([]);
  const [loadingUsers, setLoadingUsers] = useState(true);
  const router = useRouter();
  const { signIn } = useAuth();

  useEffect(() => {
    loadAvailableUsers();
  }, []);

  const loadAvailableUsers = async () => {
    try {
      setLoadingUsers(true);
      console.log('Loading available users...');
      
      // Fetch users from profiles table
      const { data: profiles, error } = await supabase
        .from('profiles')
        .select('email, full_name, role')
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error loading users:', error);
        return;
      }

      console.log('Loaded profiles:', profiles);

      // Map known test credentials with actual roles from database
      // Note: In production, passwords are hashed and cannot be retrieved
      // These are test credentials for development purposes only
      const testCredentials: UserCredential[] = [
        {
          email: 'rhenriquez1986@gmail.com',
          password: 'rahb9032',
          fullName: 'Administrador',
          role: 'admin' // ✅ Corregido: ahora muestra el rol correcto
        },
        {
          email: 'camararhb@gmail.com',
          password: 'test123',
          fullName: 'Trabajador 1',
          role: 'viewer'
        }
      ];

      // Update roles from database to ensure they match
      const usersWithCorrectRoles = testCredentials.map(cred => {
        const dbProfile = profiles?.find(p => p.email === cred.email);
        if (dbProfile) {
          return {
            ...cred,
            role: dbProfile.role, // Use role from database
            fullName: dbProfile.full_name || cred.fullName
          };
        }
        return cred;
      });

      // Filter to only show users that exist in the database
      const existingUsers = usersWithCorrectRoles.filter(cred => 
        profiles?.some(p => p.email === cred.email)
      );

      setAvailableUsers(existingUsers);
      console.log('Available test users:', existingUsers);
    } catch (error) {
      console.error('Error loading users:', error);
    } finally {
      setLoadingUsers(false);
    }
  };

  const handleSelectUser = (user: UserCredential) => {
    setEmail(user.email);
    setPassword(user.password);
  };

  const handleLogin = async () => {
    if (!email || !password) {
      Alert.alert('Error', 'Por favor ingresa tu correo y contraseña');
      return;
    }

    setLoading(true);
    try {
      console.log('Attempting login for:', email);
      const { error } = await signIn(email.trim().toLowerCase(), password);
      
      if (error) {
        console.error('Login error:', error);
        
        // Provide user-friendly error messages
        let errorMessage = 'No se pudo iniciar sesión. Verifica tus credenciales.';
        
        if (error.message) {
          if (error.message.includes('Invalid login credentials')) {
            errorMessage = 'Correo o contraseña incorrectos. Por favor verifica tus datos.';
          } else if (error.message.includes('Email not confirmed')) {
            errorMessage = 'Por favor confirma tu correo electrónico antes de iniciar sesión.';
          } else if (error.message.includes('Database error')) {
            errorMessage = 'Error de base de datos. Por favor contacta al administrador.';
          } else if (error.message.includes('User not found')) {
            errorMessage = 'Usuario no encontrado. Por favor verifica tu correo.';
          } else {
            errorMessage = error.message;
          }
        }
        
        Alert.alert('Error de inicio de sesión', errorMessage);
      } else {
        console.log('Login successful');
        // Navigation will be handled by auth state change
        router.replace('/(tabs)/(home)');
      }
    } catch (error: any) {
      console.error('Unexpected login error:', error);
      Alert.alert(
        'Error',
        'Ocurrió un error inesperado al iniciar sesión. Por favor intenta de nuevo.'
      );
    } finally {
      setLoading(false);
    }
  };

  const getRoleColor = (role: string) => {
    switch (role) {
      case 'admin':
        return '#FF6B6B';
      case 'manager':
        return '#4ECDC4';
      case 'operator':
        return '#95E1D3';
      case 'viewer':
        return '#FFE66D';
      default:
        return colors.textSecondary;
    }
  };

  const getRoleText = (role: string) => {
    switch (role) {
      case 'admin':
        return 'Administrador';
      case 'manager':
        return 'Gerente';
      case 'operator':
        return 'Operador';
      case 'viewer':
        return 'Visualizador';
      default:
        return role;
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.keyboardView}
      >
        <ScrollView
          contentContainerStyle={styles.scrollContent}
          keyboardShouldPersistTaps="handled"
        >
          <View style={styles.header}>
            <IconSymbol name="receipt" size={60} color={colors.primary} />
            <Text style={styles.title}>Sistema de Pedidos</Text>
            <Text style={styles.subtitle}>Inicia sesión para continuar</Text>
          </View>

          {/* Available Users Section */}
          <View style={styles.usersSection}>
            <Text style={styles.usersSectionTitle}>
              👥 Usuarios Disponibles
            </Text>
            {loadingUsers ? (
              <View style={styles.loadingContainer}>
                <ActivityIndicator color={colors.primary} />
                <Text style={styles.loadingText}>Cargando usuarios...</Text>
              </View>
            ) : availableUsers.length > 0 ? (
              <View style={styles.usersList}>
                {availableUsers.map((user, index) => (
                  <Pressable
                    key={index}
                    style={[
                      styles.userCard,
                      email === user.email && styles.userCardSelected
                    ]}
                    onPress={() => handleSelectUser(user)}
                    disabled={loading}
                  >
                    <View style={styles.userCardHeader}>
                      <View style={styles.userInfo}>
                        <Text style={styles.userFullName}>{user.fullName}</Text>
                        <View style={[styles.roleBadge, { backgroundColor: getRoleColor(user.role) + '20' }]}>
                          <Text style={[styles.roleText, { color: getRoleColor(user.role) }]}>
                            {getRoleText(user.role)}
                          </Text>
                        </View>
                      </View>
                      {email === user.email && (
                        <IconSymbol name="checkmark.circle.fill" size={24} color={colors.primary} />
                      )}
                    </View>
                    <View style={styles.credentialsContainer}>
                      <View style={styles.credentialRow}>
                        <IconSymbol name="mail" size={16} color={colors.textSecondary} />
                        <Text style={styles.credentialLabel}>Email:</Text>
                        <Text style={styles.credentialValue}>{user.email}</Text>
                      </View>
                      <View style={styles.credentialRow}>
                        <IconSymbol name="lock.fill" size={16} color={colors.textSecondary} />
                        <Text style={styles.credentialLabel}>Contraseña:</Text>
                        <Text style={styles.credentialValue}>{user.password}</Text>
                      </View>
                    </View>
                  </Pressable>
                ))}
              </View>
            ) : (
              <View style={styles.noUsersContainer}>
                <IconSymbol name="person.slash" size={40} color={colors.textSecondary} />
                <Text style={styles.noUsersText}>No hay usuarios disponibles</Text>
              </View>
            )}
          </View>

          <View style={styles.divider}>
            <View style={styles.dividerLine} />
            <Text style={styles.dividerText}>O ingresa manualmente</Text>
            <View style={styles.dividerLine} />
          </View>

          <View style={styles.form}>
            <View style={styles.inputContainer}>
              <Text style={styles.label}>Correo electrónico</Text>
              <View style={styles.inputWrapper}>
                <IconSymbol name="mail" size={20} color={colors.textSecondary} />
                <TextInput
                  style={styles.input}
                  placeholder="correo@ejemplo.com"
                  placeholderTextColor={colors.textSecondary}
                  value={email}
                  onChangeText={setEmail}
                  autoCapitalize="none"
                  keyboardType="email-address"
                  autoComplete="email"
                  editable={!loading}
                />
              </View>
            </View>

            <View style={styles.inputContainer}>
              <Text style={styles.label}>Contraseña</Text>
              <View style={styles.inputWrapper}>
                <IconSymbol name="lock.fill" size={20} color={colors.textSecondary} />
                <TextInput
                  style={styles.input}
                  placeholder="••••••••"
                  placeholderTextColor={colors.textSecondary}
                  value={password}
                  onChangeText={setPassword}
                  secureTextEntry={!showPassword}
                  autoCapitalize="none"
                  autoComplete="password"
                  editable={!loading}
                />
                <Pressable
                  onPress={() => setShowPassword(!showPassword)}
                  style={styles.eyeButton}
                >
                  <IconSymbol
                    name={showPassword ? 'eye.slash.fill' : 'eye.fill'}
                    size={20}
                    color={colors.textSecondary}
                  />
                </Pressable>
              </View>
            </View>

            <Pressable
              style={[styles.button, loading && styles.buttonDisabled]}
              onPress={handleLogin}
              disabled={loading}
            >
              {loading ? (
                <ActivityIndicator color="#fff" />
              ) : (
                <Text style={styles.buttonText}>Iniciar Sesión</Text>
              )}
            </Pressable>

            <View style={styles.footer}>
              <Text style={styles.footerText}>¿No tienes una cuenta? </Text>
              <Pressable
                onPress={() => router.push('/auth/register')}
                disabled={loading}
              >
                <Text style={styles.linkText}>Regístrate</Text>
              </Pressable>
            </View>
          </View>

          {/* Security Warning */}
          <View style={styles.warningContainer}>
            <IconSymbol name="exclamationmark.triangle.fill" size={20} color="#FF6B6B" />
            <Text style={styles.warningText}>
              ⚠️ Las credenciales se muestran solo para pruebas. En producción, esta información estará oculta.
            </Text>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  keyboardView: {
    flex: 1,
  },
  scrollContent: {
    flexGrow: 1,
    padding: 24,
    paddingTop: 16,
  },
  header: {
    alignItems: 'center',
    marginBottom: 24,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: colors.text,
    marginTop: 16,
  },
  subtitle: {
    fontSize: 16,
    color: colors.textSecondary,
    marginTop: 8,
  },
  usersSection: {
    marginBottom: 24,
  },
  usersSectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 12,
  },
  loadingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
    backgroundColor: colors.card,
    borderRadius: 12,
  },
  loadingText: {
    marginLeft: 12,
    fontSize: 14,
    color: colors.textSecondary,
  },
  usersList: {
    gap: 12,
  },
  userCard: {
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 16,
    borderWidth: 2,
    borderColor: colors.border,
  },
  userCardSelected: {
    borderColor: colors.primary,
    backgroundColor: colors.primary + '10',
  },
  userCardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  userInfo: {
    flex: 1,
  },
  userFullName: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 6,
  },
  roleBadge: {
    alignSelf: 'flex-start',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 6,
  },
  roleText: {
    fontSize: 12,
    fontWeight: '600',
  },
  credentialsContainer: {
    gap: 8,
  },
  credentialRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  credentialLabel: {
    fontSize: 14,
    fontWeight: '500',
    color: colors.textSecondary,
    width: 80,
  },
  credentialValue: {
    flex: 1,
    fontSize: 14,
    color: colors.text,
    fontFamily: Platform.OS === 'ios' ? 'Courier' : 'monospace',
  },
  noUsersContainer: {
    alignItems: 'center',
    padding: 32,
    backgroundColor: colors.card,
    borderRadius: 12,
  },
  noUsersText: {
    marginTop: 12,
    fontSize: 14,
    color: colors.textSecondary,
  },
  divider: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 24,
  },
  dividerLine: {
    flex: 1,
    height: 1,
    backgroundColor: colors.border,
  },
  dividerText: {
    marginHorizontal: 16,
    fontSize: 14,
    color: colors.textSecondary,
  },
  form: {
    width: '100%',
  },
  inputContainer: {
    marginBottom: 20,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 8,
  },
  inputWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.card,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: colors.border,
    paddingHorizontal: 16,
    height: 50,
  },
  input: {
    flex: 1,
    fontSize: 16,
    color: colors.text,
    marginLeft: 12,
  },
  eyeButton: {
    padding: 4,
  },
  button: {
    backgroundColor: colors.primary,
    borderRadius: 12,
    height: 50,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 8,
  },
  buttonDisabled: {
    opacity: 0.6,
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 24,
  },
  footerText: {
    fontSize: 14,
    color: colors.textSecondary,
  },
  linkText: {
    fontSize: 14,
    color: colors.primary,
    fontWeight: '600',
  },
  warningContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FF6B6B20',
    padding: 12,
    borderRadius: 8,
    marginTop: 24,
    gap: 8,
  },
  warningText: {
    flex: 1,
    fontSize: 12,
    color: '#FF6B6B',
    lineHeight: 18,
  },
});

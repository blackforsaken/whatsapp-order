
import React, { useState, useEffect, useCallback, useRef } from "react";
import { View, Text, StyleSheet, ScrollView, Pressable, Platform, Alert, Linking, ActivityIndicator, TextInput, Modal } from "react-native";
import { Stack, useLocalSearchParams, useRouter } from "expo-router";
import { IconSymbol } from "@/components/IconSymbol";
import { colors } from "@/styles/commonStyles";
import { Order, OrderStatus, OrderItem } from "@/types/Order";
import { printerService } from "@/services/BluetoothPrinterService";
import { OrderService } from "@/services/OrderService";
import { SafeAreaView } from "react-native-safe-area-context";
import { useAuth } from "@/contexts/AuthContext";

const getStatusColor = (status: OrderStatus): string => {
  switch (status) {
    case 'pending':
      return colors.warning;
    case 'preparing':
      return colors.info;
    case 'ready':
      return colors.success;
    case 'delivered':
      return colors.secondary;
    case 'cancelled':
      return colors.danger;
    default:
      return colors.secondary;
  }
};

const getStatusText = (status: OrderStatus): string => {
  switch (status) {
    case 'pending':
      return 'Pendiente';
    case 'preparing':
      return 'Preparando';
    case 'ready':
      return 'Listo';
    case 'delivered':
      return 'Entregado';
    case 'cancelled':
      return 'Cancelado';
    default:
      return status;
  }
};

const formatCurrency = (amount: number): string => {
  return `$${amount.toLocaleString('es-CL', { minimumFractionDigits: 0, maximumFractionDigits: 0 })}`;
};

export default function OrderDetailScreen() {
  const { id } = useLocalSearchParams();
  const router = useRouter();
  const { profile } = useAuth();
  const [order, setOrder] = useState<Order | null>(null);
  const [loading, setLoading] = useState(true);
  const [isPrinting, setIsPrinting] = useState(false);
  const [isUpdatingStatus, setIsUpdatingStatus] = useState(false);
  const [isEditingPrices, setIsEditingPrices] = useState(false);
  const [editedPrices, setEditedPrices] = useState<Record<string, number>>({});
  const [showEditModal, setShowEditModal] = useState(false);
  const [showAddProductModal, setShowAddProductModal] = useState(false);
  const [isAddingProduct, setIsAddingProduct] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  
  // Use refs for form values to avoid re-render issues in production
  const productNameRef = useRef('');
  const productQuantityRef = useRef('1');
  const productPriceRef = useRef('');
  const productNotesRef = useRef('');
  
  // State for forcing re-renders when needed
  const [formKey, setFormKey] = useState(0);
  
  const [editedOrder, setEditedOrder] = useState<{
    customerName: string;
    customerPhone: string;
    customerAddress: string;
    notes: string;
    items: OrderItem[];
  } | null>(null);

  const loadOrder = useCallback(async () => {
    try {
      setLoading(true);
      console.log('Cargando pedido con id:', id);
      const fetchedOrder = await OrderService.getOrderById(id as string);
      console.log('Pedido obtenido:', fetchedOrder);
      setOrder(fetchedOrder);
      
      // Initialize edited prices
      if (fetchedOrder) {
        const prices: Record<string, number> = {};
        fetchedOrder.items.forEach(item => {
          prices[item.id] = item.price;
        });
        setEditedPrices(prices);
      }
    } catch (error) {
      console.error('Error al cargar pedido:', error);
      Alert.alert('Error', 'No se pudo cargar el pedido');
    } finally {
      setLoading(false);
    }
  }, [id]);

  useEffect(() => {
    loadOrder();
  }, [loadOrder]);

  const handleAddProduct = () => {
    console.log('Abriendo modal para agregar producto');
    // Reset all form refs
    productNameRef.current = '';
    productQuantityRef.current = '1';
    productPriceRef.current = '';
    productNotesRef.current = '';
    // Force re-render with new key
    setFormKey(prev => prev + 1);
    setShowAddProductModal(true);
  };

  const handleSaveNewProduct = async () => {
    console.log('=== GUARDANDO NUEVO PRODUCTO ===');
    console.log('Nombre:', productNameRef.current);
    console.log('Cantidad:', productQuantityRef.current);
    console.log('Precio:', productPriceRef.current);
    console.log('Notas:', productNotesRef.current);
    
    // Validate form
    if (!productNameRef.current.trim()) {
      Alert.alert('❌ Campo requerido', 'Por favor ingrese el nombre del producto');
      return;
    }

    const quantity = parseInt(productQuantityRef.current) || 0;
    const totalPrice = parseFloat(productPriceRef.current) || 0;

    if (quantity <= 0) {
      Alert.alert('❌ Cantidad inválida', 'La cantidad debe ser mayor a 0');
      return;
    }

    if (totalPrice < 0) {
      Alert.alert('❌ Precio inválido', 'El precio total no puede ser negativo');
      return;
    }

    try {
      setIsAddingProduct(true);
      console.log('Agregando producto al pedido:', order?.id);

      await OrderService.addItemToOrder(order!.id, {
        name: productNameRef.current.trim(),
        quantity,
        totalPrice,
        notes: productNotesRef.current.trim() || undefined,
      });

      console.log('✅ Producto agregado exitosamente');

      // Reload order
      await loadOrder();

      setShowAddProductModal(false);

      Alert.alert(
        '✅ Producto agregado',
        `${productNameRef.current} ha sido agregado al pedido exitosamente. Se ha enviado una notificación al cliente por WhatsApp.`
      );
    } catch (error) {
      console.error('Error al agregar producto:', error);
      Alert.alert(
        '❌ Error',
        'No se pudo agregar el producto al pedido'
      );
    } finally {
      setIsAddingProduct(false);
    }
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <Stack.Screen
          options={{
            title: "Cargando...",
            headerBackTitle: "Atrás",
          }}
        />
        <ActivityIndicator size="large" color={colors.primary} />
        <Text style={styles.loadingText}>Cargando pedido...</Text>
      </View>
    );
  }

  if (!order) {
    return (
      <View style={styles.container}>
        <Stack.Screen
          options={{
            title: "Pedido no encontrado",
            headerBackTitle: "Atrás",
          }}
        />
        <View style={styles.errorContainer}>
          <IconSymbol name="exclamationmark.triangle" size={64} color={colors.danger} />
          <Text style={styles.errorText}>Pedido no encontrado</Text>
          <Text style={styles.errorSubtext}>
            El pedido que buscas no existe o ha sido eliminado
          </Text>
          <Pressable style={styles.backButton} onPress={() => router.back()}>
            <Text style={styles.backButtonText}>Volver</Text>
          </Pressable>
        </View>
      </View>
    );
  }

  const handleStatusChange = async (newStatus: OrderStatus) => {
    console.log('Cambiando estado a:', newStatus);
    
    // If changing to preparing and prices are not set, show price editor
    if (newStatus === 'preparing' && order.items.some(item => item.price === 0)) {
      setIsEditingPrices(true);
      return;
    }
    
    try {
      setIsUpdatingStatus(true);
      await OrderService.updateOrderStatus(order.id, newStatus);
      
      // Update local state
      setOrder({ ...order, status: newStatus });
      
      Alert.alert(
        '✅ Estado actualizado',
        `El pedido ahora está ${getStatusText(newStatus).toLowerCase()}`
      );
    } catch (error) {
      console.error('Error al actualizar estado del pedido:', error);
      Alert.alert(
        '❌ Error',
        'No se pudo actualizar el estado del pedido'
      );
    } finally {
      setIsUpdatingStatus(false);
    }
  };

  const handleSavePrices = async () => {
    try {
      // Validate all prices are set
      const allPricesSet = order.items.every(item => 
        editedPrices[item.id] !== undefined && editedPrices[item.id] > 0
      );

      if (!allPricesSet) {
        Alert.alert(
          '❌ Precios incompletos',
          'Por favor ingrese un precio válido para todos los productos'
        );
        return;
      }

      setIsUpdatingStatus(true);

      // Update prices
      await OrderService.updateOrderPrices(order.id, editedPrices);

      // Update status to preparing
      await OrderService.updateOrderStatus(order.id, 'preparing');

      // Reload order
      await loadOrder();

      setIsEditingPrices(false);

      Alert.alert(
        '✅ Precios actualizados',
        'Los precios se han guardado y el pedido ahora está en estado "Preparando"'
      );
    } catch (error) {
      console.error('Error al guardar precios:', error);
      Alert.alert(
        '❌ Error',
        'No se pudieron guardar los precios'
      );
    } finally {
      setIsUpdatingStatus(false);
    }
  };

  const handleEditOrder = () => {
    setEditedOrder({
      customerName: order.customerName,
      customerPhone: order.customerPhone,
      customerAddress: order.customerAddress || '',
      notes: order.notes || '',
      items: [...order.items],
    });
    setShowEditModal(true);
  };

  const handleSaveEdit = async () => {
    if (!editedOrder) return;

    try {
      setIsUpdatingStatus(true);

      await OrderService.updateOrder(order.id, {
        customerName: editedOrder.customerName,
        customerPhone: editedOrder.customerPhone,
        customerAddress: editedOrder.customerAddress || undefined,
        notes: editedOrder.notes || undefined,
        items: editedOrder.items,
      });

      await loadOrder();
      setShowEditModal(false);

      Alert.alert(
        '✅ Pedido actualizado',
        'Los cambios se han guardado correctamente'
      );
    } catch (error) {
      console.error('Error al actualizar pedido:', error);
      Alert.alert(
        '❌ Error',
        'No se pudo actualizar el pedido'
      );
    } finally {
      setIsUpdatingStatus(false);
    }
  };

  const handlePrint = async () => {
    console.log('Botón de impresión presionado para pedido:', order.id);
    
    // Check if printer is connected
    if (!printerService.isConnected()) {
      console.log('Impresora no conectada');
      Alert.alert(
        'Impresora no conectada',
        '¿Deseas configurar una impresora ahora?',
        [
          {
            text: 'Cancelar',
            style: 'cancel',
          },
          {
            text: 'Configurar',
            onPress: () => router.push('/printer-settings'),
          },
        ]
      );
      return;
    }

    setIsPrinting(true);
    console.log('Iniciando proceso de impresión...');
    
    try {
      // Verify connection before printing
      const isConnected = await printerService.verifyConnection();
      
      if (!isConnected) {
        console.log('Verificación de conexión de impresora falló');
        Alert.alert(
          'Conexión perdida',
          'La conexión con la impresora se ha perdido. Por favor, reconecta la impresora.',
          [
            {
              text: 'OK',
              onPress: () => router.push('/printer-settings'),
            },
          ]
        );
        setIsPrinting(false);
        return;
      }

      console.log('Conexión verificada, imprimiendo pedido...');
      const printed = await printerService.printOrder(order);
      
      if (printed) {
        console.log('Pedido impreso exitosamente');
        Alert.alert('✅ Éxito', 'Pedido impreso correctamente.');
      } else {
        console.log('Impresión falló');
        Alert.alert(
          '❌ Error de impresión',
          'No se pudo imprimir el pedido. Verifica que la impresora esté encendida y tenga papel.',
          [
            {
              text: 'Reintentar',
              onPress: () => handlePrint(),
            },
            {
              text: 'Configurar',
              onPress: () => router.push('/printer-settings'),
            },
            {
              text: 'Cancelar',
              style: 'cancel',
            },
          ]
        );
      }
    } catch (error) {
      console.error('Error al imprimir pedido:', error);
      Alert.alert(
        '❌ Error',
        `Ocurrió un error al imprimir el pedido: ${error instanceof Error ? error.message : 'Error desconocido'}`,
        [
          {
            text: 'Reintentar',
            onPress: () => handlePrint(),
          },
          {
            text: 'Cancelar',
            style: 'cancel',
          },
        ]
      );
    } finally {
      setIsPrinting(false);
    }
  };

  const handleWhatsApp = async () => {
    console.log('Abriendo WhatsApp para:', order.customerPhone);
    
    try {
      // Remove any non-numeric characters from phone number
      const phoneNumber = order.customerPhone.replace(/\D/g, '');
      
      // Create WhatsApp message
      const message = `Hola ${order.customerName}, tu pedido ${order.orderNumber} de la verdurería está ${getStatusText(order.status).toLowerCase()}.`;
      
      // WhatsApp URL
      const whatsappUrl = `whatsapp://send?phone=${phoneNumber}&text=${encodeURIComponent(message)}`;
      
      // Check if WhatsApp is installed
      const canOpen = await Linking.canOpenURL(whatsappUrl);
      
      if (canOpen) {
        await Linking.openURL(whatsappUrl);
      } else {
        Alert.alert('Error', 'WhatsApp no está instalado en este dispositivo.');
      }
    } catch (error) {
      console.error('Error al abrir WhatsApp:', error);
      Alert.alert('Error', 'No se pudo abrir WhatsApp.');
    }
  };

  const handleDeleteOrder = async () => {
    if (!order) return;

    // Check if user is admin
    if (profile?.role !== 'admin') {
      Alert.alert(
        '❌ Permiso denegado',
        'Solo los administradores pueden eliminar pedidos.'
      );
      return;
    }

    // Check if order status is 'ready' or 'cancelled'
    if (order.status !== 'ready' && order.status !== 'cancelled') {
      Alert.alert(
        '❌ No se puede eliminar',
        'Solo se pueden eliminar pedidos en estado "Listo" o "Cancelado".'
      );
      return;
    }

    // Show confirmation dialog
    Alert.alert(
      '⚠️ Confirmar eliminación',
      `¿Estás seguro de que deseas eliminar el pedido ${order.orderNumber}? Esta acción no se puede deshacer.`,
      [
        {
          text: 'Cancelar',
          style: 'cancel',
        },
        {
          text: 'Eliminar',
          style: 'destructive',
          onPress: async () => {
            try {
              setIsDeleting(true);
              console.log('Eliminando pedido:', order.id);
              
              await OrderService.deleteOrder(order.id);
              
              Alert.alert(
                '✅ Pedido eliminado',
                `El pedido ${order.orderNumber} ha sido eliminado exitosamente.`,
                [
                  {
                    text: 'OK',
                    onPress: () => router.back(),
                  },
                ]
              );
            } catch (error) {
              console.error('Error al eliminar pedido:', error);
              Alert.alert(
                '❌ Error',
                error instanceof Error ? error.message : 'No se pudo eliminar el pedido'
              );
            } finally {
              setIsDeleting(false);
            }
          },
        },
      ]
    );
  };

  const canEditPrices = order.status === 'pending' || order.status === 'preparing';
  const canAddProducts = order.status === 'preparing';
  const hasPrices = order.items.every(item => item.price > 0);
  const canDelete = profile?.role === 'admin' && (order.status === 'ready' || order.status === 'cancelled');

  return (
    <>
      <Stack.Screen
        options={{
          title: order.orderNumber,
          headerBackTitle: "Atrás",
        }}
      />
      <View style={styles.container}>
        {/* Sticky Title Header */}
        <View style={styles.stickyHeader}>
          <Text style={styles.stickyTitle}>{order.orderNumber}</Text>
          <Pressable onPress={handleEditOrder} style={styles.stickyEditButton}>
            <IconSymbol name="pencil" size={20} color={colors.primary} />
          </Pressable>
        </View>

        <ScrollView
          style={styles.scrollView}
          contentContainerStyle={styles.scrollContent}
          showsVerticalScrollIndicator={false}
        >
          {/* Status Section */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Estado del Pedido</Text>
            <View style={[styles.statusCard, { borderLeftColor: getStatusColor(order.status) }]}>
              <Text style={[styles.statusLabel, { color: getStatusColor(order.status) }]}>
                {getStatusText(order.status)}
              </Text>
              <Text style={styles.statusTime}>
                Creado: {order.createdAt.toLocaleString('es-ES', { 
                  day: '2-digit', 
                  month: '2-digit', 
                  year: 'numeric',
                  hour: '2-digit', 
                  minute: '2-digit' 
                })}
              </Text>
            </View>
          </View>

          {/* Price Warning */}
          {!hasPrices && order.status === 'pending' && (
            <View style={styles.warningBanner}>
              <IconSymbol name="exclamationmark.triangle.fill" size={20} color={colors.warning} />
              <Text style={styles.warningBannerText}>
                Los precios aún no han sido asignados. Se pueden agregar cuando el pedido cambie a "Preparando".
              </Text>
            </View>
          )}

          {/* Add Products Info Banner */}
          {canAddProducts && (
            <View style={styles.infoBanner}>
              <IconSymbol name="info.circle.fill" size={20} color={colors.info} />
              <Text style={styles.infoBannerText}>
                Puedes agregar más productos manualmente mientras el pedido está en preparación.
              </Text>
            </View>
          )}

          {/* Customer Info Section */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Información del Cliente</Text>
            <View style={styles.card}>
              <View style={styles.infoRow}>
                <IconSymbol name="person.fill" size={20} color={colors.primary} />
                <View style={styles.infoContent}>
                  <Text style={styles.infoLabel}>Nombre</Text>
                  <Text style={styles.infoValue}>{order.customerName}</Text>
                </View>
              </View>
              <View style={styles.infoRow}>
                <IconSymbol name="phone.fill" size={20} color={colors.primary} />
                <View style={styles.infoContent}>
                  <Text style={styles.infoLabel}>Teléfono</Text>
                  <Text style={styles.infoValue}>{order.customerPhone}</Text>
                </View>
              </View>
              {order.customerAddress && (
                <View style={styles.infoRow}>
                  <IconSymbol name="location.fill" size={20} color={colors.primary} />
                  <View style={styles.infoContent}>
                    <Text style={styles.infoLabel}>Dirección</Text>
                    <Text style={styles.infoValue}>{order.customerAddress}</Text>
                  </View>
                </View>
              )}
            </View>
          </View>

          {/* Items Section */}
          <View style={styles.section}>
            <View style={styles.sectionHeader}>
              <Text style={styles.sectionTitle}>Productos</Text>
              <View style={styles.sectionHeaderActions}>
                {canAddProducts && !isEditingPrices && (
                  <Pressable onPress={handleAddProduct} style={styles.addProductButton}>
                    <IconSymbol name="plus.circle.fill" size={18} color={colors.success} />
                    <Text style={styles.addProductButtonText}>Agregar</Text>
                  </Pressable>
                )}
                {canEditPrices && !isEditingPrices && (
                  <Pressable onPress={() => setIsEditingPrices(true)} style={styles.editPricesButton}>
                    <IconSymbol name="dollarsign.circle" size={18} color={colors.primary} />
                    <Text style={styles.editPricesButtonText}>
                      {hasPrices ? 'Editar Precios' : 'Agregar Precios'}
                    </Text>
                  </Pressable>
                )}
              </View>
            </View>
            <View style={styles.card}>
              {order.items.map((item, index) => (
                <View
                  key={item.id}
                  style={[
                    styles.itemRow,
                    index < order.items.length - 1 && styles.itemRowBorder,
                  ]}
                >
                  <View style={styles.itemLeft}>
                    <Text style={styles.itemQuantity}>{item.quantity}x</Text>
                    <View style={styles.itemInfo}>
                      <Text style={styles.itemName}>{item.name}</Text>
                      {item.notes && (
                        <Text style={styles.itemNotes}>{item.notes}</Text>
                      )}
                      {isEditingPrices && (
                        <View style={styles.priceInputContainer}>
                          <Text style={styles.priceInputLabel}>Precio total ($):</Text>
                          <TextInput
                            style={styles.priceInput}
                            placeholder="0"
                            placeholderTextColor={colors.textSecondary}
                            value={editedPrices[item.id]?.toString() || ''}
                            onChangeText={(value) => {
                              const num = parseFloat(value) || 0;
                              setEditedPrices({ ...editedPrices, [item.id]: num });
                            }}
                            keyboardType="numeric"
                          />
                        </View>
                      )}
                    </View>
                  </View>
                  {!isEditingPrices && (
                    <Text style={styles.itemPrice}>
                      {item.price > 0 ? formatCurrency(item.price) : 'Sin precio'}
                    </Text>
                  )}
                </View>
              ))}
              {!isEditingPrices && hasPrices && (
                <View style={styles.totalRow}>
                  <Text style={styles.totalLabel}>Total</Text>
                  <Text style={styles.totalValue}>{formatCurrency(order.totalAmount)}</Text>
                </View>
              )}
              {isEditingPrices && (
                <View style={styles.priceEditActions}>
                  <Pressable
                    style={[styles.priceActionButton, styles.cancelPriceButton]}
                    onPress={() => {
                      // Reset prices
                      const prices: Record<string, number> = {};
                      order.items.forEach(item => {
                        prices[item.id] = item.price;
                      });
                      setEditedPrices(prices);
                      setIsEditingPrices(false);
                    }}
                  >
                    <Text style={styles.priceActionButtonText}>Cancelar</Text>
                  </Pressable>
                  <Pressable
                    style={[styles.priceActionButton, styles.savePriceButton]}
                    onPress={handleSavePrices}
                    disabled={isUpdatingStatus}
                  >
                    {isUpdatingStatus ? (
                      <ActivityIndicator size="small" color={colors.card} />
                    ) : (
                      <Text style={styles.priceActionButtonText}>Guardar Precios</Text>
                    )}
                  </Pressable>
                </View>
              )}
            </View>
          </View>

          {/* Notes Section */}
          {order.notes && (
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Notas</Text>
              <View style={styles.card}>
                <Text style={styles.notesText}>{order.notes}</Text>
              </View>
            </View>
          )}

          {/* Action Buttons */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Acciones</Text>
            <View style={styles.actionsGrid}>
              <Pressable
                style={({ pressed }) => [
                  styles.actionButton,
                  { backgroundColor: colors.primary },
                  pressed && styles.actionButtonPressed,
                  isPrinting && styles.actionButtonDisabled,
                ]}
                onPress={handlePrint}
                disabled={isPrinting}
              >
                <IconSymbol name="printer.fill" size={24} color={colors.card} />
                <Text style={styles.actionButtonText}>
                  {isPrinting ? 'Imprimiendo...' : 'Imprimir'}
                </Text>
              </Pressable>

              <Pressable
                style={({ pressed }) => [
                  styles.actionButton,
                  { backgroundColor: colors.success },
                  pressed && styles.actionButtonPressed,
                ]}
                onPress={handleWhatsApp}
              >
                <IconSymbol name="message.fill" size={24} color={colors.card} />
                <Text style={styles.actionButtonText}>WhatsApp</Text>
              </Pressable>
            </View>
          </View>

          {/* Delete Button - Only for admins and ready/cancelled orders */}
          {canDelete && !isEditingPrices && (
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Zona de Peligro</Text>
              <Pressable
                style={({ pressed }) => [
                  styles.deleteButton,
                  pressed && styles.deleteButtonPressed,
                  isDeleting && styles.actionButtonDisabled,
                ]}
                onPress={handleDeleteOrder}
                disabled={isDeleting}
              >
                {isDeleting ? (
                  <>
                    <ActivityIndicator size="small" color={colors.card} />
                    <Text style={styles.deleteButtonText}>Eliminando...</Text>
                  </>
                ) : (
                  <>
                    <IconSymbol name="trash.fill" size={20} color={colors.card} />
                    <Text style={styles.deleteButtonText}>Eliminar Pedido</Text>
                  </>
                )}
              </Pressable>
              <Text style={styles.deleteWarning}>
                ⚠️ Esta acción no se puede deshacer. El pedido será eliminado permanentemente.
              </Text>
            </View>
          )}

          {/* Status Change Buttons */}
          {order.status !== 'delivered' && order.status !== 'cancelled' && !isEditingPrices && (
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Cambiar Estado</Text>
              <View style={styles.statusButtons}>
                {order.status === 'pending' && (
                  <Pressable
                    style={({ pressed }) => [
                      styles.statusButton,
                      { backgroundColor: colors.info },
                      pressed && styles.statusButtonPressed,
                      isUpdatingStatus && styles.actionButtonDisabled,
                    ]}
                    onPress={() => handleStatusChange('preparing')}
                    disabled={isUpdatingStatus}
                  >
                    {isUpdatingStatus ? (
                      <ActivityIndicator size="small" color={colors.card} />
                    ) : (
                      <Text style={styles.statusButtonText}>Marcar como Preparando</Text>
                    )}
                  </Pressable>
                )}
                {order.status === 'preparing' && hasPrices && (
                  <Pressable
                    style={({ pressed }) => [
                      styles.statusButton,
                      { backgroundColor: colors.success },
                      pressed && styles.statusButtonPressed,
                      isUpdatingStatus && styles.actionButtonDisabled,
                    ]}
                    onPress={() => handleStatusChange('ready')}
                    disabled={isUpdatingStatus}
                  >
                    {isUpdatingStatus ? (
                      <ActivityIndicator size="small" color={colors.card} />
                    ) : (
                      <Text style={styles.statusButtonText}>Marcar como Listo</Text>
                    )}
                  </Pressable>
                )}
                {order.status === 'ready' && (
                  <Pressable
                    style={({ pressed }) => [
                      styles.statusButton,
                      { backgroundColor: colors.secondary },
                      pressed && styles.statusButtonPressed,
                      isUpdatingStatus && styles.actionButtonDisabled,
                    ]}
                    onPress={() => handleStatusChange('delivered')}
                    disabled={isUpdatingStatus}
                  >
                    {isUpdatingStatus ? (
                      <ActivityIndicator size="small" color={colors.card} />
                    ) : (
                      <Text style={styles.statusButtonText}>Marcar como Entregado</Text>
                    )}
                  </Pressable>
                )}
                <Pressable
                  style={({ pressed }) => [
                    styles.statusButton,
                    styles.cancelButton,
                    pressed && styles.statusButtonPressed,
                    isUpdatingStatus && styles.actionButtonDisabled,
                  ]}
                  onPress={() => handleStatusChange('cancelled')}
                  disabled={isUpdatingStatus}
                >
                  {isUpdatingStatus ? (
                    <ActivityIndicator size="small" color={colors.card} />
                  ) : (
                    <Text style={styles.statusButtonText}>Cancelar Pedido</Text>
                  )}
                </Pressable>
              </View>
            </View>
          )}

          {/* Extra bottom padding for safe area */}
          <View style={styles.bottomSpacer} />
        </ScrollView>
      </View>

      {/* Edit Order Modal */}
      <Modal
        visible={showEditModal}
        animationType="slide"
        presentationStyle="formSheet"
        onRequestClose={() => setShowEditModal(false)}
      >
        <SafeAreaView style={styles.modalContainer} edges={['top', 'bottom']}>
          <View style={styles.modalHeader}>
            <Pressable onPress={() => setShowEditModal(false)}>
              <Text style={styles.modalCancelText}>Cancelar</Text>
            </Pressable>
            <Text style={styles.modalTitle}>Editar Pedido</Text>
            <Pressable onPress={handleSaveEdit} disabled={isUpdatingStatus}>
              {isUpdatingStatus ? (
                <ActivityIndicator size="small" color={colors.primary} />
              ) : (
                <Text style={styles.modalSaveText}>Guardar</Text>
              )}
            </Pressable>
          </View>
          <ScrollView 
            style={styles.modalContent}
            contentContainerStyle={styles.modalScrollContent}
            keyboardShouldPersistTaps="handled"
            showsVerticalScrollIndicator={false}
          >
            {editedOrder && (
              <>
                <View style={styles.modalSection}>
                  <Text style={styles.modalSectionTitle}>Cliente</Text>
                  <TextInput
                    style={styles.modalInput}
                    placeholder="Nombre"
                    placeholderTextColor={colors.textSecondary}
                    value={editedOrder.customerName}
                    onChangeText={(text) => setEditedOrder({ ...editedOrder, customerName: text })}
                    autoCapitalize="words"
                  />
                  <TextInput
                    style={styles.modalInput}
                    placeholder="Teléfono"
                    placeholderTextColor={colors.textSecondary}
                    value={editedOrder.customerPhone}
                    onChangeText={(text) => setEditedOrder({ ...editedOrder, customerPhone: text })}
                    keyboardType="phone-pad"
                  />
                  <TextInput
                    style={[styles.modalInput, styles.modalTextArea]}
                    placeholder="Dirección"
                    placeholderTextColor={colors.textSecondary}
                    value={editedOrder.customerAddress}
                    onChangeText={(text) => setEditedOrder({ ...editedOrder, customerAddress: text })}
                    multiline
                    numberOfLines={3}
                    textAlignVertical="top"
                  />
                </View>
                <View style={styles.modalSection}>
                  <Text style={styles.modalSectionTitle}>Notas</Text>
                  <TextInput
                    style={[styles.modalInput, styles.modalTextArea]}
                    placeholder="Notas del pedido"
                    placeholderTextColor={colors.textSecondary}
                    value={editedOrder.notes}
                    onChangeText={(text) => setEditedOrder({ ...editedOrder, notes: text })}
                    multiline
                    numberOfLines={4}
                    textAlignVertical="top"
                  />
                </View>
              </>
            )}
          </ScrollView>
        </SafeAreaView>
      </Modal>

      {/* Add Product Modal - PRODUCTION-READY VERSION */}
      <Modal
        visible={showAddProductModal}
        animationType="slide"
        presentationStyle="formSheet"
        onRequestClose={() => setShowAddProductModal(false)}
      >
        <SafeAreaView style={styles.modalContainer} edges={['top', 'bottom']}>
          {/* Modal Header */}
          <View style={styles.modalHeader}>
            <Pressable 
              onPress={() => setShowAddProductModal(false)}
              style={styles.modalHeaderButton}
            >
              <Text style={styles.modalCancelText}>Cancelar</Text>
            </Pressable>
            <Text style={styles.modalTitle}>Agregar Producto</Text>
            <Pressable 
              onPress={handleSaveNewProduct} 
              disabled={isAddingProduct}
              style={styles.modalHeaderButton}
            >
              {isAddingProduct ? (
                <ActivityIndicator size="small" color={colors.primary} />
              ) : (
                <Text style={styles.modalSaveText}>Agregar</Text>
              )}
            </Pressable>
          </View>
          
          {/* Modal Content */}
          <ScrollView 
            style={styles.modalContent}
            contentContainerStyle={styles.modalScrollContent}
            keyboardShouldPersistTaps="handled"
            showsVerticalScrollIndicator={false}
            keyboardDismissMode="on-drag"
          >
            {/* Form Section */}
            <View style={styles.formSection}>
              <View style={styles.formSectionHeader}>
                <IconSymbol name="cart.fill" size={20} color={colors.primary} />
                <Text style={styles.formSectionTitle}>Información del Producto</Text>
              </View>
              
              {/* Product Name */}
              <View style={styles.formGroup}>
                <Text style={styles.formLabel}>
                  Nombre del Producto <Text style={styles.formRequired}>*</Text>
                </Text>
                <TextInput
                  key={`name-${formKey}`}
                  style={styles.formInput}
                  placeholder="Ej: Tomates, Lechugas, Papas"
                  placeholderTextColor={colors.textSecondary}
                  defaultValue={productNameRef.current}
                  onChangeText={(text) => {
                    productNameRef.current = text;
                  }}
                  autoCapitalize="words"
                  returnKeyType="next"
                  autoCorrect={false}
                  autoComplete="off"
                />
              </View>

              {/* Quantity */}
              <View style={styles.formGroup}>
                <Text style={styles.formLabel}>
                  Cantidad <Text style={styles.formRequired}>*</Text>
                </Text>
                <TextInput
                  key={`quantity-${formKey}`}
                  style={styles.formInput}
                  placeholder="1"
                  placeholderTextColor={colors.textSecondary}
                  defaultValue={productQuantityRef.current}
                  onChangeText={(text) => {
                    productQuantityRef.current = text;
                  }}
                  keyboardType="number-pad"
                  returnKeyType="next"
                  autoCorrect={false}
                  autoComplete="off"
                />
              </View>

              {/* Price */}
              <View style={styles.formGroup}>
                <Text style={styles.formLabel}>
                  Precio Total ($) <Text style={styles.formRequired}>*</Text>
                </Text>
                <Text style={styles.formHelperText}>
                  Ingrese el precio total del producto (no se multiplica por cantidad)
                </Text>
                <TextInput
                  key={`price-${formKey}`}
                  style={styles.formInput}
                  placeholder="0"
                  placeholderTextColor={colors.textSecondary}
                  defaultValue={productPriceRef.current}
                  onChangeText={(text) => {
                    productPriceRef.current = text;
                  }}
                  keyboardType="number-pad"
                  returnKeyType="next"
                  autoCorrect={false}
                  autoComplete="off"
                />
              </View>

              {/* Notes */}
              <View style={styles.formGroup}>
                <Text style={styles.formLabel}>Notas (opcional)</Text>
                <TextInput
                  key={`notes-${formKey}`}
                  style={[styles.formInput, styles.formTextArea]}
                  placeholder="Ej: Bien maduros, sin golpes"
                  placeholderTextColor={colors.textSecondary}
                  defaultValue={productNotesRef.current}
                  onChangeText={(text) => {
                    productNotesRef.current = text;
                  }}
                  multiline
                  numberOfLines={3}
                  textAlignVertical="top"
                  returnKeyType="done"
                  autoCorrect={false}
                  autoComplete="off"
                />
              </View>
            </View>

            {/* Info Banner */}
            <View style={styles.formInfoBanner}>
              <IconSymbol name="info.circle.fill" size={18} color={colors.info} />
              <Text style={styles.formInfoText}>
                El cliente recibirá una notificación por WhatsApp cuando agregues este producto.
              </Text>
            </View>

            {/* Action Button */}
            <View style={styles.modalActionContainer}>
              <Pressable
                style={({ pressed }) => [
                  styles.modalActionButton,
                  pressed && styles.modalActionButtonPressed,
                  isAddingProduct && styles.modalActionButtonDisabled,
                ]}
                onPress={handleSaveNewProduct}
                disabled={isAddingProduct}
              >
                {isAddingProduct ? (
                  <>
                    <ActivityIndicator size="small" color={colors.card} />
                    <Text style={styles.modalActionButtonText}>Agregando...</Text>
                  </>
                ) : (
                  <>
                    <IconSymbol name="plus.circle.fill" size={20} color={colors.card} />
                    <Text style={styles.modalActionButtonText}>Agregar Producto al Pedido</Text>
                  </>
                )}
              </Pressable>
            </View>
          </ScrollView>
        </SafeAreaView>
      </Modal>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  stickyHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: colors.card,
    borderBottomWidth: 1,
    borderBottomColor: colors.highlight,
    boxShadow: '0px 2px 4px rgba(0, 0, 0, 0.1)',
    elevation: 3,
    zIndex: 10,
  },
  stickyTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: colors.text,
  },
  stickyEditButton: {
    padding: 8,
    borderRadius: 8,
    backgroundColor: colors.background,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: colors.background,
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: colors.textSecondary,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: 16,
    paddingBottom: 120,
  },
  bottomSpacer: {
    height: 40,
  },
  section: {
    marginBottom: 24,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  sectionHeaderActions: {
    flexDirection: 'row',
    gap: 8,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: colors.text,
    marginBottom: 12,
  },
  card: {
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 16,
    boxShadow: '0px 2px 8px rgba(0, 0, 0, 0.08)',
    elevation: 2,
  },
  statusCard: {
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 16,
    borderLeftWidth: 4,
    boxShadow: '0px 2px 8px rgba(0, 0, 0, 0.08)',
    elevation: 2,
  },
  statusLabel: {
    fontSize: 20,
    fontWeight: '700',
    marginBottom: 4,
  },
  statusTime: {
    fontSize: 14,
    color: colors.textSecondary,
  },
  warningBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 16,
    marginBottom: 24,
    borderLeftWidth: 4,
    borderLeftColor: colors.warning,
  },
  warningBannerText: {
    flex: 1,
    fontSize: 14,
    color: colors.text,
    lineHeight: 20,
  },
  infoBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 16,
    marginBottom: 24,
    borderLeftWidth: 4,
    borderLeftColor: colors.info,
  },
  infoBannerText: {
    flex: 1,
    fontSize: 14,
    color: colors.text,
    lineHeight: 20,
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
    marginBottom: 16,
  },
  infoContent: {
    flex: 1,
  },
  infoLabel: {
    fontSize: 12,
    color: colors.textSecondary,
    marginBottom: 2,
  },
  infoValue: {
    fontSize: 16,
    color: colors.text,
    fontWeight: '500',
  },
  addProductButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 6,
    backgroundColor: colors.background,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: colors.success,
  },
  addProductButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.success,
  },
  editPricesButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 6,
    backgroundColor: colors.background,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: colors.primary,
  },
  editPricesButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.primary,
  },
  itemRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    paddingVertical: 12,
  },
  itemRowBorder: {
    borderBottomWidth: 1,
    borderBottomColor: colors.highlight,
  },
  itemLeft: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
    flex: 1,
  },
  itemQuantity: {
    fontSize: 16,
    fontWeight: '700',
    color: colors.primary,
    minWidth: 30,
  },
  itemInfo: {
    flex: 1,
  },
  itemName: {
    fontSize: 16,
    color: colors.text,
    fontWeight: '500',
    marginBottom: 2,
  },
  itemNotes: {
    fontSize: 13,
    color: colors.textSecondary,
    fontStyle: 'italic',
  },
  itemPrice: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.text,
  },
  priceInputContainer: {
    marginTop: 8,
    gap: 4,
  },
  priceInputLabel: {
    fontSize: 12,
    fontWeight: '600',
    color: colors.textSecondary,
  },
  priceInput: {
    backgroundColor: colors.background,
    borderRadius: 8,
    padding: 10,
    fontSize: 16,
    fontWeight: '600',
    color: colors.text,
    borderWidth: 2,
    borderColor: colors.primary,
  },
  priceEditActions: {
    flexDirection: 'row',
    gap: 12,
    marginTop: 16,
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: colors.highlight,
  },
  priceActionButton: {
    flex: 1,
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  cancelPriceButton: {
    backgroundColor: colors.textSecondary,
  },
  savePriceButton: {
    backgroundColor: colors.primary,
  },
  priceActionButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.card,
  },
  totalRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingTop: 16,
    marginTop: 8,
    borderTopWidth: 2,
    borderTopColor: colors.highlight,
  },
  totalLabel: {
    fontSize: 18,
    fontWeight: '700',
    color: colors.text,
  },
  totalValue: {
    fontSize: 24,
    fontWeight: '700',
    color: colors.primary,
  },
  notesText: {
    fontSize: 15,
    color: colors.text,
    lineHeight: 22,
  },
  actionsGrid: {
    flexDirection: 'row',
    gap: 12,
  },
  actionButton: {
    flex: 1,
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 16,
    borderRadius: 12,
    gap: 8,
  },
  actionButtonPressed: {
    opacity: 0.7,
  },
  actionButtonDisabled: {
    opacity: 0.5,
  },
  actionButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.card,
  },
  statusButtons: {
    gap: 12,
  },
  statusButton: {
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  statusButtonPressed: {
    opacity: 0.7,
  },
  statusButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.card,
  },
  cancelButton: {
    backgroundColor: colors.danger,
  },
  deleteButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: colors.danger,
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
  },
  deleteButtonPressed: {
    opacity: 0.7,
  },
  deleteButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.card,
  },
  deleteWarning: {
    fontSize: 13,
    color: colors.textSecondary,
    textAlign: 'center',
    fontStyle: 'italic',
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 32,
  },
  errorText: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
    marginTop: 16,
  },
  errorSubtext: {
    fontSize: 14,
    color: colors.textSecondary,
    marginTop: 8,
    marginBottom: 24,
    textAlign: 'center',
  },
  backButton: {
    backgroundColor: colors.primary,
    paddingHorizontal: 32,
    paddingVertical: 12,
    borderRadius: 8,
  },
  backButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.card,
  },
  modalContainer: {
    flex: 1,
    backgroundColor: colors.background,
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: colors.highlight,
    backgroundColor: colors.card,
  },
  modalHeaderButton: {
    minWidth: 80,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: colors.text,
  },
  modalCancelText: {
    fontSize: 16,
    color: colors.danger,
  },
  modalSaveText: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.primary,
    textAlign: 'right',
  },
  modalContent: {
    flex: 1,
  },
  modalScrollContent: {
    padding: 16,
    paddingBottom: 40,
  },
  modalSection: {
    marginBottom: 24,
  },
  modalSectionTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: colors.text,
    marginBottom: 12,
  },
  modalInput: {
    backgroundColor: colors.card,
    borderRadius: 8,
    padding: 14,
    fontSize: 16,
    color: colors.text,
    borderWidth: 1,
    borderColor: colors.highlight,
    marginBottom: 12,
  },
  modalTextArea: {
    minHeight: 80,
    textAlignVertical: 'top',
  },
  formSection: {
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    boxShadow: '0px 2px 8px rgba(0, 0, 0, 0.08)',
    elevation: 2,
  },
  formSectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 16,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: colors.highlight,
  },
  formSectionTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: colors.text,
  },
  formGroup: {
    marginBottom: 16,
  },
  formLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 8,
  },
  formRequired: {
    color: colors.danger,
  },
  formHelperText: {
    fontSize: 12,
    color: colors.textSecondary,
    marginBottom: 8,
    fontStyle: 'italic',
  },
  formInput: {
    backgroundColor: colors.background,
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    color: colors.text,
    borderWidth: 1,
    borderColor: colors.highlight,
  },
  formTextArea: {
    minHeight: 80,
    textAlignVertical: 'top',
  },
  formInfoBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    backgroundColor: colors.card,
    borderRadius: 10,
    padding: 14,
    marginBottom: 16,
    borderLeftWidth: 3,
    borderLeftColor: colors.info,
  },
  formInfoText: {
    flex: 1,
    fontSize: 13,
    color: colors.text,
    lineHeight: 18,
  },
  modalActionContainer: {
    marginTop: 8,
  },
  modalActionButton: {
    backgroundColor: colors.primary,
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    boxShadow: '0px 4px 12px rgba(0, 123, 255, 0.3)',
    elevation: 4,
  },
  modalActionButtonPressed: {
    opacity: 0.8,
    transform: [{ scale: 0.98 }],
  },
  modalActionButtonDisabled: {
    opacity: 0.6,
  },
  modalActionButtonText: {
    fontSize: 16,
    fontWeight: '700',
    color: colors.card,
  },
});

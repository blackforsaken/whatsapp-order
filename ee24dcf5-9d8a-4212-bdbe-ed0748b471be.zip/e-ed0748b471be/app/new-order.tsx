
import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  ScrollView,
  Pressable,
  Alert,
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  Animated,
} from 'react-native';
import { Stack, useRouter } from 'expo-router';
import { IconSymbol } from '@/components/IconSymbol';
import { colors } from '@/styles/commonStyles';
import { OrderService } from '@/services/OrderService';
import { SafeAreaView } from 'react-native-safe-area-context';

interface OrderItem {
  id: string;
  name: string;
  quantity: number;
  notes?: string;
}

export default function NewOrderScreen() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const successAnimation = useState(new Animated.Value(0))[0];

  // Customer information
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [customerAddress, setCustomerAddress] = useState('');
  const [orderNotes, setOrderNotes] = useState('');

  // Order items (without prices)
  const [items, setItems] = useState<OrderItem[]>([
    { id: '1', name: '', quantity: 1, notes: '' },
  ]);

  const addItem = () => {
    const newItem: OrderItem = {
      id: Date.now().toString(),
      name: '',
      quantity: 1,
      notes: '',
    };
    setItems([...items, newItem]);
  };

  const removeItem = (id: string) => {
    if (items.length === 1) {
      Alert.alert('Error', 'Debe haber al menos un producto en el pedido');
      return;
    }
    setItems(items.filter((item) => item.id !== id));
  };

  const updateItem = (id: string, field: keyof OrderItem, value: any) => {
    setItems(
      items.map((item) =>
        item.id === id ? { ...item, [field]: value } : item
      )
    );
  };

  const validateForm = (): boolean => {
    if (!customerName.trim()) {
      Alert.alert('❌ Campo requerido', 'Por favor ingrese el nombre del cliente');
      return false;
    }

    if (!customerPhone.trim()) {
      Alert.alert('❌ Campo requerido', 'Por favor ingrese el teléfono del cliente');
      return false;
    }

    const hasValidItems = items.some(
      (item) => item.name.trim() && item.quantity > 0
    );

    if (!hasValidItems) {
      Alert.alert(
        '❌ Productos requeridos',
        'Por favor agregue al menos un producto válido con nombre y cantidad'
      );
      return false;
    }

    return true;
  };

  const showSuccessBanner = () => {
    setShowSuccess(true);
    Animated.sequence([
      Animated.timing(successAnimation, {
        toValue: 1,
        duration: 300,
        useNativeDriver: true,
      }),
      Animated.delay(2000),
      Animated.timing(successAnimation, {
        toValue: 0,
        duration: 300,
        useNativeDriver: true,
      }),
    ]).start(() => {
      setShowSuccess(false);
    });
  };

  const handleCreateOrder = async () => {
    console.log('=== INICIANDO CREACIÓN DE PEDIDO ===');
    
    if (!validateForm()) {
      console.log('Validación fallida');
      return;
    }

    try {
      setLoading(true);
      console.log('Loading activado');

      // Filter out empty items
      const validItems = items.filter(
        (item) => item.name.trim() && item.quantity > 0
      );

      console.log('Creando pedido con:', {
        customerName,
        customerPhone,
        itemsCount: validItems.length
      });

      const order = await OrderService.createOrder(
        customerName.trim(),
        customerPhone.trim(),
        customerAddress.trim() || undefined,
        validItems.map((item) => ({
          name: item.name.trim(),
          quantity: item.quantity,
          price: 0, // Price is 0 initially
          notes: item.notes?.trim() || undefined,
        })),
        orderNotes.trim() || undefined
      );

      console.log('✅ Pedido creado exitosamente:', order);

      if (order) {
        // Mostrar banner de éxito con animación
        showSuccessBanner();
        
        // Esperar un momento antes de mostrar el Alert
        setTimeout(() => {
          Alert.alert(
            '✅ ¡Pedido Creado Exitosamente!',
            `Pedido ${order.orderNumber} creado para ${customerName}.\n\n` +
            `📦 Total de productos: ${validItems.length}\n\n` +
            `💰 Los precios se pueden agregar cuando el pedido cambie a estado "Preparando".`,
            [
              {
                text: '👁️ Ver Pedido',
                onPress: () => {
                  console.log('Navegando a pedido:', order.id);
                  router.replace(`/order/${order.id}`);
                },
              },
              {
                text: '➕ Crear Otro',
                onPress: () => {
                  console.log('Reseteando formulario');
                  // Reset form
                  setCustomerName('');
                  setCustomerPhone('');
                  setCustomerAddress('');
                  setOrderNotes('');
                  setItems([{ id: Date.now().toString(), name: '', quantity: 1, notes: '' }]);
                },
              },
              {
                text: '🏠 Ir al Inicio',
                onPress: () => {
                  console.log('Navegando al inicio');
                  router.replace('/(tabs)/(home)');
                },
                style: 'cancel',
              },
            ],
            { 
              cancelable: false,
              onDismiss: () => {
                console.log('Alert dismissed');
              }
            }
          );
        }, 500);
      } else {
        console.error('❌ Order es null o undefined');
        Alert.alert(
          '❌ Error',
          'No se pudo crear el pedido. Por favor, intente nuevamente.'
        );
      }
    } catch (error) {
      console.error('=== ERROR AL CREAR PEDIDO ===');
      console.error('Error completo:', error);
      console.error('Error message:', error instanceof Error ? error.message : 'Unknown error');
      console.error('Error stack:', error instanceof Error ? error.stack : 'No stack');
      
      Alert.alert(
        '❌ Error al Crear Pedido',
        'Ocurrió un error al crear el pedido. Verifique su conexión e intente nuevamente.\n\n' +
        'Detalles: ' + (error instanceof Error ? error.message : 'Error desconocido')
      );
    } finally {
      setLoading(false);
      console.log('Loading desactivado');
    }
  };

  const renderHeaderRight = () => {
    return (
      <Pressable
        onPress={handleCreateOrder}
        disabled={loading}
        style={styles.headerButton}
      >
        {loading ? (
          <ActivityIndicator size="small" color={colors.primary} />
        ) : (
          <Text style={styles.headerButtonText}>Crear</Text>
        )}
      </Pressable>
    );
  };

  const successScale = successAnimation.interpolate({
    inputRange: [0, 1],
    outputRange: [0.8, 1],
  });

  const successOpacity = successAnimation;

  return (
    <>
      <Stack.Screen
        options={{
          title: 'Nuevo Pedido - Verdurería',
          headerBackTitle: 'Atrás',
          headerRight: renderHeaderRight,
        }}
      />
      <KeyboardAvoidingView
        style={styles.container}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 90 : 0}
      >
        <ScrollView
          style={styles.scrollView}
          contentContainerStyle={styles.scrollContent}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        >
          {/* Success Banner with Animation */}
          {showSuccess && (
            <Animated.View 
              style={[
                styles.successBanner,
                {
                  opacity: successOpacity,
                  transform: [{ scale: successScale }],
                }
              ]}
            >
              <IconSymbol name="checkmark.circle.fill" size={28} color="#fff" />
              <Text style={styles.successBannerText}>
                ✅ ¡Pedido creado exitosamente!
              </Text>
            </Animated.View>
          )}

          {/* Info Banner */}
          <View style={styles.infoBanner}>
            <IconSymbol name="info.circle.fill" size={20} color={colors.info} />
            <Text style={styles.infoBannerText}>
              Los precios se agregarán cuando el pedido cambie a estado "Preparando"
            </Text>
          </View>

          {/* Customer Information Section */}
          <View style={styles.section}>
            <View style={styles.sectionHeader}>
              <IconSymbol name="person.fill" size={20} color={colors.primary} />
              <Text style={styles.sectionTitle}>Información del Cliente</Text>
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.label}>
                Nombre <Text style={styles.required}>*</Text>
              </Text>
              <TextInput
                style={styles.input}
                placeholder="Ej: María García"
                placeholderTextColor={colors.textSecondary}
                value={customerName}
                onChangeText={setCustomerName}
                autoCapitalize="words"
              />
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.label}>
                Teléfono <Text style={styles.required}>*</Text>
              </Text>
              <TextInput
                style={styles.input}
                placeholder="Ej: +56 9 1234 5678"
                placeholderTextColor={colors.textSecondary}
                value={customerPhone}
                onChangeText={setCustomerPhone}
                keyboardType="phone-pad"
              />
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.label}>Dirección</Text>
              <TextInput
                style={[styles.input, styles.textArea]}
                placeholder="Ej: Av. Providencia 123, Santiago"
                placeholderTextColor={colors.textSecondary}
                value={customerAddress}
                onChangeText={setCustomerAddress}
                multiline
                numberOfLines={2}
              />
            </View>
          </View>

          {/* Order Items Section */}
          <View style={styles.section}>
            <View style={styles.sectionHeader}>
              <IconSymbol name="cart.fill" size={20} color={colors.primary} />
              <Text style={styles.sectionTitle}>Productos del Pedido</Text>
            </View>

            {items.map((item, index) => (
              <View key={item.id} style={styles.itemCard}>
                <View style={styles.itemHeader}>
                  <Text style={styles.itemNumber}>Producto {index + 1}</Text>
                  {items.length > 1 && (
                    <Pressable
                      onPress={() => removeItem(item.id)}
                      style={styles.removeButton}
                    >
                      <IconSymbol name="trash" size={18} color={colors.danger} />
                    </Pressable>
                  )}
                </View>

                <View style={styles.inputGroup}>
                  <Text style={styles.label}>
                    Nombre <Text style={styles.required}>*</Text>
                  </Text>
                  <TextInput
                    style={styles.input}
                    placeholder="Ej: Tomates, Lechugas, Papas"
                    placeholderTextColor={colors.textSecondary}
                    value={item.name}
                    onChangeText={(value) => updateItem(item.id, 'name', value)}
                  />
                </View>

                <View style={styles.inputGroup}>
                  <Text style={styles.label}>
                    Cantidad <Text style={styles.required}>*</Text>
                  </Text>
                  <TextInput
                    style={styles.input}
                    placeholder="1"
                    placeholderTextColor={colors.textSecondary}
                    value={item.quantity.toString()}
                    onChangeText={(value) => {
                      const num = parseInt(value) || 0;
                      updateItem(item.id, 'quantity', num);
                    }}
                    keyboardType="number-pad"
                  />
                </View>

                <View style={styles.inputGroup}>
                  <Text style={styles.label}>Notas del producto</Text>
                  <TextInput
                    style={styles.input}
                    placeholder="Ej: Bien maduros, sin golpes"
                    placeholderTextColor={colors.textSecondary}
                    value={item.notes}
                    onChangeText={(value) => updateItem(item.id, 'notes', value)}
                  />
                </View>
              </View>
            ))}

            <Pressable style={styles.addItemButton} onPress={addItem}>
              <IconSymbol name="plus.circle.fill" size={20} color={colors.primary} />
              <Text style={styles.addItemButtonText}>Agregar Producto</Text>
            </Pressable>
          </View>

          {/* Order Notes Section */}
          <View style={styles.section}>
            <View style={styles.sectionHeader}>
              <IconSymbol name="note.text" size={20} color={colors.primary} />
              <Text style={styles.sectionTitle}>Notas del Pedido</Text>
            </View>

            <View style={styles.inputGroup}>
              <TextInput
                style={[styles.input, styles.textArea]}
                placeholder="Notas adicionales sobre el pedido..."
                placeholderTextColor={colors.textSecondary}
                value={orderNotes}
                onChangeText={setOrderNotes}
                multiline
                numberOfLines={3}
              />
            </View>
          </View>

          {/* Create Button */}
          <View style={styles.buttonContainer}>
            <Pressable
              style={({ pressed }) => [
                styles.createButton,
                pressed && styles.createButtonPressed,
                loading && styles.createButtonDisabled,
              ]}
              onPress={handleCreateOrder}
              disabled={loading}
            >
              {loading ? (
                <>
                  <ActivityIndicator size="small" color={colors.card} />
                  <Text style={styles.createButtonText}>Creando pedido...</Text>
                </>
              ) : (
                <>
                  <IconSymbol name="checkmark.circle.fill" size={20} color={colors.card} />
                  <Text style={styles.createButtonText}>Crear Pedido</Text>
                </>
              )}
            </Pressable>
          </View>

          {/* Extra bottom padding for safe area and tab bar */}
          <View style={styles.bottomSpacer} />
        </ScrollView>
      </KeyboardAvoidingView>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    paddingVertical: 16,
    paddingHorizontal: 16,
    paddingBottom: 120,
  },
  bottomSpacer: {
    height: 40,
  },
  successBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    backgroundColor: '#4CAF50',
    borderRadius: 16,
    padding: 20,
    marginBottom: 20,
    boxShadow: '0px 8px 24px rgba(76, 175, 80, 0.5)',
    elevation: 8,
  },
  successBannerText: {
    flex: 1,
    fontSize: 18,
    fontWeight: '800',
    color: '#fff',
    lineHeight: 24,
  },
  infoBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 16,
    marginBottom: 24,
    borderLeftWidth: 4,
    borderLeftColor: colors.info,
  },
  infoBannerText: {
    flex: 1,
    fontSize: 14,
    color: colors.text,
    lineHeight: 20,
  },
  section: {
    marginBottom: 24,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: colors.text,
  },
  inputGroup: {
    marginBottom: 16,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 8,
  },
  required: {
    color: colors.danger,
  },
  input: {
    backgroundColor: colors.card,
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    color: colors.text,
    borderWidth: 1,
    borderColor: colors.highlight,
  },
  textArea: {
    minHeight: 80,
    textAlignVertical: 'top',
  },
  itemCard: {
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: colors.highlight,
  },
  itemHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: colors.highlight,
  },
  itemNumber: {
    fontSize: 16,
    fontWeight: '700',
    color: colors.text,
  },
  removeButton: {
    padding: 4,
  },
  addItemButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: colors.card,
    borderRadius: 8,
    padding: 12,
    borderWidth: 2,
    borderColor: colors.primary,
    borderStyle: 'dashed',
  },
  addItemButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.primary,
  },
  buttonContainer: {
    marginBottom: 20,
  },
  createButton: {
    backgroundColor: colors.primary,
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    boxShadow: '0px 4px 12px rgba(0, 123, 255, 0.3)',
    elevation: 4,
  },
  createButtonPressed: {
    opacity: 0.8,
    transform: [{ scale: 0.98 }],
  },
  createButtonDisabled: {
    opacity: 0.6,
  },
  createButtonText: {
    fontSize: 18,
    fontWeight: '700',
    color: colors.card,
  },
  headerButton: {
    paddingHorizontal: 12,
    paddingVertical: 6,
  },
  headerButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.primary,
  },
});

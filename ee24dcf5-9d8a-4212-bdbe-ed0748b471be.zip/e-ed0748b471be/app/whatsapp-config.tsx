
import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  ScrollView,
  Pressable,
  Alert,
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  Clipboard,
  Modal,
  Linking,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Stack, useRouter } from 'expo-router';
import { IconSymbol } from '@/components/IconSymbol';
import { colors } from '@/styles/commonStyles';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';

interface WhatsAppConfig {
  id?: string;
  verify_token: string;
  access_token: string;
  phone_number_id: string;
  webhook_url: string;
  is_active: boolean;
}

export default function WhatsAppConfigScreen() {
  const router = useRouter();
  const { profile } = useAuth();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [showTestModal, setShowTestModal] = useState(false);
  const [config, setConfig] = useState<WhatsAppConfig>({
    verify_token: '',
    access_token: '',
    phone_number_id: '',
    webhook_url: 'https://stxrvyxkxclezgcijhio.supabase.co/functions/v1/whatsapp-webhook',
    is_active: true,
  });
  const [showTokens, setShowTokens] = useState({
    verify: false,
    access: false,
  });

  useEffect(() => {
    if (profile?.role !== 'admin') {
      Alert.alert('Acceso Denegado', 'Solo los administradores pueden acceder a esta configuración.');
      router.back();
      return;
    }
    loadConfig();
  }, [profile, router]);

  const loadConfig = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('whatsapp_config')
        .select('*')
        .eq('is_active', true)
        .maybeSingle();

      if (error) {
        throw error;
      }

      if (data) {
        setConfig(data);
      }
    } catch (error) {
      console.error('Error loading WhatsApp config:', error);
      Alert.alert('Error', 'No se pudo cargar la configuración de WhatsApp');
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    if (!config.verify_token.trim()) {
      Alert.alert('Error', 'El token de verificación es requerido');
      return;
    }
    if (!config.access_token.trim()) {
      Alert.alert('Error', 'El token de acceso es requerido');
      return;
    }
    if (!config.phone_number_id.trim()) {
      Alert.alert('Error', 'El ID del número de teléfono es requerido');
      return;
    }

    try {
      setSaving(true);
      console.log('Saving WhatsApp config...', { hasId: !!config.id });

      if (config.id) {
        // Update existing config
        console.log('Updating existing config with ID:', config.id);
        const { error } = await supabase
          .from('whatsapp_config')
          .update({
            verify_token: config.verify_token,
            access_token: config.access_token,
            phone_number_id: config.phone_number_id,
            webhook_url: config.webhook_url,
            is_active: config.is_active,
            updated_at: new Date().toISOString(),
          })
          .eq('id', config.id);

        if (error) {
          console.error('Update error:', error);
          throw error;
        }
        console.log('Config updated successfully');
      } else {
        // Deactivate all existing configs first
        console.log('Deactivating existing configs...');
        const { error: deactivateError } = await supabase
          .from('whatsapp_config')
          .update({ is_active: false })
          .eq('is_active', true);

        if (deactivateError) {
          console.error('Deactivate error:', deactivateError);
        }

        // Insert new config
        console.log('Inserting new config...');
        const { data, error } = await supabase
          .from('whatsapp_config')
          .insert({
            verify_token: config.verify_token,
            access_token: config.access_token,
            phone_number_id: config.phone_number_id,
            webhook_url: config.webhook_url,
            is_active: true,
          })
          .select()
          .single();

        if (error) {
          console.error('Insert error:', error);
          throw error;
        }
        if (data) {
          console.log('Config inserted successfully with ID:', data.id);
          setConfig(data);
        }
      }

      Alert.alert(
        'Éxito',
        'La configuración de WhatsApp se ha guardado correctamente.\n\nRecuerda configurar el webhook en Meta for Developers con la URL proporcionada.',
        [{ text: 'OK' }]
      );
      
      // Reload config to ensure we have the latest data
      await loadConfig();
    } catch (error: any) {
      console.error('Error saving WhatsApp config:', error);
      const errorMessage = error?.message || 'No se pudo guardar la configuración';
      Alert.alert('Error', `No se pudo guardar la configuración: ${errorMessage}`);
    } finally {
      setSaving(false);
    }
  };

  const copyToClipboard = (text: string, label: string) => {
    Clipboard.setString(text);
    Alert.alert('Copiado', `${label} copiado al portapapeles`);
  };

  const handleTestConnection = () => {
    setShowTestModal(true);
  };

  const openURL = async (url: string, title: string) => {
    try {
      const supported = await Linking.canOpenURL(url);
      if (supported) {
        await Linking.openURL(url);
      } else {
        Alert.alert('Error', `No se puede abrir el enlace: ${title}`);
      }
    } catch (error) {
      console.error('Error opening URL:', error);
      Alert.alert('Error', 'No se pudo abrir el enlace');
    }
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={['top']}>
        <Stack.Screen
          options={{
            title: 'Configuración WhatsApp',
            headerBackTitle: 'Atrás',
          }}
        />
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={colors.primary} />
          <Text style={styles.loadingText}>Cargando configuración...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <Stack.Screen
        options={{
          title: 'Configuración WhatsApp',
          headerBackTitle: 'Atrás',
        }}
      />
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.keyboardView}
      >
        <ScrollView
          style={styles.scrollView}
          contentContainerStyle={styles.scrollContent}
          showsVerticalScrollIndicator={false}
        >
          {/* Info Banner */}
          <View style={styles.infoBanner}>
            <IconSymbol name="info.circle.fill" size={24} color={colors.info} />
            <Text style={styles.infoBannerText}>
              Configura las credenciales de WhatsApp Business API para recibir pedidos automáticamente.
            </Text>
          </View>

          {/* Webhook URL Section */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>URL del Webhook</Text>
            <Text style={styles.sectionDescription}>
              Configura esta URL en Meta for Developers
            </Text>
            <View style={styles.webhookContainer}>
              <Text style={styles.webhookUrl} numberOfLines={2}>
                {config.webhook_url}
              </Text>
              <Pressable
                style={styles.copyButton}
                onPress={() => copyToClipboard(config.webhook_url, 'URL del webhook')}
              >
                <IconSymbol name="doc.on.doc.fill" size={20} color={colors.primary} />
              </Pressable>
            </View>
          </View>

          {/* Verify Token */}
          <View style={styles.section}>
            <Text style={styles.label}>Token de Verificación *</Text>
            <Text style={styles.fieldDescription}>
              Token personalizado para verificar el webhook
            </Text>
            <View style={styles.inputContainer}>
              <TextInput
                style={styles.input}
                value={config.verify_token}
                onChangeText={(text) => setConfig({ ...config, verify_token: text })}
                placeholder="Ingresa tu token de verificación"
                placeholderTextColor={colors.textSecondary}
                secureTextEntry={!showTokens.verify}
                autoCapitalize="none"
                autoCorrect={false}
              />
              <Pressable
                style={styles.eyeButton}
                onPress={() => setShowTokens({ ...showTokens, verify: !showTokens.verify })}
              >
                <IconSymbol
                  name={showTokens.verify ? 'eye.slash.fill' : 'eye.fill'}
                  size={20}
                  color={colors.textSecondary}
                />
              </Pressable>
            </View>
          </View>

          {/* Access Token */}
          <View style={styles.section}>
            <Text style={styles.label}>Token de Acceso *</Text>
            <Text style={styles.fieldDescription}>
              Token de acceso de WhatsApp Business API
            </Text>
            <View style={styles.inputContainer}>
              <TextInput
                style={styles.input}
                value={config.access_token}
                onChangeText={(text) => setConfig({ ...config, access_token: text })}
                placeholder="Ingresa tu token de acceso"
                placeholderTextColor={colors.textSecondary}
                secureTextEntry={!showTokens.access}
                autoCapitalize="none"
                autoCorrect={false}
              />
              <Pressable
                style={styles.eyeButton}
                onPress={() => setShowTokens({ ...showTokens, access: !showTokens.access })}
              >
                <IconSymbol
                  name={showTokens.access ? 'eye.slash.fill' : 'eye.fill'}
                  size={20}
                  color={colors.textSecondary}
                />
              </Pressable>
            </View>
          </View>

          {/* Phone Number ID */}
          <View style={styles.section}>
            <Text style={styles.label}>ID del Número de Teléfono *</Text>
            <Text style={styles.fieldDescription}>
              ID del número de WhatsApp Business
            </Text>
            <TextInput
              style={styles.input}
              value={config.phone_number_id}
              onChangeText={(text) => setConfig({ ...config, phone_number_id: text })}
              placeholder="Ingresa el ID del número"
              placeholderTextColor={colors.textSecondary}
              autoCapitalize="none"
              autoCorrect={false}
              keyboardType="numeric"
            />
          </View>

          {/* Instructions */}
          <View style={styles.instructionsCard}>
            <View style={styles.instructionsHeader}>
              <IconSymbol name="book.fill" size={24} color={colors.warning} />
              <Text style={styles.instructionsTitle}>Instrucciones de Configuración</Text>
            </View>
            <View style={styles.instructionsList}>
              <View style={styles.instructionItem}>
                <Text style={styles.instructionNumber}>1.</Text>
                <Text style={styles.instructionText}>
                  Ve a Meta for Developers y accede a tu aplicación de WhatsApp Business
                </Text>
              </View>
              <View style={styles.instructionItem}>
                <Text style={styles.instructionNumber}>2.</Text>
                <Text style={styles.instructionText}>
                  Copia el Token de Acceso y el ID del Número de Teléfono
                </Text>
              </View>
              <View style={styles.instructionItem}>
                <Text style={styles.instructionNumber}>3.</Text>
                <Text style={styles.instructionText}>
                  Crea un Token de Verificación personalizado (cualquier texto seguro)
                </Text>
              </View>
              <View style={styles.instructionItem}>
                <Text style={styles.instructionNumber}>4.</Text>
                <Text style={styles.instructionText}>
                  Configura el webhook en Meta usando la URL proporcionada arriba
                </Text>
              </View>
              <View style={styles.instructionItem}>
                <Text style={styles.instructionNumber}>5.</Text>
                <Text style={styles.instructionText}>
                  Suscríbete a los eventos de mensajes en la configuración del webhook
                </Text>
              </View>
            </View>
          </View>

          {/* Action Buttons */}
          <View style={styles.buttonContainer}>
            <Pressable
              style={({ pressed }) => [
                styles.testButton,
                pressed && styles.buttonPressed,
              ]}
              onPress={handleTestConnection}
            >
              <IconSymbol name="checkmark.circle.fill" size={20} color={colors.info} />
              <Text style={styles.testButtonText}>Instrucciones de Prueba</Text>
            </Pressable>

            <Pressable
              style={({ pressed }) => [
                styles.saveButton,
                pressed && styles.buttonPressed,
                saving && styles.buttonDisabled,
              ]}
              onPress={handleSave}
              disabled={saving}
            >
              {saving ? (
                <ActivityIndicator size="small" color={colors.card} />
              ) : (
                <>
                  <IconSymbol name="checkmark.circle.fill" size={20} color={colors.card} />
                  <Text style={styles.saveButtonText}>Guardar Configuración</Text>
                </>
              )}
            </Pressable>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>

      {/* Test Instructions Modal */}
      <Modal
        visible={showTestModal}
        animationType="slide"
        presentationStyle="pageSheet"
        onRequestClose={() => setShowTestModal(false)}
      >
        <SafeAreaView style={styles.modalContainer} edges={['top']}>
          <View style={styles.modalHeader}>
            <Text style={styles.modalTitle}>Instrucciones de Prueba</Text>
            <Pressable
              style={styles.closeButton}
              onPress={() => setShowTestModal(false)}
            >
              <IconSymbol name="xmark.circle.fill" size={28} color={colors.textSecondary} />
            </Pressable>
          </View>

          <ScrollView
            style={styles.modalScrollView}
            contentContainerStyle={styles.modalContent}
            showsVerticalScrollIndicator={false}
          >
            {/* Prerequisites Section */}
            <View style={styles.testSection}>
              <View style={styles.testSectionHeader}>
                <IconSymbol name="exclamationmark.triangle.fill" size={24} color={colors.warning} />
                <Text style={styles.testSectionTitle}>Requisitos Previos</Text>
              </View>
              <View style={styles.testCard}>
                <Text style={styles.testCardText}>
                  ✓ Configuración guardada correctamente{'\n'}
                  ✓ Webhook configurado en Meta for Developers{'\n'}
                  ✓ Número de WhatsApp Business activo{'\n'}
                  ✓ Aplicación aprobada por Meta (si es necesario)
                </Text>
              </View>
            </View>

            {/* Test Steps Section */}
            <View style={styles.testSection}>
              <View style={styles.testSectionHeader}>
                <IconSymbol name="list.number" size={24} color={colors.primary} />
                <Text style={styles.testSectionTitle}>Pasos para Probar</Text>
              </View>

              <View style={styles.testStepCard}>
                <View style={styles.testStepHeader}>
                  <View style={styles.testStepBadge}>
                    <Text style={styles.testStepBadgeText}>1</Text>
                  </View>
                  <Text style={styles.testStepTitle}>Verificar Webhook</Text>
                </View>
                <Text style={styles.testStepDescription}>
                  En Meta for Developers, verifica que el webhook esté configurado y activo. 
                  Debe mostrar un estado "Verificado" o "Connected".
                </Text>
              </View>

              <View style={styles.testStepCard}>
                <View style={styles.testStepHeader}>
                  <View style={styles.testStepBadge}>
                    <Text style={styles.testStepBadgeText}>2</Text>
                  </View>
                  <Text style={styles.testStepTitle}>Enviar Mensaje de Prueba</Text>
                </View>
                <Text style={styles.testStepDescription}>
                  Desde tu teléfono personal, envía un mensaje al número de WhatsApp Business 
                  con el siguiente formato:
                </Text>
                <View style={styles.codeBlock}>
                  <Text style={styles.codeText}>
                    Pedido:{'\n'}
                    Cliente: Juan Pérez{'\n'}
                    Teléfono: +56912345678{'\n'}
                    Dirección: Av. Principal 123{'\n'}
                    Productos:{'\n'}
                    - 2kg Tomates{'\n'}
                    - 1kg Papas{'\n'}
                    - 500g Cebollas
                  </Text>
                </View>
                <Pressable
                  style={styles.copyCodeButton}
                  onPress={() => copyToClipboard(
                    'Pedido:\nCliente: Juan Pérez\nTeléfono: +56912345678\nDirección: Av. Principal 123\nProductos:\n- 2kg Tomates\n- 1kg Papas\n- 500g Cebollas',
                    'Mensaje de prueba'
                  )}
                >
                  <IconSymbol name="doc.on.doc.fill" size={16} color={colors.primary} />
                  <Text style={styles.copyCodeButtonText}>Copiar mensaje</Text>
                </Pressable>
              </View>

              <View style={styles.testStepCard}>
                <View style={styles.testStepHeader}>
                  <View style={styles.testStepBadge}>
                    <Text style={styles.testStepBadgeText}>3</Text>
                  </View>
                  <Text style={styles.testStepTitle}>Verificar Recepción</Text>
                </View>
                <Text style={styles.testStepDescription}>
                  El pedido debe aparecer automáticamente en la pantalla principal de la app 
                  con estado "Pendiente". Verifica que:
                </Text>
                <Text style={styles.testStepDescription}>
                  • El pedido se creó correctamente{'\n'}
                  • Los datos del cliente son correctos{'\n'}
                  • Los productos están listados{'\n'}
                  • El precio está en $0 (se agrega al cambiar a "En Preparación")
                </Text>
              </View>

              <View style={styles.testStepCard}>
                <View style={styles.testStepHeader}>
                  <View style={styles.testStepBadge}>
                    <Text style={styles.testStepBadgeText}>4</Text>
                  </View>
                  <Text style={styles.testStepTitle}>Probar Notificaciones</Text>
                </View>
                <Text style={styles.testStepDescription}>
                  Debes recibir una notificación push cuando llegue el nuevo pedido. 
                  Si no recibes notificaciones, verifica:
                </Text>
                <Text style={styles.testStepDescription}>
                  • Permisos de notificaciones habilitados{'\n'}
                  • Token de notificación registrado{'\n'}
                  • Dispositivo físico (no emulador)
                </Text>
              </View>

              <View style={styles.testStepCard}>
                <View style={styles.testStepHeader}>
                  <View style={styles.testStepBadge}>
                    <Text style={styles.testStepBadgeText}>5</Text>
                  </View>
                  <Text style={styles.testStepTitle}>Probar Impresión (Opcional)</Text>
                </View>
                <Text style={styles.testStepDescription}>
                  Si tienes una impresora Bluetooth configurada y la impresión automática 
                  está habilitada, el pedido debe imprimirse automáticamente.
                </Text>
              </View>
            </View>

            {/* Troubleshooting Section */}
            <View style={styles.testSection}>
              <View style={styles.testSectionHeader}>
                <IconSymbol name="wrench.and.screwdriver.fill" size={24} color={colors.error} />
                <Text style={styles.testSectionTitle}>Solución de Problemas</Text>
              </View>

              <View style={styles.troubleshootCard}>
                <Text style={styles.troubleshootTitle}>
                  ❌ El pedido no aparece en la app
                </Text>
                <Text style={styles.troubleshootText}>
                  • Verifica que el webhook esté configurado correctamente{'\n'}
                  • Revisa los logs de la Edge Function en Supabase{'\n'}
                  • Confirma que el token de acceso sea válido{'\n'}
                  • Asegúrate de que el mensaje tenga el formato correcto
                </Text>
              </View>

              <View style={styles.troubleshootCard}>
                <Text style={styles.troubleshootTitle}>
                  ❌ Error al guardar la configuración
                </Text>
                <Text style={styles.troubleshootText}>
                  • Verifica que todos los campos estén completos{'\n'}
                  • Confirma que tienes permisos de administrador{'\n'}
                  • Revisa la conexión a internet{'\n'}
                  • Intenta cerrar sesión y volver a entrar
                </Text>
              </View>

              <View style={styles.troubleshootCard}>
                <Text style={styles.troubleshootTitle}>
                  ❌ No recibo notificaciones
                </Text>
                <Text style={styles.troubleshootText}>
                  • Verifica los permisos de notificaciones en tu dispositivo{'\n'}
                  • Asegúrate de usar un dispositivo físico (no emulador){'\n'}
                  • Revisa que el token de notificación esté registrado{'\n'}
                  • Cierra y vuelve a abrir la app
                </Text>
              </View>
            </View>

            {/* Additional Resources Section - ENHANCED */}
            <View style={styles.testSection}>
              <View style={styles.testSectionHeader}>
                <IconSymbol name="link.circle.fill" size={24} color={colors.success} />
                <Text style={styles.testSectionTitle}>Recursos Adicionales</Text>
              </View>
              
              <Text style={styles.resourcesDescription}>
                Accede a documentación oficial y herramientas útiles para configurar y solucionar problemas:
              </Text>

              {/* WhatsApp Business API Documentation */}
              <Pressable
                style={({ pressed }) => [
                  styles.resourceLinkCard,
                  pressed && styles.resourceLinkPressed,
                ]}
                onPress={() => openURL(
                  'https://developers.facebook.com/docs/whatsapp/cloud-api',
                  'Documentación de WhatsApp Business API'
                )}
              >
                <View style={styles.resourceLinkIcon}>
                  <IconSymbol name="book.fill" size={24} color={colors.primary} />
                </View>
                <View style={styles.resourceLinkContent}>
                  <Text style={styles.resourceLinkTitle}>
                    Documentación de WhatsApp Business API
                  </Text>
                  <Text style={styles.resourceLinkDescription}>
                    Guía oficial completa de Meta para implementar WhatsApp Business Cloud API
                  </Text>
                </View>
                <IconSymbol name="chevron.right" size={20} color={colors.textSecondary} />
              </Pressable>

              {/* Meta for Developers Dashboard */}
              <Pressable
                style={({ pressed }) => [
                  styles.resourceLinkCard,
                  pressed && styles.resourceLinkPressed,
                ]}
                onPress={() => openURL(
                  'https://developers.facebook.com/apps',
                  'Panel de Meta for Developers'
                )}
              >
                <View style={styles.resourceLinkIcon}>
                  <IconSymbol name="square.grid.2x2.fill" size={24} color={colors.info} />
                </View>
                <View style={styles.resourceLinkContent}>
                  <Text style={styles.resourceLinkTitle}>
                    Panel de Meta for Developers
                  </Text>
                  <Text style={styles.resourceLinkDescription}>
                    Administra tus aplicaciones, tokens y configuración de webhooks
                  </Text>
                </View>
                <IconSymbol name="chevron.right" size={20} color={colors.textSecondary} />
              </Pressable>

              {/* Supabase Edge Functions Logs */}
              <Pressable
                style={({ pressed }) => [
                  styles.resourceLinkCard,
                  pressed && styles.resourceLinkPressed,
                ]}
                onPress={() => openURL(
                  'https://supabase.com/dashboard/project/stxrvyxkxclezgcijhio/functions',
                  'Logs de Supabase Edge Functions'
                )}
              >
                <View style={styles.resourceLinkIcon}>
                  <IconSymbol name="chart.bar.fill" size={24} color={colors.warning} />
                </View>
                <View style={styles.resourceLinkContent}>
                  <Text style={styles.resourceLinkTitle}>
                    Logs de Supabase Edge Functions
                  </Text>
                  <Text style={styles.resourceLinkDescription}>
                    Revisa los logs de la función whatsapp-webhook para depurar errores
                  </Text>
                </View>
                <IconSymbol name="chevron.right" size={20} color={colors.textSecondary} />
              </Pressable>

              {/* WhatsApp Business Manager */}
              <Pressable
                style={({ pressed }) => [
                  styles.resourceLinkCard,
                  pressed && styles.resourceLinkPressed,
                ]}
                onPress={() => openURL(
                  'https://business.facebook.com/wa/manage/home',
                  'WhatsApp Business Manager'
                )}
              >
                <View style={styles.resourceLinkIcon}>
                  <IconSymbol name="building.2.fill" size={24} color={colors.success} />
                </View>
                <View style={styles.resourceLinkContent}>
                  <Text style={styles.resourceLinkTitle}>
                    WhatsApp Business Manager
                  </Text>
                  <Text style={styles.resourceLinkDescription}>
                    Gestiona tu cuenta de WhatsApp Business y números de teléfono
                  </Text>
                </View>
                <IconSymbol name="chevron.right" size={20} color={colors.textSecondary} />
              </Pressable>

              {/* Webhook Setup Guide */}
              <Pressable
                style={({ pressed }) => [
                  styles.resourceLinkCard,
                  pressed && styles.resourceLinkPressed,
                ]}
                onPress={() => openURL(
                  'https://developers.facebook.com/docs/whatsapp/cloud-api/guides/set-up-webhooks',
                  'Guía de Configuración de Webhooks'
                )}
              >
                <View style={[styles.resourceLinkIcon, { backgroundColor: '#F3E8FF' }]}>
                  <IconSymbol name="link.circle.fill" size={24} color="#9333EA" />
                </View>
                <View style={styles.resourceLinkContent}>
                  <Text style={styles.resourceLinkTitle}>
                    Guía de Configuración de Webhooks
                  </Text>
                  <Text style={styles.resourceLinkDescription}>
                    Instrucciones paso a paso para configurar webhooks de WhatsApp
                  </Text>
                </View>
                <IconSymbol name="chevron.right" size={20} color={colors.textSecondary} />
              </Pressable>

              {/* Message Templates Guide */}
              <Pressable
                style={({ pressed }) => [
                  styles.resourceLinkCard,
                  pressed && styles.resourceLinkPressed,
                ]}
                onPress={() => openURL(
                  'https://developers.facebook.com/docs/whatsapp/cloud-api/guides/send-messages',
                  'Guía de Envío de Mensajes'
                )}
              >
                <View style={[styles.resourceLinkIcon, { backgroundColor: '#FCE7F3' }]}>
                  <IconSymbol name="envelope.fill" size={24} color="#EC4899" />
                </View>
                <View style={styles.resourceLinkContent}>
                  <Text style={styles.resourceLinkTitle}>
                    Guía de Envío de Mensajes
                  </Text>
                  <Text style={styles.resourceLinkDescription}>
                    Aprende a enviar mensajes y usar plantillas de WhatsApp Business
                  </Text>
                </View>
                <IconSymbol name="chevron.right" size={20} color={colors.textSecondary} />
              </Pressable>

              {/* API Reference */}
              <Pressable
                style={({ pressed }) => [
                  styles.resourceLinkCard,
                  pressed && styles.resourceLinkPressed,
                ]}
                onPress={() => openURL(
                  'https://developers.facebook.com/docs/whatsapp/cloud-api/reference',
                  'Referencia de API'
                )}
              >
                <View style={[styles.resourceLinkIcon, { backgroundColor: '#D1FAE5' }]}>
                  <IconSymbol name="doc.text.fill" size={24} color="#10B981" />
                </View>
                <View style={styles.resourceLinkContent}>
                  <Text style={styles.resourceLinkTitle}>
                    Referencia de API
                  </Text>
                  <Text style={styles.resourceLinkDescription}>
                    Documentación completa de endpoints y parámetros de la API
                  </Text>
                </View>
                <IconSymbol name="chevron.right" size={20} color={colors.textSecondary} />
              </Pressable>

              {/* Support and Community */}
              <Pressable
                style={({ pressed }) => [
                  styles.resourceLinkCard,
                  pressed && styles.resourceLinkPressed,
                ]}
                onPress={() => openURL(
                  'https://developers.facebook.com/community/whatsapp-business',
                  'Comunidad de Desarrolladores'
                )}
              >
                <View style={[styles.resourceLinkIcon, { backgroundColor: '#FEF3C7' }]}>
                  <IconSymbol name="person.3.fill" size={24} color="#F59E0B" />
                </View>
                <View style={styles.resourceLinkContent}>
                  <Text style={styles.resourceLinkTitle}>
                    Comunidad de Desarrolladores
                  </Text>
                  <Text style={styles.resourceLinkDescription}>
                    Únete a la comunidad para obtener ayuda y compartir experiencias
                  </Text>
                </View>
                <IconSymbol name="chevron.right" size={20} color={colors.textSecondary} />
              </Pressable>

              {/* Quick Reference Card */}
              <View style={styles.quickReferenceCard}>
                <View style={styles.quickReferenceHeader}>
                  <IconSymbol name="lightbulb.fill" size={20} color={colors.warning} />
                  <Text style={styles.quickReferenceTitle}>Referencia Rápida</Text>
                </View>
                <View style={styles.quickReferenceContent}>
                  <View style={styles.quickReferenceItem}>
                    <Text style={styles.quickReferenceLabel}>Webhook URL:</Text>
                    <Pressable
                      onPress={() => copyToClipboard(config.webhook_url, 'Webhook URL')}
                    >
                      <Text style={styles.quickReferenceValue} numberOfLines={1}>
                        {config.webhook_url}
                      </Text>
                    </Pressable>
                  </View>
                  <View style={styles.quickReferenceItem}>
                    <Text style={styles.quickReferenceLabel}>Eventos requeridos:</Text>
                    <Text style={styles.quickReferenceValue}>
                      messages, message_status
                    </Text>
                  </View>
                  <View style={styles.quickReferenceItem}>
                    <Text style={styles.quickReferenceLabel}>Método HTTP:</Text>
                    <Text style={styles.quickReferenceValue}>
                      POST
                    </Text>
                  </View>
                </View>
              </View>
            </View>

            {/* Success Indicator */}
            <View style={styles.successCard}>
              <IconSymbol name="checkmark.seal.fill" size={32} color={colors.success} />
              <Text style={styles.successTitle}>¡Prueba Exitosa!</Text>
              <Text style={styles.successText}>
                Si completaste todos los pasos y el pedido apareció correctamente en la app, 
                tu integración de WhatsApp está funcionando perfectamente.
              </Text>
            </View>
          </ScrollView>

          <View style={styles.modalFooter}>
            <Pressable
              style={({ pressed }) => [
                styles.closeModalButton,
                pressed && styles.buttonPressed,
              ]}
              onPress={() => setShowTestModal(false)}
            >
              <Text style={styles.closeModalButtonText}>Cerrar</Text>
            </Pressable>
          </View>
        </SafeAreaView>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  keyboardView: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
    paddingBottom: 40,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    marginTop: 12,
    fontSize: 16,
    color: colors.textSecondary,
  },
  infoBanner: {
    flexDirection: 'row',
    backgroundColor: colors.highlight,
    borderRadius: 12,
    padding: 16,
    marginBottom: 24,
    gap: 12,
  },
  infoBannerText: {
    flex: 1,
    fontSize: 14,
    color: colors.info,
    lineHeight: 20,
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: colors.text,
    marginBottom: 4,
  },
  sectionDescription: {
    fontSize: 14,
    color: colors.textSecondary,
    marginBottom: 12,
  },
  webhookContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 16,
    gap: 12,
  },
  webhookUrl: {
    flex: 1,
    fontSize: 13,
    color: colors.text,
    fontFamily: Platform.OS === 'ios' ? 'Courier' : 'monospace',
  },
  copyButton: {
    padding: 8,
  },
  label: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 4,
  },
  fieldDescription: {
    fontSize: 13,
    color: colors.textSecondary,
    marginBottom: 8,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.card,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: colors.border,
  },
  input: {
    flex: 1,
    fontSize: 16,
    color: colors.text,
    padding: 16,
  },
  eyeButton: {
    padding: 16,
  },
  instructionsCard: {
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 20,
    marginBottom: 24,
    borderWidth: 1,
    borderColor: colors.warning + '30',
  },
  instructionsHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 16,
  },
  instructionsTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: colors.text,
  },
  instructionsList: {
    gap: 12,
  },
  instructionItem: {
    flexDirection: 'row',
    gap: 12,
  },
  instructionNumber: {
    fontSize: 16,
    fontWeight: '700',
    color: colors.warning,
    width: 24,
  },
  instructionText: {
    flex: 1,
    fontSize: 14,
    color: colors.text,
    lineHeight: 20,
  },
  buttonContainer: {
    gap: 12,
  },
  testButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 16,
    gap: 8,
    borderWidth: 2,
    borderColor: colors.info,
  },
  testButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.info,
  },
  saveButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.primary,
    borderRadius: 12,
    padding: 16,
    gap: 8,
    boxShadow: '0px 4px 12px rgba(0, 123, 255, 0.3)',
    elevation: 4,
  },
  saveButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.card,
  },
  buttonPressed: {
    opacity: 0.7,
    transform: [{ scale: 0.98 }],
  },
  buttonDisabled: {
    opacity: 0.5,
  },
  // Modal Styles
  modalContainer: {
    flex: 1,
    backgroundColor: colors.background,
  },
  modalHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  modalTitle: {
    fontSize: 24,
    fontWeight: '700',
    color: colors.text,
  },
  closeButton: {
    padding: 4,
  },
  modalScrollView: {
    flex: 1,
  },
  modalContent: {
    padding: 20,
    paddingBottom: 40,
  },
  testSection: {
    marginBottom: 32,
  },
  testSectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 16,
  },
  testSectionTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: colors.text,
  },
  testCard: {
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: colors.warning + '30',
  },
  testCardText: {
    fontSize: 15,
    color: colors.text,
    lineHeight: 24,
  },
  testStepCard: {
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: colors.border,
  },
  testStepHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 12,
  },
  testStepBadge: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  testStepBadgeText: {
    fontSize: 16,
    fontWeight: '700',
    color: colors.card,
  },
  testStepTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
    flex: 1,
  },
  testStepDescription: {
    fontSize: 15,
    color: colors.text,
    lineHeight: 22,
    marginBottom: 8,
  },
  codeBlock: {
    backgroundColor: colors.background,
    borderRadius: 8,
    padding: 12,
    marginTop: 8,
    marginBottom: 8,
    borderWidth: 1,
    borderColor: colors.border,
  },
  codeText: {
    fontSize: 13,
    color: colors.text,
    fontFamily: Platform.OS === 'ios' ? 'Courier' : 'monospace',
    lineHeight: 20,
  },
  copyCodeButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingVertical: 8,
    paddingHorizontal: 12,
    backgroundColor: colors.primary + '20',
    borderRadius: 8,
    alignSelf: 'flex-start',
  },
  copyCodeButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.primary,
  },
  troubleshootCard: {
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: colors.error + '30',
  },
  troubleshootTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.error,
    marginBottom: 8,
  },
  troubleshootText: {
    fontSize: 14,
    color: colors.text,
    lineHeight: 22,
  },
  // Enhanced Additional Resources Styles
  resourcesDescription: {
    fontSize: 15,
    color: colors.textSecondary,
    lineHeight: 22,
    marginBottom: 16,
  },
  resourceLinkCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: colors.border,
    gap: 12,
  },
  resourceLinkPressed: {
    opacity: 0.7,
    transform: [{ scale: 0.98 }],
  },
  resourceLinkIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: colors.background,
    alignItems: 'center',
    justifyContent: 'center',
  },
  resourceLinkContent: {
    flex: 1,
  },
  resourceLinkTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 4,
  },
  resourceLinkDescription: {
    fontSize: 13,
    color: colors.textSecondary,
    lineHeight: 18,
  },
  quickReferenceCard: {
    backgroundColor: colors.warning + '15',
    borderRadius: 12,
    padding: 16,
    marginTop: 8,
    borderWidth: 1,
    borderColor: colors.warning + '30',
  },
  quickReferenceHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
  },
  quickReferenceTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.text,
  },
  quickReferenceContent: {
    gap: 8,
  },
  quickReferenceItem: {
    gap: 4,
  },
  quickReferenceLabel: {
    fontSize: 13,
    fontWeight: '600',
    color: colors.textSecondary,
  },
  quickReferenceValue: {
    fontSize: 14,
    color: colors.text,
    fontFamily: Platform.OS === 'ios' ? 'Courier' : 'monospace',
  },
  successCard: {
    backgroundColor: colors.success + '20',
    borderRadius: 12,
    padding: 20,
    alignItems: 'center',
    borderWidth: 2,
    borderColor: colors.success,
  },
  successTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: colors.success,
    marginTop: 12,
    marginBottom: 8,
  },
  successText: {
    fontSize: 15,
    color: colors.text,
    textAlign: 'center',
    lineHeight: 22,
  },
  modalFooter: {
    padding: 20,
    borderTopWidth: 1,
    borderTopColor: colors.border,
  },
  closeModalButton: {
    backgroundColor: colors.primary,
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    boxShadow: '0px 4px 12px rgba(0, 123, 255, 0.3)',
    elevation: 4,
  },
  closeModalButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.card,
  },
});

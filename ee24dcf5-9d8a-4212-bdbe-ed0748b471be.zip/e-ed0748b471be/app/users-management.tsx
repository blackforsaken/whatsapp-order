
import React, { useState, useEffect, useCallback } from 'react';
import { Stack, useRouter } from 'expo-router';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Pressable,
  Alert,
  ActivityIndicator,
  TextInput,
  Modal,
  RefreshControl,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { IconSymbol } from '@/components/IconSymbol';
import { colors } from '@/styles/commonStyles';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase';

interface User {
  id: string;
  email: string;
  full_name: string | null;
  role: 'admin' | 'manager' | 'operator' | 'viewer';
  phone: string | null;
  is_active: boolean;
  created_at: string;
}

const roleLabels: Record<string, string> = {
  admin: 'Administrador',
  manager: 'Gerente',
  operator: 'Operador',
  viewer: 'Visualizador',
};

const roleColors: Record<string, string> = {
  admin: '#F44336',
  manager: '#FF9800',
  operator: '#4CAF50',
  viewer: '#2196F3',
};

export default function UsersManagementScreen() {
  const { profile } = useAuth();
  const router = useRouter();
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [showEditModal, setShowEditModal] = useState(false);
  const [editingRole, setEditingRole] = useState<string>('');

  const loadUsers = useCallback(async () => {
    try {
      console.log('Loading users...');
      setLoading(true);
      
      // Simple query without complex joins
      const { data, error } = await supabase
        .from('profiles')
        .select('id, email, full_name, role, phone, is_active, created_at')
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error loading users:', error);
        throw error;
      }

      console.log('Users loaded successfully:', data?.length || 0);
      setUsers(data || []);
    } catch (error: any) {
      console.error('Error loading users:', error);
      Alert.alert(
        'Error', 
        error.message || 'No se pudieron cargar los usuarios. Por favor intenta de nuevo.'
      );
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useEffect(() => {
    if (profile?.role !== 'admin' && profile?.role !== 'manager') {
      Alert.alert('Acceso Denegado', 'Solo los administradores y gerentes pueden acceder a esta pantalla');
      router.back();
      return;
    }
    loadUsers();
  }, [profile, router, loadUsers]);

  const onRefresh = useCallback(() => {
    setRefreshing(true);
    loadUsers();
  }, [loadUsers]);

  const handleEditUser = (user: User) => {
    setSelectedUser(user);
    setEditingRole(user.role);
    setShowEditModal(true);
  };

  const handleSaveUser = async () => {
    if (!selectedUser) return;

    try {
      console.log('Updating user role:', selectedUser.email, 'to', editingRole);
      
      const { error } = await supabase
        .from('profiles')
        .update({ role: editingRole })
        .eq('id', selectedUser.id);

      if (error) {
        console.error('Error updating user:', error);
        throw error;
      }

      Alert.alert('Éxito', 'Usuario actualizado correctamente');
      setShowEditModal(false);
      loadUsers();
    } catch (error: any) {
      console.error('Error updating user:', error);
      Alert.alert('Error', error.message || 'No se pudo actualizar el usuario');
    }
  };

  const handleToggleActive = async (user: User) => {
    try {
      console.log('Toggling user active status:', user.email);
      
      const { error } = await supabase
        .from('profiles')
        .update({ is_active: !user.is_active })
        .eq('id', user.id);

      if (error) {
        console.error('Error toggling user active status:', error);
        throw error;
      }

      Alert.alert(
        'Éxito',
        `Usuario ${!user.is_active ? 'activado' : 'desactivado'} correctamente`
      );
      loadUsers();
    } catch (error: any) {
      console.error('Error toggling user active status:', error);
      Alert.alert('Error', error.message || 'No se pudo actualizar el estado del usuario');
    }
  };

  const filteredUsers = users.filter(
    user =>
      user.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.full_name?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const renderHeaderRight = () => (
    <Pressable onPress={loadUsers} style={{ marginRight: 16 }}>
      <IconSymbol name="arrow.clockwise" size={24} color={colors.text} />
    </Pressable>
  );

  if (loading && !refreshing) {
    return (
      <SafeAreaView style={styles.container}>
        <Stack.Screen
          options={{
            title: 'Gestión de Usuarios',
            headerStyle: { backgroundColor: colors.background },
            headerTintColor: colors.text,
          }}
        />
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={colors.primary} />
          <Text style={styles.loadingText}>Cargando usuarios...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <Stack.Screen
        options={{
          title: 'Gestión de Usuarios',
          headerStyle: { backgroundColor: colors.background },
          headerTintColor: colors.text,
          headerRight: renderHeaderRight,
        }}
      />

      <View style={styles.searchContainer}>
        <IconSymbol name="magnifyingglass" size={20} color={colors.textSecondary} />
        <TextInput
          style={styles.searchInput}
          placeholder="Buscar usuarios..."
          placeholderTextColor={colors.textSecondary}
          value={searchQuery}
          onChangeText={setSearchQuery}
        />
      </View>

      <ScrollView 
        style={styles.scrollView}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            tintColor={colors.primary}
            colors={[colors.primary]}
          />
        }
      >
        <View style={styles.statsContainer}>
          <View style={styles.statCard}>
            <Text style={styles.statNumber}>{users.length}</Text>
            <Text style={styles.statLabel}>Total Usuarios</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statNumber}>
              {users.filter(u => u.is_active).length}
            </Text>
            <Text style={styles.statLabel}>Activos</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statNumber}>
              {users.filter(u => u.role === 'admin').length}
            </Text>
            <Text style={styles.statLabel}>Admins</Text>
          </View>
        </View>

        <View style={styles.usersContainer}>
          {filteredUsers.map(user => (
            <View key={user.id} style={styles.userCard}>
              <View style={styles.userHeader}>
                <View style={styles.userInfo}>
                  <View style={styles.userNameRow}>
                    <Text style={styles.userName}>
                      {user.full_name || 'Sin nombre'}
                    </Text>
                    {!user.is_active && (
                      <View style={styles.inactiveBadge}>
                        <Text style={styles.inactiveBadgeText}>Inactivo</Text>
                      </View>
                    )}
                  </View>
                  <Text style={styles.userEmail}>{user.email}</Text>
                  {user.phone && (
                    <Text style={styles.userPhone}>{user.phone}</Text>
                  )}
                </View>
                <View
                  style={[
                    styles.roleBadge,
                    { backgroundColor: roleColors[user.role] },
                  ]}
                >
                  <Text style={styles.roleBadgeText}>
                    {roleLabels[user.role]}
                  </Text>
                </View>
              </View>

              {profile?.role === 'admin' && (
                <View style={styles.userActions}>
                  <Pressable
                    style={styles.actionButton}
                    onPress={() => handleEditUser(user)}
                  >
                    <IconSymbol name="pencil" size={20} color={colors.primary} />
                    <Text style={styles.actionButtonText}>Editar Rol</Text>
                  </Pressable>

                  <Pressable
                    style={[
                      styles.actionButton,
                      !user.is_active && styles.actionButtonActive,
                    ]}
                    onPress={() => handleToggleActive(user)}
                  >
                    <IconSymbol
                      name={user.is_active ? 'xmark.circle' : 'checkmark.circle'}
                      size={20}
                      color={user.is_active ? colors.error : colors.success}
                    />
                    <Text
                      style={[
                        styles.actionButtonText,
                        { color: user.is_active ? colors.error : colors.success },
                      ]}
                    >
                      {user.is_active ? 'Desactivar' : 'Activar'}
                    </Text>
                  </Pressable>
                </View>
              )}
            </View>
          ))}
        </View>
      </ScrollView>

      <Modal
        visible={showEditModal}
        transparent
        animationType="slide"
        onRequestClose={() => setShowEditModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Editar Rol de Usuario</Text>
              <Pressable onPress={() => setShowEditModal(false)}>
                <IconSymbol name="xmark" size={24} color={colors.text} />
              </Pressable>
            </View>

            {selectedUser && (
              <>
                <View style={styles.modalUserInfo}>
                  <Text style={styles.modalUserName}>
                    {selectedUser.full_name || 'Sin nombre'}
                  </Text>
                  <Text style={styles.modalUserEmail}>{selectedUser.email}</Text>
                </View>

                <Text style={styles.modalLabel}>Seleccionar Rol:</Text>

                {Object.entries(roleLabels).map(([role, label]) => (
                  <Pressable
                    key={role}
                    style={[
                      styles.roleOption,
                      editingRole === role && styles.roleOptionSelected,
                    ]}
                    onPress={() => setEditingRole(role)}
                  >
                    <View
                      style={[
                        styles.roleOptionBadge,
                        { backgroundColor: roleColors[role] },
                      ]}
                    >
                      <Text style={styles.roleOptionBadgeText}>{label}</Text>
                    </View>
                    {editingRole === role && (
                      <IconSymbol
                        name="checkmark.circle.fill"
                        size={24}
                        color={colors.success}
                      />
                    )}
                  </Pressable>
                ))}

                <View style={styles.modalActions}>
                  <Pressable
                    style={[styles.modalButton, styles.modalButtonCancel]}
                    onPress={() => setShowEditModal(false)}
                  >
                    <Text style={styles.modalButtonTextCancel}>Cancelar</Text>
                  </Pressable>
                  <Pressable
                    style={[styles.modalButton, styles.modalButtonSave]}
                    onPress={handleSaveUser}
                  >
                    <Text style={styles.modalButtonTextSave}>Guardar</Text>
                  </Pressable>
                </View>
              </>
            )}
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    marginTop: 12,
    fontSize: 16,
    color: colors.textSecondary,
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.card,
    margin: 16,
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 12,
    gap: 12,
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
    color: colors.text,
  },
  scrollView: {
    flex: 1,
  },
  statsContainer: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    gap: 12,
    marginBottom: 16,
  },
  statCard: {
    flex: 1,
    backgroundColor: colors.card,
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  statNumber: {
    fontSize: 28,
    fontWeight: 'bold',
    color: colors.primary,
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 12,
    color: colors.textSecondary,
  },
  usersContainer: {
    paddingHorizontal: 16,
    paddingBottom: 16,
  },
  userCard: {
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
  },
  userHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  userInfo: {
    flex: 1,
    marginRight: 12,
  },
  userNameRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 4,
  },
  userName: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
  },
  inactiveBadge: {
    backgroundColor: colors.error + '20',
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 4,
  },
  inactiveBadgeText: {
    fontSize: 10,
    color: colors.error,
    fontWeight: '600',
  },
  userEmail: {
    fontSize: 14,
    color: colors.textSecondary,
    marginBottom: 2,
  },
  userPhone: {
    fontSize: 14,
    color: colors.textSecondary,
  },
  roleBadge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8,
  },
  roleBadgeText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#FFFFFF',
  },
  userActions: {
    flexDirection: 'row',
    gap: 12,
    borderTopWidth: 1,
    borderTopColor: colors.border,
    paddingTop: 12,
  },
  actionButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 8,
    backgroundColor: colors.background,
  },
  actionButtonActive: {
    backgroundColor: colors.success + '10',
  },
  actionButtonText: {
    fontSize: 14,
    fontWeight: '500',
    color: colors.primary,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: colors.background,
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    padding: 24,
    maxHeight: '80%',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 24,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: colors.text,
  },
  modalUserInfo: {
    backgroundColor: colors.card,
    padding: 16,
    borderRadius: 12,
    marginBottom: 24,
  },
  modalUserName: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 4,
  },
  modalUserEmail: {
    fontSize: 14,
    color: colors.textSecondary,
  },
  modalLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 12,
  },
  roleOption: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: colors.card,
    padding: 16,
    borderRadius: 12,
    marginBottom: 8,
  },
  roleOptionSelected: {
    borderWidth: 2,
    borderColor: colors.success,
  },
  roleOptionBadge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8,
  },
  roleOptionBadgeText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#FFFFFF',
  },
  modalActions: {
    flexDirection: 'row',
    gap: 12,
    marginTop: 24,
  },
  modalButton: {
    flex: 1,
    paddingVertical: 14,
    borderRadius: 12,
    alignItems: 'center',
  },
  modalButtonCancel: {
    backgroundColor: colors.card,
  },
  modalButtonSave: {
    backgroundColor: colors.primary,
  },
  modalButtonTextCancel: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.text,
  },
  modalButtonTextSave: {
    fontSize: 16,
    fontWeight: '600',
    color: '#FFFFFF',
  },
});

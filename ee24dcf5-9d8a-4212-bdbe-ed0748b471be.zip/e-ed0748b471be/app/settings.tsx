
import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Pressable,
  Switch,
  Alert,
  Platform,
  Linking,
  Modal,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Stack, useRouter } from 'expo-router';
import { IconSymbol } from '@/components/IconSymbol';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { useTheme } from '@/contexts/ThemeContext';
import { NotificationService } from '@/services/NotificationService';
import * as Notifications from 'expo-notifications';
import Constants from 'expo-constants';

interface AppSettings {
  notifications_enabled: boolean;
  sound_enabled: boolean;
  vibration_enabled: boolean;
  auto_print_enabled: boolean;
  language: 'es' | 'en';
}

export default function SettingsScreen() {
  const router = useRouter();
  const { user, profile } = useAuth();
  const { theme, themeMode, setThemeMode, colors } = useTheme();
  const [loading, setLoading] = useState(true);
  const [showLanguageModal, setShowLanguageModal] = useState(false);
  const [showAboutModal, setShowAboutModal] = useState(false);
  const [settings, setSettings] = useState<AppSettings>({
    notifications_enabled: true,
    sound_enabled: true,
    vibration_enabled: true,
    auto_print_enabled: false,
    language: 'es',
  });

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    try {
      setLoading(true);
      
      // Load settings from Supabase
      const { data, error } = await supabase
        .from('user_settings')
        .select('*')
        .eq('user_id', user?.id)
        .maybeSingle();

      if (error && error.code !== 'PGRST116') {
        throw error;
      }

      if (data) {
        setSettings({
          notifications_enabled: data.notifications_enabled ?? true,
          sound_enabled: data.sound_enabled ?? true,
          vibration_enabled: data.vibration_enabled ?? true,
          auto_print_enabled: data.auto_print_enabled ?? false,
          language: data.language ?? 'es',
        });
      }
    } catch (error) {
      console.error('Error loading settings:', error);
    } finally {
      setLoading(false);
    }
  };

  const saveSettings = async (newSettings: Partial<AppSettings>) => {
    try {
      const updatedSettings = { ...settings, ...newSettings };
      setSettings(updatedSettings);

      const { error } = await supabase
        .from('user_settings')
        .upsert({
          user_id: user?.id,
          ...updatedSettings,
          updated_at: new Date().toISOString(),
        });

      if (error) throw error;
    } catch (error) {
      console.error('Error saving settings:', error);
      Alert.alert('Error', 'No se pudieron guardar los ajustes');
    }
  };

  const handleNotificationsToggle = async (value: boolean) => {
    try {
      console.log('Toggling notifications to:', value);

      if (value) {
        // Check if push notifications are supported
        if (!NotificationService.isPushNotificationSupported()) {
          console.log('Push notifications not supported in this environment');
          
          // Show Expo Go limitation message
          NotificationService.showExpoGoLimitation();
          
          // Don't enable the setting
          return;
        }

        // Check if we have permission
        const { status: existingStatus } = await Notifications.getPermissionsAsync();
        let finalStatus = existingStatus;

        if (existingStatus !== 'granted') {
          const { status } = await Notifications.requestPermissionsAsync();
          finalStatus = status;
        }

        if (finalStatus !== 'granted') {
          Alert.alert(
            'Permisos Requeridos',
            'Para habilitar las notificaciones, debes otorgar permisos en la configuración de tu dispositivo.',
            [
              { text: 'Cancelar', style: 'cancel' },
              { text: 'Abrir Configuración', onPress: () => Linking.openSettings() },
            ]
          );
          return;
        }

        // Register for push notifications
        const token = await NotificationService.registerForPushNotifications();
        
        if (token) {
          console.log('Successfully registered for push notifications');
          await saveSettings({ notifications_enabled: true });
          Alert.alert(
            'Notificaciones Habilitadas',
            'Recibirás notificaciones de nuevos pedidos y cambios de estado.'
          );
        } else {
          console.log('Failed to register for push notifications');
          Alert.alert(
            'Error',
            'No se pudo registrar el dispositivo para notificaciones push. Verifica que estés usando una compilación de desarrollo.'
          );
        }
      } else {
        // Disable notifications
        await saveSettings({ notifications_enabled: false });
        
        // Optionally remove push token
        if (user?.id) {
          await NotificationService.removePushToken(user.id);
        }
        
        Alert.alert(
          'Notificaciones Deshabilitadas',
          'Ya no recibirás notificaciones push.'
        );
      }
    } catch (error) {
      console.error('Error toggling notifications:', error);
      
      // Check if it's an Expo Go limitation error
      if (error instanceof Error && error.message.includes('Expo Go')) {
        NotificationService.showExpoGoLimitation();
      } else {
        Alert.alert(
          'Error',
          'Ocurrió un error al cambiar la configuración de notificaciones. Por favor, intenta de nuevo.'
        );
      }
    }
  };

  const handleSoundToggle = async (value: boolean) => {
    await saveSettings({ sound_enabled: value });
  };

  const handleVibrationToggle = async (value: boolean) => {
    await saveSettings({ vibration_enabled: value });
  };

  const handleAutoPrintToggle = async (value: boolean) => {
    await saveSettings({ auto_print_enabled: value });
  };

  const handleDarkModeToggle = async (value: boolean) => {
    // Toggle between dark and light mode
    const newMode = value ? 'dark' : 'light';
    await setThemeMode(newMode);
  };

  const handleLanguageChange = (language: 'es' | 'en') => {
    Alert.alert(
      'Próximamente',
      'El cambio de idioma estará disponible en una próxima actualización.',
      [{ text: 'OK' }]
    );
    setShowLanguageModal(false);
    // await saveSettings({ language });
  };

  const handleClearCache = () => {
    Alert.alert(
      'Limpiar Caché',
      '¿Estás seguro de que deseas limpiar la caché de la aplicación?',
      [
        { text: 'Cancelar', style: 'cancel' },
        {
          text: 'Limpiar',
          style: 'destructive',
          onPress: () => {
            // Clear cache logic here
            Alert.alert('Éxito', 'La caché se ha limpiado correctamente');
          },
        },
      ]
    );
  };

  const handleResetSettings = () => {
    Alert.alert(
      'Restablecer Ajustes',
      '¿Estás seguro de que deseas restablecer todos los ajustes a sus valores predeterminados?',
      [
        { text: 'Cancelar', style: 'cancel' },
        {
          text: 'Restablecer',
          style: 'destructive',
          onPress: async () => {
            const defaultSettings: AppSettings = {
              notifications_enabled: true,
              sound_enabled: true,
              vibration_enabled: true,
              auto_print_enabled: false,
              language: 'es',
            };
            await saveSettings(defaultSettings);
            await setThemeMode('system');
            Alert.alert('Éxito', 'Los ajustes se han restablecido correctamente');
          },
        },
      ]
    );
  };

  const openPrivacyPolicy = () => {
    Alert.alert(
      'Política de Privacidad',
      'La política de privacidad estará disponible próximamente.',
      [{ text: 'OK' }]
    );
  };

  const openTermsOfService = () => {
    Alert.alert(
      'Términos de Servicio',
      'Los términos de servicio estarán disponibles próximamente.',
      [{ text: 'OK' }]
    );
  };

  const getLanguageText = (lang: string): string => {
    switch (lang) {
      case 'es':
        return 'Español';
      case 'en':
        return 'English';
      default:
        return 'Español';
    }
  };

  const getThemeModeText = (): string => {
    switch (themeMode) {
      case 'light':
        return 'Claro';
      case 'dark':
        return 'Oscuro';
      case 'system':
        return 'Sistema';
      default:
        return 'Sistema';
    }
  };

  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: colors.background,
    },
    scrollView: {
      flex: 1,
    },
    scrollContent: {
      paddingBottom: Platform.OS === 'ios' ? 20 : 100,
    },
    section: {
      paddingHorizontal: 20,
      marginTop: 24,
    },
    sectionTitle: {
      fontSize: 13,
      fontWeight: '700',
      color: colors.textSecondary,
      marginBottom: 12,
      letterSpacing: 0.5,
    },
    settingCard: {
      backgroundColor: colors.card,
      borderRadius: 12,
      marginBottom: 8,
      overflow: 'hidden',
    },
    settingCardPressed: {
      opacity: 0.7,
      transform: [{ scale: 0.98 }],
    },
    settingRow: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: 16,
    },
    settingLeft: {
      flexDirection: 'row',
      alignItems: 'center',
      flex: 1,
      gap: 12,
    },
    settingTextContainer: {
      flex: 1,
    },
    settingLabel: {
      fontSize: 16,
      fontWeight: '500',
      color: colors.text,
    },
    settingDescription: {
      fontSize: 13,
      color: colors.textSecondary,
      marginTop: 2,
    },
    settingValue: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 8,
    },
    settingValueText: {
      fontSize: 15,
      color: colors.textSecondary,
    },
    userInfoCard: {
      backgroundColor: colors.card,
      borderRadius: 12,
      padding: 16,
      marginHorizontal: 20,
      marginTop: 24,
      marginBottom: 24,
      gap: 12,
    },
    userInfoRow: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
    },
    userInfoLabel: {
      fontSize: 14,
      color: colors.textSecondary,
      fontWeight: '500',
    },
    userInfoValue: {
      fontSize: 14,
      color: colors.text,
      fontWeight: '600',
    },
    // Modal Styles
    modalContainer: {
      flex: 1,
      backgroundColor: colors.background,
    },
    modalHeader: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'space-between',
      paddingHorizontal: 20,
      paddingVertical: 16,
      borderBottomWidth: 1,
      borderBottomColor: colors.border,
    },
    modalTitle: {
      fontSize: 24,
      fontWeight: '700',
      color: colors.text,
    },
    closeButton: {
      padding: 4,
    },
    modalScrollView: {
      flex: 1,
    },
    modalContent: {
      padding: 20,
    },
    // Language Modal
    languageOption: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'space-between',
      backgroundColor: colors.card,
      borderRadius: 12,
      padding: 16,
      marginBottom: 12,
      borderWidth: 2,
      borderColor: 'transparent',
    },
    languageOptionSelected: {
      borderColor: colors.primary,
      backgroundColor: colors.primary + '10',
    },
    languageOptionPressed: {
      opacity: 0.7,
      transform: [{ scale: 0.98 }],
    },
    languageOptionLeft: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 12,
    },
    languageFlag: {
      fontSize: 32,
    },
    languageOptionText: {
      fontSize: 18,
      fontWeight: '600',
      color: colors.text,
    },
    comingSoonBanner: {
      flexDirection: 'row',
      alignItems: 'center',
      backgroundColor: colors.warning + '20',
      borderRadius: 12,
      padding: 16,
      marginTop: 12,
      gap: 12,
    },
    comingSoonText: {
      flex: 1,
      fontSize: 14,
      color: colors.warning,
      lineHeight: 20,
    },
    // About Modal
    aboutHeader: {
      alignItems: 'center',
      paddingVertical: 24,
    },
    aboutIcon: {
      width: 96,
      height: 96,
      borderRadius: 48,
      backgroundColor: colors.primary + '20',
      alignItems: 'center',
      justifyContent: 'center',
      marginBottom: 16,
    },
    aboutAppName: {
      fontSize: 28,
      fontWeight: '700',
      color: colors.text,
      marginBottom: 8,
    },
    aboutVersion: {
      fontSize: 16,
      color: colors.textSecondary,
    },
    aboutSection: {
      marginBottom: 24,
    },
    aboutSectionTitle: {
      fontSize: 18,
      fontWeight: '700',
      color: colors.text,
      marginBottom: 12,
    },
    aboutText: {
      fontSize: 15,
      color: colors.text,
      lineHeight: 22,
    },
    featureList: {
      gap: 12,
    },
    featureItem: {
      flexDirection: 'row',
      alignItems: 'flex-start',
      gap: 12,
    },
    featureText: {
      flex: 1,
      fontSize: 15,
      color: colors.text,
      lineHeight: 22,
    },
    aboutFooter: {
      paddingTop: 24,
      borderTopWidth: 1,
      borderTopColor: colors.border,
      alignItems: 'center',
    },
    aboutCopyright: {
      fontSize: 13,
      color: colors.textSecondary,
      textAlign: 'center',
    },
  });

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <Stack.Screen
        options={{
          title: 'Ajustes',
          headerBackTitle: 'Atrás',
        }}
      />

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {/* General Settings */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>GENERAL</Text>

          <View style={styles.settingCard}>
            <View style={styles.settingRow}>
              <View style={styles.settingLeft}>
                <IconSymbol name="globe" size={22} color={colors.primary} />
                <Text style={styles.settingLabel}>Idioma</Text>
              </View>
              <Pressable
                style={styles.settingValue}
                onPress={() => setShowLanguageModal(true)}
              >
                <Text style={styles.settingValueText}>
                  {getLanguageText(settings.language)}
                </Text>
                <IconSymbol name="chevron.right" size={18} color={colors.textSecondary} />
              </Pressable>
            </View>
          </View>

          <View style={styles.settingCard}>
            <View style={styles.settingRow}>
              <View style={styles.settingLeft}>
                <IconSymbol name="moon.fill" size={22} color={colors.secondary} />
                <View style={styles.settingTextContainer}>
                  <Text style={styles.settingLabel}>Modo Oscuro</Text>
                  <Text style={styles.settingDescription}>
                    {getThemeModeText()}
                  </Text>
                </View>
              </View>
              <Switch
                value={themeMode === 'dark'}
                onValueChange={handleDarkModeToggle}
                trackColor={{ false: colors.border, true: colors.primary }}
                thumbColor={colors.card}
              />
            </View>
          </View>
        </View>

        {/* Notifications Settings */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>NOTIFICACIONES</Text>

          <View style={styles.settingCard}>
            <View style={styles.settingRow}>
              <View style={styles.settingLeft}>
                <IconSymbol name="bell.fill" size={22} color={colors.warning} />
                <View style={styles.settingTextContainer}>
                  <Text style={styles.settingLabel}>Notificaciones Push</Text>
                  <Text style={styles.settingDescription}>
                    Recibe alertas de nuevos pedidos
                  </Text>
                </View>
              </View>
              <Switch
                value={settings.notifications_enabled}
                onValueChange={handleNotificationsToggle}
                trackColor={{ false: colors.border, true: colors.primary }}
                thumbColor={colors.card}
              />
            </View>
          </View>

          <View style={styles.settingCard}>
            <View style={styles.settingRow}>
              <View style={styles.settingLeft}>
                <IconSymbol name="speaker.wave.2.fill" size={22} color={colors.info} />
                <View style={styles.settingTextContainer}>
                  <Text style={styles.settingLabel}>Sonido</Text>
                  <Text style={styles.settingDescription}>
                    Reproducir sonido con notificaciones
                  </Text>
                </View>
              </View>
              <Switch
                value={settings.sound_enabled}
                onValueChange={handleSoundToggle}
                trackColor={{ false: colors.border, true: colors.primary }}
                thumbColor={colors.card}
                disabled={!settings.notifications_enabled}
              />
            </View>
          </View>

          <View style={styles.settingCard}>
            <View style={styles.settingRow}>
              <View style={styles.settingLeft}>
                <IconSymbol name="iphone.radiowaves.left.and.right" size={22} color={colors.success} />
                <View style={styles.settingTextContainer}>
                  <Text style={styles.settingLabel}>Vibración</Text>
                  <Text style={styles.settingDescription}>
                    Vibrar con notificaciones
                  </Text>
                </View>
              </View>
              <Switch
                value={settings.vibration_enabled}
                onValueChange={handleVibrationToggle}
                trackColor={{ false: colors.border, true: colors.primary }}
                thumbColor={colors.card}
                disabled={!settings.notifications_enabled}
              />
            </View>
          </View>
        </View>

        {/* Printer Settings */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>IMPRESIÓN</Text>

          <View style={styles.settingCard}>
            <View style={styles.settingRow}>
              <View style={styles.settingLeft}>
                <IconSymbol name="printer.fill" size={22} color={colors.info} />
                <View style={styles.settingTextContainer}>
                  <Text style={styles.settingLabel}>Impresión Automática</Text>
                  <Text style={styles.settingDescription}>
                    Imprimir pedidos nuevos automáticamente
                  </Text>
                </View>
              </View>
              <Switch
                value={settings.auto_print_enabled}
                onValueChange={handleAutoPrintToggle}
                trackColor={{ false: colors.border, true: colors.primary }}
                thumbColor={colors.card}
              />
            </View>
          </View>

          <Pressable
            style={({ pressed }) => [
              styles.settingCard,
              pressed && styles.settingCardPressed,
            ]}
            onPress={() => router.push('/printer-settings')}
          >
            <View style={styles.settingRow}>
              <View style={styles.settingLeft}>
                <IconSymbol name="gearshape.fill" size={22} color={colors.secondary} />
                <Text style={styles.settingLabel}>Configurar Impresora</Text>
              </View>
              <IconSymbol name="chevron.right" size={18} color={colors.textSecondary} />
            </View>
          </Pressable>
        </View>

        {/* Privacy & Legal */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>PRIVACIDAD Y LEGAL</Text>

          <Pressable
            style={({ pressed }) => [
              styles.settingCard,
              pressed && styles.settingCardPressed,
            ]}
            onPress={openPrivacyPolicy}
          >
            <View style={styles.settingRow}>
              <View style={styles.settingLeft}>
                <IconSymbol name="hand.raised.fill" size={22} color={colors.primary} />
                <Text style={styles.settingLabel}>Política de Privacidad</Text>
              </View>
              <IconSymbol name="chevron.right" size={18} color={colors.textSecondary} />
            </View>
          </Pressable>

          <Pressable
            style={({ pressed }) => [
              styles.settingCard,
              pressed && styles.settingCardPressed,
            ]}
            onPress={openTermsOfService}
          >
            <View style={styles.settingRow}>
              <View style={styles.settingLeft}>
                <IconSymbol name="doc.text.fill" size={22} color={colors.info} />
                <Text style={styles.settingLabel}>Términos de Servicio</Text>
              </View>
              <IconSymbol name="chevron.right" size={18} color={colors.textSecondary} />
            </View>
          </Pressable>

          <View style={styles.settingCard}>
            <View style={styles.settingRow}>
              <View style={styles.settingLeft}>
                <IconSymbol name="lock.fill" size={22} color={colors.success} />
                <View style={styles.settingTextContainer}>
                  <Text style={styles.settingLabel}>Compartir Datos</Text>
                  <Text style={styles.settingDescription}>
                    No compartimos tus datos con terceros
                  </Text>
                </View>
              </View>
              <IconSymbol name="checkmark.circle.fill" size={22} color={colors.success} />
            </View>
          </View>
        </View>

        {/* Advanced Settings */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>AVANZADO</Text>

          <Pressable
            style={({ pressed }) => [
              styles.settingCard,
              pressed && styles.settingCardPressed,
            ]}
            onPress={handleClearCache}
          >
            <View style={styles.settingRow}>
              <View style={styles.settingLeft}>
                <IconSymbol name="trash.fill" size={22} color={colors.warning} />
                <View style={styles.settingTextContainer}>
                  <Text style={styles.settingLabel}>Limpiar Caché</Text>
                  <Text style={styles.settingDescription}>
                    Libera espacio de almacenamiento
                  </Text>
                </View>
              </View>
              <IconSymbol name="chevron.right" size={18} color={colors.textSecondary} />
            </View>
          </Pressable>

          <Pressable
            style={({ pressed }) => [
              styles.settingCard,
              pressed && styles.settingCardPressed,
            ]}
            onPress={handleResetSettings}
          >
            <View style={styles.settingRow}>
              <View style={styles.settingLeft}>
                <IconSymbol name="arrow.counterclockwise" size={22} color={colors.danger} />
                <View style={styles.settingTextContainer}>
                  <Text style={styles.settingLabel}>Restablecer Ajustes</Text>
                  <Text style={styles.settingDescription}>
                    Volver a valores predeterminados
                  </Text>
                </View>
              </View>
              <IconSymbol name="chevron.right" size={18} color={colors.textSecondary} />
            </View>
          </Pressable>
        </View>

        {/* About Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>ACERCA DE</Text>

          <Pressable
            style={({ pressed }) => [
              styles.settingCard,
              pressed && styles.settingCardPressed,
            ]}
            onPress={() => setShowAboutModal(true)}
          >
            <View style={styles.settingRow}>
              <View style={styles.settingLeft}>
                <IconSymbol name="info.circle.fill" size={22} color={colors.info} />
                <Text style={styles.settingLabel}>Información de la App</Text>
              </View>
              <IconSymbol name="chevron.right" size={18} color={colors.textSecondary} />
            </View>
          </Pressable>

          <View style={styles.settingCard}>
            <View style={styles.settingRow}>
              <View style={styles.settingLeft}>
                <IconSymbol name="number" size={22} color={colors.secondary} />
                <Text style={styles.settingLabel}>Versión</Text>
              </View>
              <Text style={styles.settingValueText}>1.0.0</Text>
            </View>
          </View>
        </View>

        {/* User Info */}
        <View style={styles.userInfoCard}>
          <View style={styles.userInfoRow}>
            <Text style={styles.userInfoLabel}>Usuario:</Text>
            <Text style={styles.userInfoValue}>{profile?.full_name || 'Usuario'}</Text>
          </View>
          <View style={styles.userInfoRow}>
            <Text style={styles.userInfoLabel}>Email:</Text>
            <Text style={styles.userInfoValue}>{user?.email}</Text>
          </View>
          <View style={styles.userInfoRow}>
            <Text style={styles.userInfoLabel}>Rol:</Text>
            <Text style={styles.userInfoValue}>
              {profile?.role === 'admin' ? 'Administrador' : 
               profile?.role === 'manager' ? 'Gerente' :
               profile?.role === 'operator' ? 'Operador' : 'Visualizador'}
            </Text>
          </View>
        </View>
      </ScrollView>

      {/* Language Selection Modal */}
      <Modal
        visible={showLanguageModal}
        animationType="slide"
        presentationStyle="pageSheet"
        onRequestClose={() => setShowLanguageModal(false)}
      >
        <SafeAreaView style={styles.modalContainer} edges={['top']}>
          <View style={styles.modalHeader}>
            <Text style={styles.modalTitle}>Seleccionar Idioma</Text>
            <Pressable
              style={styles.closeButton}
              onPress={() => setShowLanguageModal(false)}
            >
              <IconSymbol name="xmark.circle.fill" size={28} color={colors.textSecondary} />
            </Pressable>
          </View>

          <View style={styles.modalContent}>
            <Pressable
              style={({ pressed }) => [
                styles.languageOption,
                settings.language === 'es' && styles.languageOptionSelected,
                pressed && styles.languageOptionPressed,
              ]}
              onPress={() => handleLanguageChange('es')}
            >
              <View style={styles.languageOptionLeft}>
                <Text style={styles.languageFlag}>🇪🇸</Text>
                <Text style={styles.languageOptionText}>Español</Text>
              </View>
              {settings.language === 'es' && (
                <IconSymbol name="checkmark.circle.fill" size={24} color={colors.primary} />
              )}
            </Pressable>

            <Pressable
              style={({ pressed }) => [
                styles.languageOption,
                settings.language === 'en' && styles.languageOptionSelected,
                pressed && styles.languageOptionPressed,
              ]}
              onPress={() => handleLanguageChange('en')}
            >
              <View style={styles.languageOptionLeft}>
                <Text style={styles.languageFlag}>🇺🇸</Text>
                <Text style={styles.languageOptionText}>English</Text>
              </View>
              {settings.language === 'en' && (
                <IconSymbol name="checkmark.circle.fill" size={24} color={colors.primary} />
              )}
            </Pressable>

            <View style={styles.comingSoonBanner}>
              <IconSymbol name="clock.fill" size={20} color={colors.warning} />
              <Text style={styles.comingSoonText}>
                El cambio de idioma estará disponible en una próxima actualización
              </Text>
            </View>
          </View>
        </SafeAreaView>
      </Modal>

      {/* About Modal */}
      <Modal
        visible={showAboutModal}
        animationType="slide"
        presentationStyle="pageSheet"
        onRequestClose={() => setShowAboutModal(false)}
      >
        <SafeAreaView style={styles.modalContainer} edges={['top']}>
          <View style={styles.modalHeader}>
            <Text style={styles.modalTitle}>Acerca de la App</Text>
            <Pressable
              style={styles.closeButton}
              onPress={() => setShowAboutModal(false)}
            >
              <IconSymbol name="xmark.circle.fill" size={28} color={colors.textSecondary} />
            </Pressable>
          </View>

          <ScrollView style={styles.modalScrollView} contentContainerStyle={styles.modalContent}>
            <View style={styles.aboutHeader}>
              <View style={styles.aboutIcon}>
                <IconSymbol name="bag.fill" size={48} color={colors.primary} />
              </View>
              <Text style={styles.aboutAppName}>Sistema de Pedidos</Text>
              <Text style={styles.aboutVersion}>Versión 1.0.0</Text>
            </View>

            <View style={styles.aboutSection}>
              <Text style={styles.aboutSectionTitle}>Descripción</Text>
              <Text style={styles.aboutText}>
                Sistema completo de gestión de pedidos con integración de WhatsApp Business, 
                impresión automática mediante Bluetooth y notificaciones push en tiempo real.
              </Text>
            </View>

            <View style={styles.aboutSection}>
              <Text style={styles.aboutSectionTitle}>Características</Text>
              <View style={styles.featureList}>
                <View style={styles.featureItem}>
                  <IconSymbol name="checkmark.circle.fill" size={20} color={colors.success} />
                  <Text style={styles.featureText}>Recepción automática de pedidos por WhatsApp</Text>
                </View>
                <View style={styles.featureItem}>
                  <IconSymbol name="checkmark.circle.fill" size={20} color={colors.success} />
                  <Text style={styles.featureText}>Impresión automática con impresoras Bluetooth</Text>
                </View>
                <View style={styles.featureItem}>
                  <IconSymbol name="checkmark.circle.fill" size={20} color={colors.success} />
                  <Text style={styles.featureText}>Notificaciones push en tiempo real</Text>
                </View>
                <View style={styles.featureItem}>
                  <IconSymbol name="checkmark.circle.fill" size={20} color={colors.success} />
                  <Text style={styles.featureText}>Gestión de usuarios con roles y permisos</Text>
                </View>
                <View style={styles.featureItem}>
                  <IconSymbol name="checkmark.circle.fill" size={20} color={colors.success} />
                  <Text style={styles.featureText}>Seguimiento de estados de pedidos</Text>
                </View>
                <View style={styles.featureItem}>
                  <IconSymbol name="checkmark.circle.fill" size={20} color={colors.success} />
                  <Text style={styles.featureText}>Notificaciones por correo electrónico</Text>
                </View>
              </View>
            </View>

            <View style={styles.aboutSection}>
              <Text style={styles.aboutSectionTitle}>Tecnologías</Text>
              <Text style={styles.aboutText}>
                Desarrollado con React Native, Expo, Supabase y WhatsApp Business API.
              </Text>
            </View>

            <View style={styles.aboutSection}>
              <Text style={styles.aboutSectionTitle}>Soporte</Text>
              <Text style={styles.aboutText}>
                Para obtener ayuda o reportar problemas, contacta al administrador del sistema.
              </Text>
            </View>

            <View style={styles.aboutFooter}>
              <Text style={styles.aboutCopyright}>
                © 2024 Sistema de Pedidos. Todos los derechos reservados.
              </Text>
            </View>
          </ScrollView>
        </SafeAreaView>
      </Modal>
    </SafeAreaView>
  );
}


import { Database } from '@/types/database.types';
import { Order, OrderItem } from '@/types/Order';
import { supabase } from '@/lib/supabase';
import { EmailService } from './EmailService';
import { NotificationService } from './NotificationService';
import { RealtimeChannel } from '@supabase/supabase-js';

type OrderRow = Database['public']['Tables']['orders']['Row'];
type OrderItemRow = Database['public']['Tables']['order_items']['Row'];
type OrderInsert = Database['public']['Tables']['orders']['Insert'];
type OrderItemInsert = Database['public']['Tables']['order_items']['Insert'];

export class OrderService {
  static async getOrders(): Promise<Order[]> {
    try {
      const { data: ordersData, error: ordersError } = await supabase
        .from('orders')
        .select('*')
        .order('created_at', { ascending: false });

      if (ordersError) {
        console.error('Error fetching orders:', ordersError);
        throw ordersError;
      }

      if (!ordersData || ordersData.length === 0) {
        return [];
      }

      const orderIds = ordersData.map(order => order.id);

      const { data: itemsData, error: itemsError } = await supabase
        .from('order_items')
        .select('*')
        .in('order_id', orderIds);

      if (itemsError) {
        console.error('Error fetching order items:', itemsError);
        throw itemsError;
      }

      const orders: Order[] = ordersData.map(orderRow => {
        const items = (itemsData || [])
          .filter(item => item.order_id === orderRow.id)
          .map(item => ({
            id: item.id,
            name: item.name,
            quantity: item.quantity,
            price: parseFloat(item.price.toString()),
            notes: item.notes || undefined,
          }));

        return {
          id: orderRow.id,
          orderNumber: orderRow.order_number,
          customerName: orderRow.customer_name,
          customerPhone: orderRow.customer_phone,
          customerAddress: orderRow.customer_address || undefined,
          items,
          status: orderRow.status as Order['status'],
          source: orderRow.source as Order['source'],
          totalAmount: parseFloat(orderRow.total_amount.toString()),
          notes: orderRow.notes || undefined,
          createdAt: new Date(orderRow.created_at!),
          printed: orderRow.printed || false,
          printedAt: orderRow.printed_at ? new Date(orderRow.printed_at) : undefined,
        };
      });

      return orders;
    } catch (error) {
      console.error('Error in getOrders:', error);
      throw error;
    }
  }

  static async getOrderById(id: string): Promise<Order | null> {
    try {
      const { data: orderData, error: orderError } = await supabase
        .from('orders')
        .select('*')
        .eq('id', id)
        .single();

      if (orderError) {
        console.error('Error fetching order:', orderError);
        throw orderError;
      }

      if (!orderData) {
        return null;
      }

      const { data: itemsData, error: itemsError } = await supabase
        .from('order_items')
        .select('*')
        .eq('order_id', id);

      if (itemsError) {
        console.error('Error fetching order items:', itemsError);
        throw itemsError;
      }

      const items: OrderItem[] = (itemsData || []).map(item => ({
        id: item.id,
        name: item.name,
        quantity: item.quantity,
        price: parseFloat(item.price.toString()),
        notes: item.notes || undefined,
      }));

      const order: Order = {
        id: orderData.id,
        orderNumber: orderData.order_number,
        customerName: orderData.customer_name,
        customerPhone: orderData.customer_phone,
        customerAddress: orderData.customer_address || undefined,
        items,
        status: orderData.status as Order['status'],
        source: orderData.source as Order['source'],
        totalAmount: parseFloat(orderData.total_amount.toString()),
        notes: orderData.notes || undefined,
        createdAt: new Date(orderData.created_at!),
        printed: orderData.printed || false,
        printedAt: orderData.printed_at ? new Date(orderData.printed_at) : undefined,
      };

      return order;
    } catch (error) {
      console.error('Error in getOrderById:', error);
      throw error;
    }
  }

  static async createOrder(
    customerName: string,
    customerPhone: string,
    customerAddress: string | undefined,
    items: { name: string; quantity: number; price: number; notes?: string }[],
    notes?: string
  ): Promise<Order> {
    try {
      const { data: { user } } = await supabase.auth.getUser();

      const orderNumber = `ORD-${Date.now()}`;
      const totalAmount = items.reduce((sum, item) => sum + item.price, 0);

      const orderInsert: OrderInsert = {
        order_number: orderNumber,
        customer_name: customerName,
        customer_phone: customerPhone,
        customer_address: customerAddress,
        status: 'pending',
        total_amount: totalAmount,
        source: 'manual',
        notes,
        created_by: user?.id,
      };

      const { data: orderData, error: orderError } = await supabase
        .from('orders')
        .insert(orderInsert)
        .select()
        .single();

      if (orderError) {
        console.error('Error creating order:', orderError);
        throw orderError;
      }

      const itemsInsert: OrderItemInsert[] = items.map(item => ({
        order_id: orderData.id,
        name: item.name,
        quantity: item.quantity,
        price: item.price,
        notes: item.notes,
      }));

      const { data: itemsData, error: itemsError } = await supabase
        .from('order_items')
        .insert(itemsInsert)
        .select();

      if (itemsError) {
        console.error('Error creating order items:', itemsError);
        throw itemsError;
      }

      // Send push notifications to all active users
      const { data: activeUsers } = await supabase
        .from('profiles')
        .select('id')
        .eq('is_active', true);

      if (activeUsers && activeUsers.length > 0) {
        const userIds = activeUsers.map(profile => profile.id);
        
        // Send push notification via Edge Function
        try {
          await supabase.functions.invoke('send-push-notification', {
            body: {
              userIds,
              title: 'Nuevo pedido',
              message: `Pedido ${orderNumber} de ${customerName}`,
              data: {
                type: 'new_order',
                orderId: orderData.id,
                orderNumber,
              },
            },
          });
        } catch (error) {
          console.error('Error sending push notification:', error);
        }
      }

      const order: Order = {
        id: orderData.id,
        orderNumber: orderData.order_number,
        customerName: orderData.customer_name,
        customerPhone: orderData.customer_phone,
        customerAddress: orderData.customer_address || undefined,
        items: (itemsData || []).map(item => ({
          id: item.id,
          name: item.name,
          quantity: item.quantity,
          price: parseFloat(item.price.toString()),
          notes: item.notes || undefined,
        })),
        status: orderData.status as Order['status'],
        source: orderData.source as Order['source'],
        totalAmount: parseFloat(orderData.total_amount.toString()),
        notes: orderData.notes || undefined,
        createdAt: new Date(orderData.created_at!),
        printed: false,
      };

      return order;
    } catch (error) {
      console.error('Error in createOrder:', error);
      throw error;
    }
  }

  /**
   * Add a new item to an existing order
   * The totalPrice is the final price for the item (not multiplied by quantity)
   */
  static async addItemToOrder(
    orderId: string,
    item: { name: string; quantity: number; totalPrice: number; notes?: string }
  ): Promise<void> {
    try {
      console.log('Adding item to order:', orderId, item);

      // Insert the new item with totalPrice as the price field
      const itemInsert: OrderItemInsert = {
        order_id: orderId,
        name: item.name,
        quantity: item.quantity,
        price: item.totalPrice,
        notes: item.notes,
      };

      const { error: itemError } = await supabase
        .from('order_items')
        .insert(itemInsert);

      if (itemError) {
        console.error('Error adding item to order:', itemError);
        throw itemError;
      }

      // Recalculate total amount (sum of all item prices, not multiplied by quantity)
      const { data: items, error: itemsError } = await supabase
        .from('order_items')
        .select('price')
        .eq('order_id', orderId);

      if (itemsError) {
        console.error('Error fetching items for total calculation:', itemsError);
        throw itemsError;
      }

      const totalAmount = (items || []).reduce(
        (sum, item) => sum + parseFloat(item.price.toString()),
        0
      );

      // Update order total
      const { error: orderError } = await supabase
        .from('orders')
        .update({
          total_amount: totalAmount,
          updated_at: new Date().toISOString(),
        })
        .eq('id', orderId);

      if (orderError) {
        console.error('Error updating order total:', orderError);
        throw orderError;
      }

      console.log('Item added successfully, new total:', totalAmount);

      // Send WhatsApp notification to customer about the added product
      await this.sendProductAddedNotification(orderId, item);
    } catch (error) {
      console.error('Error in addItemToOrder:', error);
      throw error;
    }
  }

  /**
   * Send WhatsApp notification when a product is added to an order
   */
  private static async sendProductAddedNotification(
    orderId: string,
    addedItem: { name: string; quantity: number; totalPrice: number }
  ): Promise<void> {
    try {
      console.log('Sending WhatsApp notification for added product:', orderId, addedItem);

      // Get order details
      const { data: orderData, error: orderError } = await supabase
        .from('orders')
        .select('order_number, customer_name, customer_phone, source, total_amount')
        .eq('id', orderId)
        .single();

      if (orderError || !orderData) {
        console.error('Error fetching order for WhatsApp notification:', orderError);
        return;
      }

      // Only send WhatsApp notifications for WhatsApp orders
      if (orderData.source !== 'whatsapp') {
        console.log('Order is not from WhatsApp, skipping WhatsApp notification');
        return;
      }

      // Get all order items for the complete list
      const { data: itemsData } = await supabase
        .from('order_items')
        .select('name, quantity, price')
        .eq('order_id', orderId);

      // Call the Edge Function to send WhatsApp message
      const { error: functionError } = await supabase.functions.invoke('send-whatsapp-product-added', {
        body: {
          orderId,
          orderNumber: orderData.order_number,
          customerName: orderData.customer_name,
          customerPhone: orderData.customer_phone,
          addedProduct: {
            name: addedItem.name,
            quantity: addedItem.quantity,
            price: addedItem.totalPrice,
          },
          totalAmount: orderData.total_amount,
          allItems: itemsData || [],
        },
      });

      if (functionError) {
        console.error('Error calling WhatsApp product added notification function:', functionError);
      } else {
        console.log('WhatsApp product added notification sent successfully');
      }
    } catch (error) {
      console.error('Error in sendProductAddedNotification:', error);
      // Don't throw error - we don't want to fail the item addition if WhatsApp fails
    }
  }

  static async updateOrder(
    orderId: string,
    updates: {
      customerName?: string;
      customerPhone?: string;
      customerAddress?: string;
      notes?: string;
      items?: OrderItem[];
    }
  ): Promise<void> {
    try {
      // Update order basic info
      const orderUpdates: any = {
        updated_at: new Date().toISOString(),
      };

      if (updates.customerName !== undefined) {
        orderUpdates.customer_name = updates.customerName;
      }
      if (updates.customerPhone !== undefined) {
        orderUpdates.customer_phone = updates.customerPhone;
      }
      if (updates.customerAddress !== undefined) {
        orderUpdates.customer_address = updates.customerAddress;
      }
      if (updates.notes !== undefined) {
        orderUpdates.notes = updates.notes;
      }

      const { error: orderError } = await supabase
        .from('orders')
        .update(orderUpdates)
        .eq('id', orderId);

      if (orderError) {
        console.error('Error updating order:', orderError);
        throw orderError;
      }

      // Update items if provided
      if (updates.items) {
        // Delete existing items
        await supabase
          .from('order_items')
          .delete()
          .eq('order_id', orderId);

        // Insert new items
        const itemsInsert = updates.items.map(item => ({
          order_id: orderId,
          name: item.name,
          quantity: item.quantity,
          price: item.price,
          notes: item.notes,
        }));

        const { error: itemsError } = await supabase
          .from('order_items')
          .insert(itemsInsert);

        if (itemsError) {
          console.error('Error updating order items:', itemsError);
          throw itemsError;
        }

        // Recalculate total (sum of prices, not multiplied by quantity)
        const totalAmount = updates.items.reduce(
          (sum, item) => sum + item.price,
          0
        );

        await supabase
          .from('orders')
          .update({ total_amount: totalAmount })
          .eq('id', orderId);
      }
    } catch (error) {
      console.error('Error in updateOrder:', error);
      throw error;
    }
  }

  static async updateOrderPrices(
    orderId: string,
    prices: Record<string, number>
  ): Promise<void> {
    try {
      // Update each item's price
      for (const [itemId, price] of Object.entries(prices)) {
        const { error } = await supabase
          .from('order_items')
          .update({ price })
          .eq('id', itemId)
          .eq('order_id', orderId);

        if (error) {
          console.error('Error updating item price:', error);
          throw error;
        }
      }

      // Recalculate total amount (sum of prices, not multiplied by quantity)
      const { data: items, error: itemsError } = await supabase
        .from('order_items')
        .select('price')
        .eq('order_id', orderId);

      if (itemsError) {
        console.error('Error fetching items for total calculation:', itemsError);
        throw itemsError;
      }

      const totalAmount = (items || []).reduce(
        (sum, item) => sum + parseFloat(item.price.toString()),
        0
      );

      const { error: orderError } = await supabase
        .from('orders')
        .update({
          total_amount: totalAmount,
          updated_at: new Date().toISOString(),
        })
        .eq('id', orderId);

      if (orderError) {
        console.error('Error updating order total:', orderError);
        throw orderError;
      }
    } catch (error) {
      console.error('Error in updateOrderPrices:', error);
      throw error;
    }
  }

  /**
   * Send WhatsApp notification to customer about order status change
   */
  private static async sendWhatsAppStatusNotification(
    orderId: string,
    status: Order['status']
  ): Promise<void> {
    try {
      console.log('Sending WhatsApp status notification for order:', orderId, 'status:', status);

      // Get order details
      const { data: orderData, error: orderError } = await supabase
        .from('orders')
        .select('order_number, customer_name, customer_phone, source, total_amount')
        .eq('id', orderId)
        .single();

      if (orderError || !orderData) {
        console.error('Error fetching order for WhatsApp notification:', orderError);
        return;
      }

      // Only send WhatsApp notifications for WhatsApp orders
      if (orderData.source !== 'whatsapp') {
        console.log('Order is not from WhatsApp, skipping WhatsApp notification');
        return;
      }

      // Get order items for detailed message
      const { data: itemsData } = await supabase
        .from('order_items')
        .select('name, quantity, price')
        .eq('order_id', orderId);

      // Call the Edge Function to send WhatsApp message
      const { error: functionError } = await supabase.functions.invoke('send-whatsapp-status', {
        body: {
          orderId,
          orderNumber: orderData.order_number,
          customerName: orderData.customer_name,
          customerPhone: orderData.customer_phone,
          status,
          totalAmount: orderData.total_amount,
          items: itemsData || [],
        },
      });

      if (functionError) {
        console.error('Error calling WhatsApp status notification function:', functionError);
      } else {
        console.log('WhatsApp status notification sent successfully');
      }
    } catch (error) {
      console.error('Error in sendWhatsAppStatusNotification:', error);
      // Don't throw error - we don't want to fail the status update if WhatsApp fails
    }
  }

  static async updateOrderStatus(orderId: string, status: Order['status']): Promise<void> {
    try {
      const { error } = await supabase
        .from('orders')
        .update({ status, updated_at: new Date().toISOString() })
        .eq('id', orderId);

      if (error) {
        console.error('Error updating order status:', error);
        throw error;
      }

      const { data: orderData } = await supabase
        .from('orders')
        .select('order_number, customer_name')
        .eq('id', orderId)
        .single();

      // Send push notifications to all active users about status change
      if (orderData) {
        const { data: activeUsers } = await supabase
          .from('profiles')
          .select('id')
          .eq('is_active', true);

        if (activeUsers && activeUsers.length > 0) {
          const statusMessages: Record<string, string> = {
            pending: 'está pendiente',
            preparing: 'está siendo preparado',
            ready: 'está listo',
            delivered: 'ha sido entregado',
            cancelled: 'ha sido cancelado',
          };

          const userIds = activeUsers.map(profile => profile.id);
          
          // Send push notification via Edge Function
          try {
            await supabase.functions.invoke('send-push-notification', {
              body: {
                userIds,
                title: 'Cambio de estado',
                message: `Pedido ${orderData.order_number} ${statusMessages[status]}`,
                data: {
                  type: 'order_status_change',
                  orderId,
                  orderNumber: orderData.order_number,
                  status,
                },
              },
            });
          } catch (error) {
            console.error('Error sending push notification:', error);
          }
        }
      }

      // Send WhatsApp notification to customer
      await this.sendWhatsAppStatusNotification(orderId, status);
    } catch (error) {
      console.error('Error in updateOrderStatus:', error);
      throw error;
    }
  }

  /**
   * Delete an order (only allowed for admins and only for 'ready' or 'cancelled' orders)
   * The RLS policy enforces these restrictions at the database level
   */
  static async deleteOrder(orderId: string): Promise<void> {
    try {
      console.log('Deleting order:', orderId);

      // First delete all order items (cascade should handle this, but being explicit)
      const { error: itemsError } = await supabase
        .from('order_items')
        .delete()
        .eq('order_id', orderId);

      if (itemsError) {
        console.error('Error deleting order items:', itemsError);
        throw itemsError;
      }

      // Delete the order
      const { error: orderError } = await supabase
        .from('orders')
        .delete()
        .eq('id', orderId);

      if (orderError) {
        console.error('Error deleting order:', orderError);
        // Check if it's a permission error
        if (orderError.code === 'PGRST301' || orderError.message.includes('policy')) {
          throw new Error('No tienes permiso para eliminar este pedido. Solo los administradores pueden eliminar pedidos en estado "Listo" o "Cancelado".');
        }
        throw orderError;
      }

      console.log('Order deleted successfully');
    } catch (error) {
      console.error('Error in deleteOrder:', error);
      throw error;
    }
  }

  static async markAsPrinted(orderId: string): Promise<void> {
    try {
      const { error } = await supabase
        .from('orders')
        .update({
          printed: true,
          printed_at: new Date().toISOString(),
        })
        .eq('id', orderId);

      if (error) {
        console.error('Error marking order as printed:', error);
        throw error;
      }
    } catch (error) {
      console.error('Error in markAsPrinted:', error);
      throw error;
    }
  }

  static async getUnprintedOrders(): Promise<Order[]> {
    try {
      const { data: ordersData, error: ordersError } = await supabase
        .from('orders')
        .select('*')
        .eq('printed', false)
        .order('created_at', { ascending: true });

      if (ordersError) {
        console.error('Error fetching unprinted orders:', ordersError);
        throw ordersError;
      }

      if (!ordersData || ordersData.length === 0) {
        return [];
      }

      const orderIds = ordersData.map(order => order.id);

      const { data: itemsData, error: itemsError } = await supabase
        .from('order_items')
        .select('*')
        .in('order_id', orderIds);

      if (itemsError) {
        console.error('Error fetching order items:', itemsError);
        throw itemsError;
      }

      const orders: Order[] = ordersData.map(orderRow => {
        const items = (itemsData || [])
          .filter(item => item.order_id === orderRow.id)
          .map(item => ({
            id: item.id,
            name: item.name,
            quantity: item.quantity,
            price: parseFloat(item.price.toString()),
            notes: item.notes || undefined,
          }));

        return {
          id: orderRow.id,
          orderNumber: orderRow.order_number,
          customerName: orderRow.customer_name,
          customerPhone: orderRow.customer_phone,
          customerAddress: orderRow.customer_address || undefined,
          items,
          status: orderRow.status as Order['status'],
          source: orderRow.source as Order['source'],
          totalAmount: parseFloat(orderRow.total_amount.toString()),
          notes: orderRow.notes || undefined,
          createdAt: new Date(orderRow.created_at!),
          printed: false,
        };
      });

      return orders;
    } catch (error) {
      console.error('Error in getUnprintedOrders:', error);
      throw error;
    }
  }

  /**
   * Subscribe to new orders in real-time
   * @param callback Function to call when a new order is created
   * @returns Unsubscribe function
   */
  static subscribeToNewOrders(callback: (order: Order) => void): () => void {
    console.log('Setting up subscription to new orders');
    
    const channel = supabase
      .channel('new-orders')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'orders',
        },
        async (payload) => {
          console.log('New order detected:', payload);
          
          try {
            // Fetch the complete order with items
            const order = await OrderService.getOrderById(payload.new.id);
            if (order) {
              callback(order);
            }
          } catch (error) {
            console.error('Error fetching new order details:', error);
          }
        }
      )
      .subscribe();

    // Return unsubscribe function
    return () => {
      console.log('Unsubscribing from new orders');
      supabase.removeChannel(channel);
    };
  }

  /**
   * Subscribe to order updates in real-time
   * @param callback Function to call when an order is updated
   * @returns Unsubscribe function
   */
  static subscribeToOrderUpdates(callback: (order: Order) => void): () => void {
    console.log('Setting up subscription to order updates');
    
    const channel = supabase
      .channel('order-updates')
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'orders',
        },
        async (payload) => {
          console.log('Order updated:', payload);
          
          try {
            // Fetch the complete order with items
            const order = await OrderService.getOrderById(payload.new.id);
            if (order) {
              callback(order);
            }
          } catch (error) {
            console.error('Error fetching updated order details:', error);
          }
        }
      )
      .subscribe();

    // Return unsubscribe function
    return () => {
      console.log('Unsubscribing from order updates');
      supabase.removeChannel(channel);
    };
  }
}

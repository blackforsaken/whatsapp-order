
import { Alert } from 'react-native';
import { supabase } from '@/lib/supabase';

export interface InAppNotification {
  id: string;
  title: string;
  message: string;
  type: 'new_order' | 'order_status_change' | 'system';
  orderId?: string;
  timestamp: Date;
  read: boolean;
}

type NotificationListener = (notification: InAppNotification) => void;

/**
 * In-App Notification Service
 * Provides dialog-based notifications that work in all environments
 * including Expo Go where push notifications are not supported
 */
export class InAppNotificationService {
  private static listeners: Set<NotificationListener> = new Set();
  private static notificationQueue: InAppNotification[] = [];

  /**
   * Show an immediate dialog notification
   */
  static showDialog(title: string, message: string, orderId?: string): void {
    Alert.alert(
      title,
      message,
      [
        {
          text: 'Cerrar',
          style: 'cancel',
        },
        ...(orderId
          ? [
              {
                text: 'Ver Pedido',
                onPress: () => {
                  // Navigation will be handled by the listener
                  this.notifyListeners({
                    id: Date.now().toString(),
                    title,
                    message,
                    type: 'new_order',
                    orderId,
                    timestamp: new Date(),
                    read: false,
                  });
                },
              },
            ]
          : []),
      ],
      { cancelable: true }
    );
  }

  /**
   * Show a banner notification (non-blocking)
   */
  static showBanner(notification: InAppNotification): void {
    this.notificationQueue.push(notification);
    this.notifyListeners(notification);
  }

  /**
   * Register a listener for notifications
   */
  static addListener(listener: NotificationListener): () => void {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }

  /**
   * Notify all listeners
   */
  private static notifyListeners(notification: InAppNotification): void {
    this.listeners.forEach((listener) => {
      try {
        listener(notification);
      } catch (error) {
        console.error('Error in notification listener:', error);
      }
    });
  }

  /**
   * Get all queued notifications
   */
  static getQueuedNotifications(): InAppNotification[] {
    return [...this.notificationQueue];
  }

  /**
   * Clear notification queue
   */
  static clearQueue(): void {
    this.notificationQueue = [];
  }

  /**
   * Mark notification as read
   */
  static markAsRead(notificationId: string): void {
    const notification = this.notificationQueue.find((n) => n.id === notificationId);
    if (notification) {
      notification.read = true;
    }
  }

  /**
   * Send notification to all active users via database
   * This creates notification records that can be displayed in-app
   */
  static async sendToAllUsers(
    title: string,
    message: string,
    type: 'new_order' | 'order_status_change' | 'system',
    orderId?: string
  ): Promise<void> {
    try {
      // Get all active users
      const { data: activeUsers, error: usersError } = await supabase
        .from('profiles')
        .select('id')
        .eq('is_active', true);

      if (usersError) {
        console.error('Error fetching active users:', usersError);
        return;
      }

      if (!activeUsers || activeUsers.length === 0) {
        console.log('No active users to notify');
        return;
      }

      // Create notification records for all users
      const notificationRecords = activeUsers.map((user) => ({
        user_id: user.id,
        type,
        title,
        message,
        order_id: orderId || null,
        read: false,
      }));

      const { error: insertError } = await supabase
        .from('notifications')
        .insert(notificationRecords);

      if (insertError) {
        console.error('Error creating notification records:', insertError);
      } else {
        console.log(`Created ${notificationRecords.length} notification records`);
      }
    } catch (error) {
      console.error('Error in sendToAllUsers:', error);
    }
  }

  /**
   * Send notification to specific user
   */
  static async sendToUser(
    userId: string,
    title: string,
    message: string,
    type: 'new_order' | 'order_status_change' | 'system',
    orderId?: string
  ): Promise<void> {
    try {
      const { error } = await supabase.from('notifications').insert({
        user_id: userId,
        type,
        title,
        message,
        order_id: orderId || null,
        read: false,
      });

      if (error) {
        console.error('Error creating notification record:', error);
      } else {
        console.log('Notification record created for user:', userId);
      }
    } catch (error) {
      console.error('Error in sendToUser:', error);
    }
  }
}

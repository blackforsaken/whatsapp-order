
import { Platform, Alert } from 'react-native';
import { Order, OrderItem } from '@/types/Order';

// Conditionally import the Bluetooth library only on native platforms
let BluetoothManager: any = null;
let BluetoothEscposPrinter: any = null;
let BluetoothTscPrinter: any = null;
let bluetoothLoadError: Error | null = null;

// Only import on native platforms
if (Platform.OS !== 'web') {
  try {
    // Use dynamic import instead of require
    import('react-native-bluetooth-escpos-printer').then((BluetoothLib) => {
      BluetoothManager = BluetoothLib.BluetoothManager;
      BluetoothEscposPrinter = BluetoothLib.BluetoothEscposPrinter;
      BluetoothTscPrinter = BluetoothLib.BluetoothTscPrinter;
      console.log('✅ Bluetooth library loaded successfully');
    }).catch((error) => {
      bluetoothLoadError = error as Error;
      console.error('❌ Failed to load Bluetooth library:', error);
      console.log('⚠️ Bluetooth printing requires a development build');
      console.log('📖 See: https://docs.expo.dev/develop/development-builds/introduction/');
    });
  } catch (error) {
    bluetoothLoadError = error as Error;
    console.error('❌ Failed to load Bluetooth library:', error);
    console.log('⚠️ Bluetooth printing requires a development build');
    console.log('📖 See: https://docs.expo.dev/develop/development-builds/introduction/');
  }
}

export interface PrinterDevice {
  address: string;
  name: string;
}

export interface PrinterSettings {
  printerModel: string;
  paperWidth: number;
  fontSize: 'small' | 'normal' | 'large';
  printHeader: boolean;
  printFooter: boolean;
  headerText: string;
  footerText: string;
  lineSpacing: number;
  boldTitles: boolean;
  autoCutEnabled: boolean;
}

export interface PrinterDiagnostics {
  isConnected: boolean;
  bluetoothEnabled: boolean;
  deviceName: string | null;
  deviceAddress: string | null;
  lastPrintSuccess: boolean;
  lastPrintTime: Date | null;
  errorCount: number;
  lastError: string | null;
}

const formatCurrency = (amount: number): string => {
  return `$${amount.toLocaleString('es-CL', { minimumFractionDigits: 0, maximumFractionDigits: 0 })}`;
};

class BluetoothPrinterService {
  private connectedDevice: PrinterDevice | null = null;
  private isInitialized: boolean = false;
  private settings: PrinterSettings = {
    printerModel: 'generic_80mm',
    paperWidth: 80,
    fontSize: 'normal',
    printHeader: true,
    printFooter: true,
    headerText: 'VERDURERIA',
    footerText: 'Gracias por su pedido!',
    lineSpacing: 1,
    boldTitles: true,
    autoCutEnabled: true,
  };
  private diagnostics: PrinterDiagnostics = {
    isConnected: false,
    bluetoothEnabled: false,
    deviceName: null,
    deviceAddress: null,
    lastPrintSuccess: false,
    lastPrintTime: null,
    errorCount: 0,
    lastError: null,
  };

  /**
   * Update printer settings
   */
  updateSettings(newSettings: Partial<PrinterSettings>): void {
    this.settings = { ...this.settings, ...newSettings };
    console.log('🔧 Printer settings updated:', this.settings);
  }

  /**
   * Get current printer settings
   */
  getSettings(): PrinterSettings {
    return { ...this.settings };
  }

  /**
   * Get printer diagnostics
   */
  getDiagnostics(): PrinterDiagnostics {
    return { ...this.diagnostics };
  }

  /**
   * Set whether auto-cut is enabled
   */
  setAutoCutEnabled(enabled: boolean): void {
    this.settings.autoCutEnabled = enabled;
    console.log('🔧 Auto-cut setting updated:', enabled);
  }

  /**
   * Get current auto-cut setting
   */
  getAutoCutEnabled(): boolean {
    return this.settings.autoCutEnabled;
  }

  /**
   * Check if Bluetooth is available on this platform
   */
  isBluetoothAvailable(): boolean {
    if (Platform.OS === 'web') {
      console.log('⚠️ Bluetooth is not available on web platform');
      return false;
    }

    if (bluetoothLoadError) {
      console.log('⚠️ Bluetooth library failed to load:', bluetoothLoadError.message);
      return false;
    }

    if (!BluetoothManager || !BluetoothEscposPrinter) {
      console.log('⚠️ Bluetooth library is not loaded');
      return false;
    }

    console.log('✅ Bluetooth is available');
    return true;
  }

  /**
   * Show user-friendly error message for Expo Go limitations
   */
  showExpoGoLimitation(): void {
    Alert.alert(
      '🔧 Desarrollo Requerido',
      'La impresión Bluetooth requiere una compilación de desarrollo (Development Build).\n\n' +
      'Expo Go no soporta esta funcionalidad.\n\n' +
      'Para usar la impresora:\n' +
      '1. Crea un Development Build\n' +
      '2. O usa "npx expo run:android" / "npx expo run:ios"',
      [
        {
          text: 'Más Información',
          onPress: () => {
            console.log('📖 Development builds: https://docs.expo.dev/develop/development-builds/introduction/');
          }
        },
        { text: 'Entendido', style: 'cancel' }
      ]
    );
  }

  /**
   * Initialize Bluetooth and check if it's enabled
   */
  async initialize(): Promise<boolean> {
    try {
      console.log('🔄 Initializing Bluetooth...');
      
      // Check if Bluetooth is available on this platform
      if (!this.isBluetoothAvailable()) {
        console.error('❌ Bluetooth is not available on this platform');
        this.diagnostics.bluetoothEnabled = false;
        this.showExpoGoLimitation();
        return false;
      }

      const isEnabled = await BluetoothManager.isBluetoothEnabled();
      console.log('Bluetooth enabled status:', isEnabled);
      this.diagnostics.bluetoothEnabled = isEnabled;
      
      if (!isEnabled) {
        console.log('⚠️ Bluetooth is not enabled, attempting to enable...');
        if (Platform.OS === 'android') {
          try {
            await BluetoothManager.enableBluetooth();
            this.diagnostics.bluetoothEnabled = true;
            console.log('✅ Bluetooth enabled successfully');
          } catch (enableError) {
            console.error('❌ Error enabling Bluetooth:', enableError);
            this.diagnostics.lastError = 'No se pudo habilitar Bluetooth';
            return false;
          }
        } else {
          console.log('⚠️ Cannot enable Bluetooth programmatically on iOS');
          this.diagnostics.lastError = 'Habilita Bluetooth manualmente en iOS';
          return false;
        }
      }
      
      this.isInitialized = true;
      console.log('✅ Bluetooth initialized successfully');
      return true;
    } catch (error) {
      console.error('❌ Error initializing Bluetooth:', error);
      this.isInitialized = false;
      this.diagnostics.bluetoothEnabled = false;
      this.diagnostics.lastError = error instanceof Error ? error.message : 'Error desconocido';
      return false;
    }
  }

  /**
   * Run comprehensive diagnostics
   */
  async runDiagnostics(): Promise<PrinterDiagnostics> {
    console.log('🔍 Running printer diagnostics...');

    // Reset diagnostics
    this.diagnostics.lastError = null;

    // Check Bluetooth availability
    const available = this.isBluetoothAvailable();
    if (!available) {
      this.diagnostics.bluetoothEnabled = false;
      this.diagnostics.isConnected = false;
      this.diagnostics.lastError = 'Bluetooth no disponible en esta plataforma';
      return this.getDiagnostics();
    }

    // Check Bluetooth enabled status
    try {
      const isEnabled = await BluetoothManager.isBluetoothEnabled();
      this.diagnostics.bluetoothEnabled = isEnabled;
      
      if (!isEnabled) {
        this.diagnostics.isConnected = false;
        this.diagnostics.lastError = 'Bluetooth está deshabilitado';
        return this.getDiagnostics();
      }
    } catch (error) {
      this.diagnostics.bluetoothEnabled = false;
      this.diagnostics.lastError = 'Error al verificar estado de Bluetooth';
      return this.getDiagnostics();
    }

    // Check connection status
    this.diagnostics.isConnected = this.connectedDevice !== null;
    this.diagnostics.deviceName = this.connectedDevice?.name || null;
    this.diagnostics.deviceAddress = this.connectedDevice?.address || null;

    // Verify actual connection if device is supposedly connected
    if (this.connectedDevice) {
      const verified = await this.verifyConnection();
      if (!verified) {
        this.diagnostics.isConnected = false;
        this.diagnostics.lastError = 'Conexión perdida con la impresora';
      }
    }

    console.log('✅ Diagnostics complete:', this.diagnostics);
    return this.getDiagnostics();
  }

  /**
   * Scan for available Bluetooth printers
   */
  async scanForPrinters(): Promise<PrinterDevice[]> {
    try {
      console.log('🔍 Scanning for Bluetooth printers...');
      
      // Check if Bluetooth is available
      if (!this.isBluetoothAvailable()) {
        console.error('❌ Bluetooth is not available on this platform');
        this.diagnostics.lastError = 'Bluetooth no disponible';
        this.showExpoGoLimitation();
        return [];
      }

      // Ensure Bluetooth is initialized
      if (!this.isInitialized) {
        console.log('⚠️ Bluetooth not initialized, initializing now...');
        const initialized = await this.initialize();
        if (!initialized) {
          console.error('❌ Failed to initialize Bluetooth');
          return [];
        }
      }

      // Get paired devices
      const pairedDevicesRaw = await BluetoothManager.enableBluetooth();
      console.log('Raw paired devices:', pairedDevicesRaw);
      
      // Parse the response - it might be a JSON string
      let pairedDevices = pairedDevicesRaw;
      if (typeof pairedDevicesRaw === 'string') {
        try {
          pairedDevices = JSON.parse(pairedDevicesRaw);
        } catch (parseError) {
          console.error('❌ Error parsing paired devices:', parseError);
          this.diagnostics.lastError = 'Error al analizar dispositivos';
          return [];
        }
      }
      
      // Convert to PrinterDevice array
      const printers: PrinterDevice[] = (Array.isArray(pairedDevices) ? pairedDevices : []).map((device: any) => ({
        address: device.address || device.id || '',
        name: device.name || 'Unknown Device',
      }));
      
      console.log(`✅ Found ${printers.length} printer(s):`, printers);
      return printers;
    } catch (error) {
      console.error('❌ Error scanning for printers:', error);
      this.diagnostics.lastError = error instanceof Error ? error.message : 'Error al escanear';
      this.diagnostics.errorCount++;
      return [];
    }
  }

  /**
   * Connect to a specific printer
   */
  async connectToPrinter(device: PrinterDevice): Promise<boolean> {
    try {
      console.log('🔄 Connecting to printer:', device.name, '(', device.address, ')');
      
      // Check if Bluetooth is available
      if (!this.isBluetoothAvailable()) {
        console.error('❌ Bluetooth is not available on this platform');
        this.diagnostics.lastError = 'Bluetooth no disponible';
        this.showExpoGoLimitation();
        return false;
      }

      // Ensure Bluetooth is initialized
      if (!this.isInitialized) {
        console.log('⚠️ Bluetooth not initialized, initializing now...');
        const initialized = await this.initialize();
        if (!initialized) {
          console.error('❌ Failed to initialize Bluetooth');
          return false;
        }
      }

      // Disconnect from any existing connection
      if (this.connectedDevice) {
        console.log('⚠️ Disconnecting from previous printer...');
        await this.disconnect();
      }

      // Connect to the new device
      await BluetoothManager.connect(device.address);
      this.connectedDevice = device;
      this.diagnostics.isConnected = true;
      this.diagnostics.deviceName = device.name;
      this.diagnostics.deviceAddress = device.address;
      this.diagnostics.lastError = null;
      
      console.log('✅ Successfully connected to printer:', device.name);
      return true;
    } catch (error) {
      console.error('❌ Error connecting to printer:', error);
      this.connectedDevice = null;
      this.diagnostics.isConnected = false;
      this.diagnostics.lastError = error instanceof Error ? error.message : 'Error al conectar';
      this.diagnostics.errorCount++;
      return false;
    }
  }

  /**
   * Disconnect from current printer
   */
  async disconnect(): Promise<void> {
    try {
      if (this.connectedDevice) {
        console.log('🔄 Disconnecting from printer:', this.connectedDevice.name);
        
        // Check if Bluetooth is available
        if (!this.isBluetoothAvailable()) {
          console.error('❌ Bluetooth is not available on this platform');
          this.connectedDevice = null;
          this.diagnostics.isConnected = false;
          return;
        }

        await BluetoothManager.disconnect();
        this.connectedDevice = null;
        this.diagnostics.isConnected = false;
        this.diagnostics.deviceName = null;
        this.diagnostics.deviceAddress = null;
        console.log('✅ Disconnected from printer');
      }
    } catch (error) {
      console.error('❌ Error disconnecting from printer:', error);
      this.connectedDevice = null;
      this.diagnostics.isConnected = false;
      this.diagnostics.lastError = error instanceof Error ? error.message : 'Error al desconectar';
    }
  }

  /**
   * Check if printer is connected
   */
  isConnected(): boolean {
    return this.connectedDevice !== null;
  }

  /**
   * Get connected device info
   */
  getConnectedDevice(): PrinterDevice | null {
    return this.connectedDevice;
  }

  /**
   * Verify actual Bluetooth connection status
   */
  async verifyConnection(): Promise<boolean> {
    try {
      if (!this.connectedDevice) {
        return false;
      }

      // Check if Bluetooth is available
      if (!this.isBluetoothAvailable()) {
        console.error('❌ Bluetooth is not available on this platform');
        this.connectedDevice = null;
        this.diagnostics.isConnected = false;
        return false;
      }

      // Try to check connection status
      const isEnabled = await BluetoothManager.isBluetoothEnabled();
      if (!isEnabled) {
        console.log('⚠️ Bluetooth is disabled');
        this.connectedDevice = null;
        this.diagnostics.isConnected = false;
        this.diagnostics.bluetoothEnabled = false;
        return false;
      }

      this.diagnostics.bluetoothEnabled = true;
      return true;
    } catch (error) {
      console.error('❌ Error verifying connection:', error);
      this.connectedDevice = null;
      this.diagnostics.isConnected = false;
      this.diagnostics.lastError = error instanceof Error ? error.message : 'Error al verificar conexión';
      return false;
    }
  }

  /**
   * Get font size multipliers based on settings
   */
  private getFontSizeMultipliers(): { width: number; height: number } {
    switch (this.settings.fontSize) {
      case 'small':
        return { width: 0, height: 0 };
      case 'large':
        return { width: 2, height: 2 };
      case 'normal':
      default:
        return { width: 1, height: 1 };
    }
  }

  /**
   * Get character width based on paper width and font size
   */
  private getCharacterWidth(): number {
    const baseWidth = this.settings.paperWidth === 58 ? 32 : 48;
    const fontSize = this.settings.fontSize;
    
    if (fontSize === 'small') return baseWidth + 16;
    if (fontSize === 'large') return Math.floor(baseWidth / 2);
    return baseWidth;
  }

  /**
   * Perform paper cut if auto-cut is enabled
   */
  private async performCut(): Promise<void> {
    if (!this.settings.autoCutEnabled) {
      console.log('⚠️ Auto-cut is disabled, skipping paper cut');
      return;
    }

    try {
      console.log('✂️ Performing paper cut...');
      await BluetoothEscposPrinter.cutOnePoint();
      console.log('✅ Paper cut successful');
    } catch (cutError) {
      console.log('⚠️ Paper cut not supported or failed:', cutError);
      // Don't throw error, just log it - some printers don't support cutting
    }
  }

  /**
   * Print line spacing
   */
  private async printLineSpacing(): Promise<void> {
    for (let i = 0; i < this.settings.lineSpacing; i++) {
      await BluetoothEscposPrinter.printText('\r\n', {});
    }
  }

  /**
   * Print an order receipt
   */
  async printOrder(order: Order): Promise<boolean> {
    try {
      if (!this.connectedDevice) {
        console.error('❌ No printer connected');
        this.diagnostics.lastError = 'No hay impresora conectada';
        return false;
      }

      // Check if Bluetooth is available
      if (!this.isBluetoothAvailable()) {
        console.error('❌ Bluetooth is not available on this platform');
        this.diagnostics.lastError = 'Bluetooth no disponible';
        this.showExpoGoLimitation();
        return false;
      }

      // Verify connection before printing
      const isConnected = await this.verifyConnection();
      if (!isConnected) {
        console.error('❌ Printer connection lost');
        this.diagnostics.lastError = 'Conexión perdida';
        this.diagnostics.lastPrintSuccess = false;
        return false;
      }

      console.log('🖨️ Printing order:', order.orderNumber);
      console.log('📋 Settings:', this.settings);

      const fontSizes = this.getFontSizeMultipliers();
      const separator = '='.repeat(this.getCharacterWidth());

      // Print header
      if (this.settings.printHeader) {
        await BluetoothEscposPrinter.printerAlign(BluetoothEscposPrinter.ALIGN.CENTER);
        await BluetoothEscposPrinter.printText(separator + '\r\n', {});
        await BluetoothEscposPrinter.printText(this.settings.headerText + '\r\n', {
          widthtimes: this.settings.boldTitles ? fontSizes.width : 0,
          heigthtimes: this.settings.boldTitles ? fontSizes.height : 0,
        });
        await BluetoothEscposPrinter.printText('NUEVO PEDIDO\r\n', {
          widthtimes: fontSizes.width,
          heigthtimes: fontSizes.height,
        });
        await BluetoothEscposPrinter.printText(separator + '\r\n', {});
        await this.printLineSpacing();
      }

      // Print order number and time
      await BluetoothEscposPrinter.printerAlign(BluetoothEscposPrinter.ALIGN.LEFT);
      await BluetoothEscposPrinter.printText(`Pedido: ${order.orderNumber}\r\n`, {});
      await BluetoothEscposPrinter.printText(
        `Fecha: ${order.createdAt.toLocaleDateString('es-CL')} ${order.createdAt.toLocaleTimeString('es-CL', { hour: '2-digit', minute: '2-digit' })}\r\n`,
        {}
      );
      await BluetoothEscposPrinter.printText('-'.repeat(this.getCharacterWidth()) + '\r\n', {});

      // Print customer info
      await this.printLineSpacing();
      await BluetoothEscposPrinter.printText('CLIENTE:\r\n', {});
      await BluetoothEscposPrinter.printText(`${order.customerName}\r\n`, {});
      await BluetoothEscposPrinter.printText(`Tel: ${order.customerPhone}\r\n`, {});
      
      if (order.customerAddress) {
        await BluetoothEscposPrinter.printText(`Dir: ${order.customerAddress}\r\n`, {});
      }
      
      await BluetoothEscposPrinter.printText('-'.repeat(this.getCharacterWidth()) + '\r\n', {});

      // Print items
      await this.printLineSpacing();
      await BluetoothEscposPrinter.printText('PRODUCTOS:\r\n', {});

      for (const item of order.items) {
        // Item name and quantity
        await BluetoothEscposPrinter.printText(
          `${item.quantity}x ${item.name}\r\n`,
          {}
        );

        // Item price
        const itemTotal = item.price * item.quantity;
        await BluetoothEscposPrinter.printText(`   ${formatCurrency(itemTotal)}\r\n`, {});

        // Item notes if any
        if (item.notes) {
          await BluetoothEscposPrinter.printText(`   Nota: ${item.notes}\r\n`, {});
        }
        
        await this.printLineSpacing();
      }

      await BluetoothEscposPrinter.printText('-'.repeat(this.getCharacterWidth()) + '\r\n', {});

      // Print total
      await BluetoothEscposPrinter.printerAlign(BluetoothEscposPrinter.ALIGN.RIGHT);
      await BluetoothEscposPrinter.printText(`TOTAL: ${formatCurrency(order.totalAmount)}\r\n`, {
        widthtimes: fontSizes.width,
        heigthtimes: fontSizes.height,
      });

      // Print notes if any
      if (order.notes) {
        await BluetoothEscposPrinter.printerAlign(BluetoothEscposPrinter.ALIGN.LEFT);
        await this.printLineSpacing();
        await BluetoothEscposPrinter.printText('-'.repeat(this.getCharacterWidth()) + '\r\n', {});
        await BluetoothEscposPrinter.printText('NOTAS:\r\n', {});
        await BluetoothEscposPrinter.printText(`${order.notes}\r\n`, {});
      }

      // Print footer
      if (this.settings.printFooter) {
        await BluetoothEscposPrinter.printerAlign(BluetoothEscposPrinter.ALIGN.CENTER);
        await this.printLineSpacing();
        await BluetoothEscposPrinter.printText(separator + '\r\n', {});
        await BluetoothEscposPrinter.printText(this.settings.footerText + '\r\n', {});
        await BluetoothEscposPrinter.printText(separator + '\r\n\r\n\r\n', {});
      }

      // Cut paper if enabled
      await this.performCut();

      this.diagnostics.lastPrintSuccess = true;
      this.diagnostics.lastPrintTime = new Date();
      this.diagnostics.lastError = null;
      console.log('✅ Order printed successfully');
      return true;
    } catch (error) {
      console.error('❌ Error printing order:', error);
      this.connectedDevice = null;
      this.diagnostics.isConnected = false;
      this.diagnostics.lastPrintSuccess = false;
      this.diagnostics.lastError = error instanceof Error ? error.message : 'Error al imprimir';
      this.diagnostics.errorCount++;
      return false;
    }
  }

  /**
   * Print a test receipt
   */
  async printTest(): Promise<boolean> {
    try {
      if (!this.connectedDevice) {
        console.error('❌ No printer connected');
        this.diagnostics.lastError = 'No hay impresora conectada';
        return false;
      }

      // Check if Bluetooth is available
      if (!this.isBluetoothAvailable()) {
        console.error('❌ Bluetooth is not available on this platform');
        this.diagnostics.lastError = 'Bluetooth no disponible';
        this.showExpoGoLimitation();
        return false;
      }

      // Verify connection before printing
      const isConnected = await this.verifyConnection();
      if (!isConnected) {
        console.error('❌ Printer connection lost');
        this.diagnostics.lastError = 'Conexión perdida';
        this.diagnostics.lastPrintSuccess = false;
        return false;
      }

      console.log('🖨️ Printing test receipt...');
      console.log('📋 Settings:', this.settings);

      const fontSizes = this.getFontSizeMultipliers();
      const separator = '='.repeat(this.getCharacterWidth());

      await BluetoothEscposPrinter.printerAlign(BluetoothEscposPrinter.ALIGN.CENTER);
      await BluetoothEscposPrinter.printText(separator + '\r\n', {});
      await BluetoothEscposPrinter.printText(this.settings.headerText + '\r\n', {
        widthtimes: fontSizes.width,
        heigthtimes: fontSizes.height,
      });
      await BluetoothEscposPrinter.printText('PRUEBA DE IMPRESION\r\n', {
        widthtimes: fontSizes.width,
        heigthtimes: fontSizes.height,
      });
      await BluetoothEscposPrinter.printText(separator + '\r\n', {});
      await this.printLineSpacing();
      await BluetoothEscposPrinter.printText('Impresora conectada correctamente\r\n', {});
      await BluetoothEscposPrinter.printText(
        `${new Date().toLocaleString('es-CL')}\r\n`,
        {}
      );
      
      // Show settings
      await this.printLineSpacing();
      await BluetoothEscposPrinter.printerAlign(BluetoothEscposPrinter.ALIGN.LEFT);
      await BluetoothEscposPrinter.printText('CONFIGURACION:\r\n', {});
      await BluetoothEscposPrinter.printText(`Modelo: ${this.settings.printerModel}\r\n`, {});
      await BluetoothEscposPrinter.printText(`Ancho: ${this.settings.paperWidth}mm\r\n`, {});
      await BluetoothEscposPrinter.printText(`Tamaño: ${this.settings.fontSize}\r\n`, {});
      await BluetoothEscposPrinter.printText(`Autocorte: ${this.settings.autoCutEnabled ? 'Si' : 'No'}\r\n`, {});
      await BluetoothEscposPrinter.printText(`Espaciado: ${this.settings.lineSpacing}x\r\n`, {});
      
      await this.printLineSpacing();
      await BluetoothEscposPrinter.printerAlign(BluetoothEscposPrinter.ALIGN.CENTER);
      await BluetoothEscposPrinter.printText(separator + '\r\n\r\n\r\n', {});

      // Cut paper if enabled
      await this.performCut();

      this.diagnostics.lastPrintSuccess = true;
      this.diagnostics.lastPrintTime = new Date();
      this.diagnostics.lastError = null;
      console.log('✅ Test receipt printed successfully');
      return true;
    } catch (error) {
      console.error('❌ Error printing test receipt:', error);
      this.connectedDevice = null;
      this.diagnostics.isConnected = false;
      this.diagnostics.lastPrintSuccess = false;
      this.diagnostics.lastError = error instanceof Error ? error.message : 'Error al imprimir';
      this.diagnostics.errorCount++;
      return false;
    }
  }
}

// Export singleton instance
export const printerService = new BluetoothPrinterService();


import { supabase } from '@/lib/supabase';

export interface EmailData {
  to: string;
  subject: string;
  html: string;
  text?: string;
}

export class EmailService {
  static async sendEmail(emailData: EmailData): Promise<{ success: boolean; error?: string }> {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      
      if (!session) {
        return { success: false, error: 'No hay sesión activa' };
      }

      const response = await fetch(
        `${process.env.EXPO_PUBLIC_SUPABASE_URL}/functions/v1/send-email`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${session.access_token}`,
          },
          body: JSON.stringify(emailData),
        }
      );

      const result = await response.json();

      if (!response.ok) {
        console.error('Error sending email:', result);
        return { success: false, error: result.error || 'Error al enviar el correo' };
      }

      return { success: true };
    } catch (error) {
      console.error('Error in EmailService.sendEmail:', error);
      return { success: false, error: 'Error al enviar el correo' };
    }
  }

  static async sendOrderConfirmation(
    email: string,
    orderNumber: string,
    customerName: string,
    items: { name: string; quantity: number; price: number }[],
    total: number
  ): Promise<{ success: boolean; error?: string }> {
    const itemsHtml = items
      .map(
        item => `
        <tr>
          <td style="padding: 8px; border-bottom: 1px solid #eee;">${item.name}</td>
          <td style="padding: 8px; border-bottom: 1px solid #eee; text-align: center;">${item.quantity}</td>
          <td style="padding: 8px; border-bottom: 1px solid #eee; text-align: right;">$${item.price.toFixed(2)}</td>
          <td style="padding: 8px; border-bottom: 1px solid #eee; text-align: right;">$${(item.quantity * item.price).toFixed(2)}</td>
        </tr>
      `
      )
      .join('');

    const html = `
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Confirmación de Pedido</title>
        </head>
        <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
          <div style="background-color: #4CAF50; color: white; padding: 20px; text-align: center; border-radius: 8px 8px 0 0;">
            <h1 style="margin: 0;">Confirmación de Pedido</h1>
          </div>
          
          <div style="background-color: #f9f9f9; padding: 20px; border: 1px solid #ddd; border-top: none; border-radius: 0 0 8px 8px;">
            <p>Hola <strong>${customerName}</strong>,</p>
            
            <p>Tu pedido ha sido recibido exitosamente.</p>
            
            <div style="background-color: white; padding: 15px; border-radius: 8px; margin: 20px 0;">
              <p style="margin: 0;"><strong>Número de Pedido:</strong> ${orderNumber}</p>
            </div>
            
            <h2 style="color: #4CAF50; border-bottom: 2px solid #4CAF50; padding-bottom: 10px;">Detalles del Pedido</h2>
            
            <table style="width: 100%; border-collapse: collapse; background-color: white; border-radius: 8px; overflow: hidden;">
              <thead>
                <tr style="background-color: #4CAF50; color: white;">
                  <th style="padding: 12px; text-align: left;">Producto</th>
                  <th style="padding: 12px; text-align: center;">Cantidad</th>
                  <th style="padding: 12px; text-align: right;">Precio</th>
                  <th style="padding: 12px; text-align: right;">Subtotal</th>
                </tr>
              </thead>
              <tbody>
                ${itemsHtml}
              </tbody>
              <tfoot>
                <tr style="background-color: #f5f5f5; font-weight: bold;">
                  <td colspan="3" style="padding: 12px; text-align: right;">Total:</td>
                  <td style="padding: 12px; text-align: right; color: #4CAF50; font-size: 18px;">$${total.toFixed(2)}</td>
                </tr>
              </tfoot>
            </table>
            
            <div style="margin-top: 30px; padding: 15px; background-color: #e8f5e9; border-left: 4px solid #4CAF50; border-radius: 4px;">
              <p style="margin: 0;"><strong>Estado:</strong> Tu pedido está siendo preparado</p>
              <p style="margin: 10px 0 0 0;">Te notificaremos cuando esté listo para entrega.</p>
            </div>
            
            <p style="margin-top: 30px;">Si tienes alguna pregunta sobre tu pedido, no dudes en contactarnos.</p>
            
            <p style="margin-top: 20px;">Gracias por tu preferencia,<br><strong>El equipo de Pedidos</strong></p>
          </div>
          
          <div style="text-align: center; margin-top: 20px; color: #666; font-size: 12px;">
            <p>Este es un correo automático, por favor no respondas a este mensaje.</p>
          </div>
        </body>
      </html>
    `;

    return this.sendEmail({
      to: email,
      subject: `Confirmación de Pedido ${orderNumber}`,
      html,
    });
  }

  static async sendOrderStatusUpdate(
    email: string,
    orderNumber: string,
    customerName: string,
    status: string
  ): Promise<{ success: boolean; error?: string }> {
    const statusMessages: Record<string, { title: string; message: string; color: string }> = {
      preparing: {
        title: 'Tu pedido está siendo preparado',
        message: 'Estamos trabajando en tu pedido. Te notificaremos cuando esté listo.',
        color: '#FF9800',
      },
      ready: {
        title: 'Tu pedido está listo',
        message: 'Tu pedido está listo para ser entregado o recogido.',
        color: '#4CAF50',
      },
      delivered: {
        title: 'Pedido entregado',
        message: 'Tu pedido ha sido entregado exitosamente. ¡Gracias por tu compra!',
        color: '#2196F3',
      },
      cancelled: {
        title: 'Pedido cancelado',
        message: 'Tu pedido ha sido cancelado. Si tienes alguna pregunta, contáctanos.',
        color: '#F44336',
      },
    };

    const statusInfo = statusMessages[status] || {
      title: 'Actualización de pedido',
      message: 'El estado de tu pedido ha sido actualizado.',
      color: '#9E9E9E',
    };

    const html = `
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Actualización de Pedido</title>
        </head>
        <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
          <div style="background-color: ${statusInfo.color}; color: white; padding: 20px; text-align: center; border-radius: 8px 8px 0 0;">
            <h1 style="margin: 0;">Actualización de Pedido</h1>
          </div>
          
          <div style="background-color: #f9f9f9; padding: 20px; border: 1px solid #ddd; border-top: none; border-radius: 0 0 8px 8px;">
            <p>Hola <strong>${customerName}</strong>,</p>
            
            <div style="background-color: white; padding: 15px; border-radius: 8px; margin: 20px 0;">
              <p style="margin: 0;"><strong>Número de Pedido:</strong> ${orderNumber}</p>
            </div>
            
            <div style="margin: 20px 0; padding: 20px; background-color: white; border-left: 4px solid ${statusInfo.color}; border-radius: 4px;">
              <h2 style="margin: 0 0 10px 0; color: ${statusInfo.color};">${statusInfo.title}</h2>
              <p style="margin: 0;">${statusInfo.message}</p>
            </div>
            
            <p style="margin-top: 30px;">Si tienes alguna pregunta sobre tu pedido, no dudes en contactarnos.</p>
            
            <p style="margin-top: 20px;">Gracias por tu preferencia,<br><strong>El equipo de Pedidos</strong></p>
          </div>
          
          <div style="text-align: center; margin-top: 20px; color: #666; font-size: 12px;">
            <p>Este es un correo automático, por favor no respondas a este mensaje.</p>
          </div>
        </body>
      </html>
    `;

    return this.sendEmail({
      to: email,
      subject: `Actualización de Pedido ${orderNumber} - ${statusInfo.title}`,
      html,
    });
  }
}

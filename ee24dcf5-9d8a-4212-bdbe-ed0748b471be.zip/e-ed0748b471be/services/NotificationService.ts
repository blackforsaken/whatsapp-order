
import { supabase } from '@/lib/supabase';
import * as Notifications from 'expo-notifications';
import * as Device from 'expo-device';
import { Platform, Alert } from 'react-native';
import Constants from 'expo-constants';

// Configure notification behavior
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: true,
  }),
});

export interface NotificationData {
  id: string;
  user_id: string | null;
  type: 'new_order' | 'order_status_change' | 'system';
  title: string;
  message: string;
  order_id: string | null;
  read: boolean;
  created_at: string;
}

export class NotificationService {
  /**
   * Check if push notifications are supported in current environment
   */
  static isPushNotificationSupported(): boolean {
    if (Platform.OS === 'web') {
      return false;
    }

    // Check if running in Expo Go (SDK 53+)
    const isExpoGo = Constants.appOwnership === 'expo';
    if (isExpoGo) {
      console.log('⚠️ Push notifications are not supported in Expo Go (SDK 53+)');
      return false;
    }

    return true;
  }

  /**
   * Show user-friendly error message for Expo Go limitations
   */
  static showExpoGoLimitation(): void {
    Alert.alert(
      '🔧 Desarrollo Requerido',
      'Las notificaciones push requieren una compilación de desarrollo (Development Build).\n\n' +
      'Expo Go no soporta esta funcionalidad desde SDK 53.\n\n' +
      'Para usar notificaciones push:\n' +
      '1. Crea un Development Build\n' +
      '2. O usa "npx expo run:android" / "npx expo run:ios"',
      [
        {
          text: 'Más Información',
          onPress: () => {
            console.log('📖 Development builds: https://docs.expo.dev/develop/development-builds/introduction/');
          }
        },
        { text: 'Entendido', style: 'cancel' }
      ]
    );
  }

  /**
   * Register device for push notifications and save token to database
   */
  static async registerForPushNotifications(): Promise<string | null> {
    if (Platform.OS === 'web') {
      console.log('Push notifications are not supported on web');
      return null;
    }

    // Check if push notifications are supported
    if (!this.isPushNotificationSupported()) {
      console.log('⚠️ Push notifications not supported in this environment');
      return null;
    }

    try {
      // Check if running on physical device
      if (!Device.isDevice) {
        console.log('Push notifications only work on physical devices');
        return null;
      }

      // Get existing permission status
      const { status: existingStatus } = await Notifications.getPermissionsAsync();
      let finalStatus = existingStatus;

      // Request permission if not granted
      if (existingStatus !== 'granted') {
        const { status } = await Notifications.requestPermissionsAsync();
        finalStatus = status;
      }

      if (finalStatus !== 'granted') {
        console.log('Failed to get push token - permission denied');
        return null;
      }

      // Get the Expo push token
      const projectId = Constants.expoConfig?.extra?.eas?.projectId ?? Constants.easConfig?.projectId;
      
      if (!projectId) {
        console.log('No project ID found for push notifications');
        return null;
      }

      const tokenData = await Notifications.getExpoPushTokenAsync({ 
        projectId 
      });
      
      const token = tokenData.data;
      console.log('Push token obtained:', token);

      // Save token to database
      const { data: userData } = await supabase.auth.getUser();
      if (userData?.user) {
        await this.savePushToken(userData.user.id, token);
      }

      // Configure notification channel for Android
      if (Platform.OS === 'android') {
        await Notifications.setNotificationChannelAsync('default', {
          name: 'default',
          importance: Notifications.AndroidImportance.MAX,
          vibrationPattern: [0, 250, 250, 250],
          lightColor: '#FF231F7C',
        });
      }

      return token;
    } catch (error) {
      console.error('Error registering for push notifications:', error);
      
      // Check if it's an Expo Go limitation error
      if (error instanceof Error && error.message.includes('Expo Go')) {
        this.showExpoGoLimitation();
      }
      
      return null;
    }
  }

  /**
   * Save push token to database
   */
  static async savePushToken(userId: string, token: string): Promise<void> {
    try {
      const { error } = await supabase
        .from('push_tokens')
        .upsert(
          {
            user_id: userId,
            token,
            device_type: Platform.OS,
            updated_at: new Date().toISOString(),
          },
          {
            onConflict: 'token',
          }
        );

      if (error) {
        console.error('Error saving push token:', error);
      } else {
        console.log('Push token saved successfully');
      }
    } catch (error) {
      console.error('Error in savePushToken:', error);
    }
  }

  /**
   * Remove push token from database (call on logout)
   */
  static async removePushToken(userId: string): Promise<void> {
    try {
      const { error } = await supabase
        .from('push_tokens')
        .delete()
        .eq('user_id', userId);

      if (error) {
        console.error('Error removing push token:', error);
      } else {
        console.log('Push token removed successfully');
      }
    } catch (error) {
      console.error('Error in removePushToken:', error);
    }
  }

  /**
   * Send a local notification (shown immediately on device)
   */
  static async sendLocalNotification(title: string, body: string, data?: any): Promise<void> {
    if (Platform.OS === 'web') {
      console.log('Local notifications are not supported on web');
      return;
    }

    try {
      await Notifications.scheduleNotificationAsync({
        content: {
          title,
          body,
          data,
          sound: true,
        },
        trigger: null, // Show immediately
      });
    } catch (error) {
      console.error('Error sending local notification:', error);
    }
  }

  /**
   * Send push notification via Edge Function
   */
  static async sendPushNotification(
    userId: string,
    title: string,
    message: string,
    data?: any
  ): Promise<void> {
    try {
      const { data: result, error } = await supabase.functions.invoke('send-push-notification', {
        body: {
          userId,
          title,
          message,
          data,
        },
      });

      if (error) {
        console.error('Error sending push notification:', error);
      } else {
        console.log('Push notification sent successfully:', result);
      }
    } catch (error) {
      console.error('Error in sendPushNotification:', error);
    }
  }

  /**
   * Get unread notification count
   */
  static async getUnreadCount(): Promise<number> {
    try {
      const { data: userData } = await supabase.auth.getUser();
      if (!userData?.user) {
        return 0;
      }

      const { count, error } = await supabase
        .from('notifications')
        .select('*', { count: 'exact', head: true })
        .eq('user_id', userData.user.id)
        .eq('read', false);

      if (error) {
        console.error('Error getting unread notifications:', error);
        return 0;
      }

      return count || 0;
    } catch (error) {
      console.error('Error in getUnreadCount:', error);
      return 0;
    }
  }

  /**
   * Get all notifications for current user
   */
  static async getNotifications(limit: number = 50): Promise<NotificationData[]> {
    try {
      const { data: userData } = await supabase.auth.getUser();
      if (!userData?.user) {
        return [];
      }

      const { data, error } = await supabase
        .from('notifications')
        .select('*')
        .eq('user_id', userData.user.id)
        .order('created_at', { ascending: false })
        .limit(limit);

      if (error) {
        console.error('Error getting notifications:', error);
        return [];
      }

      return data || [];
    } catch (error) {
      console.error('Error in getNotifications:', error);
      return [];
    }
  }

  /**
   * Mark notification as read
   */
  static async markAsRead(notificationId: string): Promise<void> {
    try {
      const { error } = await supabase
        .from('notifications')
        .update({ read: true })
        .eq('id', notificationId);

      if (error) {
        console.error('Error marking notification as read:', error);
      }
    } catch (error) {
      console.error('Error in markAsRead:', error);
    }
  }

  /**
   * Mark all notifications as read
   */
  static async markAllAsRead(): Promise<void> {
    try {
      const { data: userData } = await supabase.auth.getUser();
      if (!userData?.user) {
        return;
      }

      const { error } = await supabase
        .from('notifications')
        .update({ read: true })
        .eq('user_id', userData.user.id)
        .eq('read', false);

      if (error) {
        console.error('Error marking all notifications as read:', error);
      }
    } catch (error) {
      console.error('Error in markAllAsRead:', error);
    }
  }

  /**
   * Delete a notification
   */
  static async deleteNotification(notificationId: string): Promise<void> {
    try {
      const { error } = await supabase
        .from('notifications')
        .delete()
        .eq('id', notificationId);

      if (error) {
        console.error('Error deleting notification:', error);
      }
    } catch (error) {
      console.error('Error in deleteNotification:', error);
    }
  }

  /**
   * Subscribe to notification received events
   */
  static subscribeToNotifications(callback: (notification: Notifications.Notification) => void) {
    const subscription = Notifications.addNotificationReceivedListener(callback);

    return () => {
      subscription.remove();
    };
  }

  /**
   * Subscribe to notification response events (when user taps notification)
   */
  static subscribeToNotificationResponse(
    callback: (response: Notifications.NotificationResponse) => void
  ) {
    const subscription = Notifications.addNotificationResponseReceivedListener(callback);

    return () => {
      subscription.remove();
    };
  }
}

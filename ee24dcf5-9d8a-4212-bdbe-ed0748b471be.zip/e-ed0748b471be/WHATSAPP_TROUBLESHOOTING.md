
# WhatsApp Integration - Troubleshooting Guide

## 🔍 Diagnostic Flowchart

### Problem: No confirmation received from WhatsApp

```
START: Client sent message but no confirmation received
    ↓
Q: Did the webhook receive the message?
    ├─ YES → Go to Section A
    └─ NO → Go to Section B
```

#### Section A: Webhook received message but no confirmation sent

```
Check logs for "WhatsApp message sent successfully"
    ├─ Found → Message was sent, check client's WhatsApp
    └─ Not found → Check for errors
        ↓
Check for error: "WhatsApp credentials not configured"
    ├─ YES → Configure WHATSAPP_ACCESS_TOKEN and WHATSAPP_PHONE_NUMBER_ID
    └─ NO → Check for other errors
        ↓
Check for error: "Error sending WhatsApp message"
    ├─ YES → Token may be expired or invalid
    │         → Regenerate token in Meta for Developers
    └─ NO → Check network/API issues
```

#### Section B: Webhook didn't receive message

```
Check webhook configuration in Meta
    ↓
Q: Is webhook URL correct?
    URL: https://stxrvyxkxclezgcijhio.supabase.co/functions/v1/whatsapp-webhook
    ├─ NO → Update webhook URL
    └─ YES → Continue
        ↓
Q: Is webhook verified?
    ├─ NO → Verify webhook with correct WHATSAPP_VERIFY_TOKEN
    └─ YES → Continue
        ↓
Q: Are you subscribed to 'messages' event?
    ├─ NO → Subscribe to 'messages' event
    └─ YES → Check Edge Function status
        ↓
Q: Is Edge Function deployed and active?
    ├─ NO → Deploy Edge Function
    └─ YES → Check Meta webhook logs
```

### Problem: Order not created in database

```
START: Message received but order not in database
    ↓
Check logs for "Order created: {id}"
    ├─ Found → Order was created, check database query
    └─ Not found → Continue
        ↓
Check logs for "No se pudieron extraer items del mensaje"
    ├─ Found → Message format not recognized
    │         → Go to Section C
    └─ Not found → Continue
        ↓
Check logs for "Error creating order"
    ├─ Found → Database error
    │         → Go to Section D
    └─ Not found → Check for other errors
```

#### Section C: Message format not recognized

```
Review message format in logs
    ↓
Q: Does message contain quantity, product name, and price?
    ├─ NO → Client needs to send complete information
    └─ YES → Continue
        ↓
Q: Is price clearly marked?
    Example: $10 or 10
    ├─ NO → Ask client to include price with $
    └─ YES → Continue
        ↓
Q: Is quantity clearly marked?
    Example: 2 or 2x
    ├─ NO → Ask client to include quantity
    └─ YES → Format may need new pattern
        ↓
Add new regex pattern to parseOrderFromMessage()
```

#### Section D: Database error

```
Check error message in logs
    ↓
Common errors:
    ├─ "permission denied" → Check RLS policies
    ├─ "relation does not exist" → Tables not created
    ├─ "null value in column" → Missing required field
    └─ Other → Check database logs
        ↓
Verify tables exist:
    - orders
    - order_items
    - notifications
    - profiles
        ↓
Verify RLS policies allow insert
```

### Problem: Push notifications not received

```
START: Order created but no push notifications
    ↓
Check logs for "Push notifications sent successfully"
    ├─ Found → Notifications sent, check client side
    │         → Go to Section E
    └─ Not found → Continue
        ↓
Check logs for "Error sending push notifications"
    ├─ Found → Check error details
    │         → Go to Section F
    └─ Not found → Notifications not attempted
        ↓
Q: Are there active users?
    Query: SELECT * FROM profiles WHERE is_active = true
    ├─ NO → No users to notify (expected behavior)
    └─ YES → Check notification creation logic
```

#### Section E: Notifications sent but not received

```
Q: Does user have push token registered?
    Query: SELECT * FROM push_tokens WHERE user_id = 'USER_ID'
    ├─ NO → User needs to login and register token
    └─ YES → Continue
        ↓
Q: Are notification permissions granted on device?
    ├─ NO → User needs to grant permissions
    └─ YES → Continue
        ↓
Q: Is app in foreground?
    ├─ YES → Notification may not show (expected)
    └─ NO → Check Expo push notification service
        ↓
Check Expo push notification dashboard
    → Look for delivery status
```

#### Section F: Error sending push notifications

```
Check error message
    ↓
Common errors:
    ├─ "Edge Function not found" → Deploy send-push-notification
    ├─ "Invalid token" → Token may be expired
    ├─ "Network error" → Temporary issue, will retry
    └─ Other → Check send-push-notification logs
```

### Problem: Webhook verification fails

```
START: Cannot verify webhook in Meta
    ↓
Q: Is WHATSAPP_VERIFY_TOKEN configured in Supabase?
    ├─ NO → Configure environment variable
    └─ YES → Continue
        ↓
Q: Does token in Meta match WHATSAPP_VERIFY_TOKEN?
    ├─ NO → Update token in Meta or Supabase
    └─ YES → Continue
        ↓
Q: Is Edge Function deployed?
    ├─ NO → Deploy Edge Function
    └─ YES → Continue
        ↓
Check Edge Function logs during verification
    → Look for "Webhook verified successfully"
    ├─ Found → Verification succeeded
    └─ Not found → Check for errors
```

## 🛠️ Common Fixes

### Fix 1: Reset Webhook

```bash
1. Go to Meta for Developers
2. Remove webhook subscription
3. Wait 1 minute
4. Add webhook again
5. Verify with correct token
6. Subscribe to 'messages' event
```

### Fix 2: Regenerate WhatsApp Token

```bash
1. Go to Meta for Developers
2. Navigate to WhatsApp → Configuration
3. Generate new access token
4. Update WHATSAPP_ACCESS_TOKEN in Supabase
5. Test with new message
```

### Fix 3: Redeploy Edge Function

```bash
1. Go to Supabase Dashboard
2. Navigate to Edge Functions
3. Select whatsapp-webhook
4. Click "Deploy"
5. Wait for deployment to complete
6. Test webhook
```

### Fix 4: Clear and Re-register Push Token

```bash
1. In app, logout
2. Clear app data (optional)
3. Login again
4. Grant notification permissions
5. Token will be registered automatically
6. Test with new order
```

### Fix 5: Check Database Permissions

```sql
-- Check RLS policies
SELECT * FROM pg_policies WHERE tablename = 'orders';
SELECT * FROM pg_policies WHERE tablename = 'order_items';
SELECT * FROM pg_policies WHERE tablename = 'notifications';

-- Test insert permission
INSERT INTO orders (
  order_number, 
  customer_name, 
  customer_phone, 
  status, 
  total_amount
) VALUES (
  'TEST-123', 
  'Test', 
  '1234567890', 
  'pending', 
  10
);
```

## 📋 Diagnostic Checklist

Use this checklist to diagnose issues systematically:

### Environment Configuration
- [ ] `WHATSAPP_VERIFY_TOKEN` is set
- [ ] `WHATSAPP_ACCESS_TOKEN` is set
- [ ] `WHATSAPP_PHONE_NUMBER_ID` is set
- [ ] All tokens are valid (not expired)

### Meta Configuration
- [ ] Webhook URL is correct
- [ ] Webhook is verified
- [ ] Subscribed to 'messages' event
- [ ] WhatsApp number is active

### Supabase Configuration
- [ ] Edge Function is deployed
- [ ] Edge Function status is ACTIVE
- [ ] Tables exist (orders, order_items, notifications)
- [ ] RLS policies allow inserts

### Testing
- [ ] Sent test message
- [ ] Checked Edge Function logs
- [ ] Checked database for new order
- [ ] Checked for notifications
- [ ] Checked for push notifications

## 🔬 Advanced Diagnostics

### Test Webhook Directly

Use curl to test the webhook:

```bash
curl -X POST https://stxrvyxkxclezgcijhio.supabase.co/functions/v1/whatsapp-webhook \
  -H "Content-Type: application/json" \
  -d '{
    "entry": [{
      "changes": [{
        "value": {
          "messages": [{
            "from": "1234567890",
            "id": "test-id",
            "text": {
              "body": "2 pizzas $10"
            }
          }],
          "contacts": [{
            "profile": {
              "name": "Test User"
            }
          }]
        }
      }]
    }]
  }'
```

Expected response:
```json
{"success": true}
```

### Test Parser Directly

Add this to Edge Function temporarily:

```typescript
// Test parser
const testMessage = "2 pizzas $10\n1 refresco $2";
const items = parseOrderFromMessage(testMessage);
console.log("Parsed items:", JSON.stringify(items, null, 2));
```

### Monitor Real-time

Watch logs in real-time:

```bash
# In Supabase Dashboard
Edge Functions → whatsapp-webhook → Logs → Enable auto-refresh
```

## 📊 Error Codes

| Error | Meaning | Solution |
|-------|---------|----------|
| `ECONNREFUSED` | Cannot connect to service | Check network/service status |
| `ETIMEDOUT` | Request timed out | Retry or check service |
| `401 Unauthorized` | Invalid token | Regenerate token |
| `403 Forbidden` | Permission denied | Check RLS policies |
| `404 Not Found` | Resource not found | Check URL/table name |
| `500 Internal Error` | Server error | Check logs for details |

## 🎯 Quick Fixes by Symptom

| Symptom | Quick Fix |
|---------|-----------|
| No confirmation | Check `WHATSAPP_ACCESS_TOKEN` |
| No order created | Check message format |
| No push notification | Check user has token |
| Webhook fails | Check `WHATSAPP_VERIFY_TOKEN` |
| Parsing fails | Try simpler format |
| Database error | Check RLS policies |

## 📞 When to Ask for Help

Ask for help if:
- ✅ You've checked all items in diagnostic checklist
- ✅ You've reviewed Edge Function logs
- ✅ You've tested with simple message format
- ✅ You've verified all environment variables
- ✅ Issue persists after 24 hours

Include in your support request:
1. Edge Function logs (last 50 lines)
2. Test message you sent
3. Environment variables (without actual values)
4. Steps you've already tried
5. Database query results

## 🔄 Reset Everything

If all else fails, reset the entire integration:

```bash
1. Delete webhook in Meta
2. Delete all environment variables in Supabase
3. Wait 5 minutes
4. Reconfigure everything from scratch
5. Follow WHATSAPP_SETUP_GUIDE.md step by step
6. Test with simple message
```

## 📚 Additional Resources

- [WhatsApp API Docs](https://developers.facebook.com/docs/whatsapp)
- [Supabase Edge Functions Docs](https://supabase.com/docs/guides/functions)
- [Expo Push Notifications Docs](https://docs.expo.dev/push-notifications/overview/)

## 💡 Pro Tips

1. **Always check logs first** - They contain 90% of the information you need
2. **Test with simple messages** - `2 pizzas $10` is your friend
3. **One change at a time** - Don't change multiple things simultaneously
4. **Document what works** - Keep notes of successful configurations
5. **Monitor for patterns** - If same error repeats, it's configuration not code

## ✅ Success Indicators

You know it's working when:
- ✅ Logs show "Order processed successfully"
- ✅ Client receives confirmation in < 5 seconds
- ✅ Order appears in app immediately
- ✅ Push notification arrives
- ✅ No errors in logs

## 🎉 Congratulations!

If you've made it through this guide and everything is working, you now have a fully functional WhatsApp order reception system! 🚀

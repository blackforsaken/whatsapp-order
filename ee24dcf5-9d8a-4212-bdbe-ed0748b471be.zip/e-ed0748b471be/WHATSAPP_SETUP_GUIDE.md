
# Guía de Configuración de WhatsApp Business API

Esta guía te ayudará a configurar la integración con WhatsApp Business API para recibir pedidos automáticamente.

## Requisitos Previos

1. **Cuenta de WhatsApp Business**: Necesitas una cuenta de WhatsApp Business verificada
2. **Meta Business Account**: Debes tener una cuenta de Meta Business
3. **Número de teléfono**: Un número de teléfono dedicado para WhatsApp Business

## Pasos de Configuración

### 1. Configurar WhatsApp Business API

1. Ve a [Meta for Developers](https://developers.facebook.com/)
2. Crea una nueva aplicación o selecciona una existente
3. Agrega el producto "WhatsApp" a tu aplicación
4. Configura tu número de teléfono de WhatsApp Business

### 2. Configurar el Webhook

1. En el panel de WhatsApp Business API, ve a "Configuration" > "Webhooks"
2. Configura la URL del webhook:
   ```
   https://stxrvyxkxclezgcijhio.supabase.co/functions/v1/whatsapp-webhook
   ```
3. Configura el Verify Token (guárdalo para el siguiente paso)
4. Suscríbete a los siguientes eventos:
   - `messages`
   - `message_status`

### 3. Configurar Variables de Entorno en Supabase

1. Ve a tu proyecto en Supabase Dashboard
2. Navega a "Edge Functions" > "Settings"
3. Agrega las siguientes variables de entorno:
   - `WHATSAPP_VERIFY_TOKEN`: El token que configuraste en el paso anterior
   - `WHATSAPP_ACCESS_TOKEN`: Tu token de acceso de WhatsApp Business API
   - `WHATSAPP_PHONE_NUMBER_ID`: El ID de tu número de teléfono de WhatsApp Business
   - `RESEND_API_KEY`: Tu API key de Resend (para envío de emails)

### 4. Formato de Mensajes de WhatsApp

Los clientes pueden enviar pedidos en múltiples formatos. El sistema es inteligente y puede entender varios patrones:

**Formato 1: Cantidad + Producto + Precio**
```
2 pizzas $10
1 refresco $2
3 hamburguesas $5
```

**Formato 2: Cantidad con "x" + Producto + Precio**
```
2x Pizza Margarita $10
1x Coca Cola $2
3x Hamburguesa Clásica $5
```

**Formato 3: Producto + Cantidad + Precio**
```
Pizza Margarita: 2 $10
Coca Cola: 1 $2
Hamburguesa Clásica: 3 $5
```

**Formato 4: Cantidad + Producto + Guión + Precio**
```
2 pizzas - $10
1 refresco - $2
3 hamburguesas - 5
```

**Formato 5: Producto + Precio + Cantidad**
```
Pizza Margarita $10 x2
Coca Cola $2 cantidad 1
Hamburguesa Clásica $5 x3
```

### 5. Características del Sistema

#### Parsing Inteligente de Mensajes
- Detecta automáticamente múltiples formatos de pedidos
- Fusiona items duplicados en el mismo pedido
- Extrae nombre del producto, cantidad y precio
- Maneja precios con o sin símbolo de dólar ($)

#### Confirmación Automática
Cuando un cliente envía un pedido, recibe automáticamente un mensaje de confirmación con:
- ✅ Número de pedido único
- Resumen de items ordenados
- Total a pagar
- Mensaje de confirmación

#### Notificaciones en Tiempo Real
- Todos los usuarios activos reciben notificaciones push
- Se crean notificaciones en la base de datos
- Los pedidos aparecen automáticamente en la app

#### Manejo de Errores
Si el sistema no puede entender el pedido, envía un mensaje de ayuda al cliente con ejemplos de formato.

### 6. Probar la Integración

1. Envía un mensaje de prueba desde WhatsApp al número configurado:
   ```
   2 pizzas $10
   1 refresco $2
   ```

2. Verifica que:
   - Recibes un mensaje de confirmación en WhatsApp
   - El pedido aparece en la aplicación
   - Se creó una notificación para los usuarios activos
   - Los usuarios reciben notificación push

### 7. Flujo Completo del Pedido

1. **Cliente envía mensaje** → WhatsApp Business API
2. **Webhook recibe mensaje** → Edge Function `whatsapp-webhook`
3. **Parser extrae items** → Crea orden en base de datos
4. **Sistema crea notificaciones** → Notifica a usuarios activos
5. **Envía push notifications** → Usuarios reciben alerta
6. **Confirma al cliente** → Mensaje de WhatsApp con resumen

### 8. Configuración de Emails

Para habilitar el envío de correos electrónicos:

1. Crea una cuenta en [Resend](https://resend.com/)
2. Obtén tu API Key
3. Configura la variable de entorno `RESEND_API_KEY` en Supabase
4. Verifica tu dominio en Resend para enviar emails desde tu dominio personalizado

## Solución de Problemas

### El webhook no recibe mensajes

1. Verifica que la URL del webhook esté correctamente configurada
2. Verifica que el Verify Token coincida
3. Revisa los logs de la Edge Function en Supabase:
   ```
   Supabase Dashboard → Edge Functions → whatsapp-webhook → Logs
   ```

### Los pedidos no se crean correctamente

1. Verifica el formato del mensaje en los logs
2. Revisa los logs de la Edge Function para ver errores de parsing
3. Asegúrate de que los permisos de la base de datos estén correctamente configurados
4. Verifica que las tablas `orders` y `order_items` existan

### Los clientes no reciben confirmación

1. Verifica que `WHATSAPP_ACCESS_TOKEN` esté configurada
2. Verifica que `WHATSAPP_PHONE_NUMBER_ID` esté configurada
3. Revisa los logs para ver errores de envío
4. Verifica que tu token de WhatsApp no haya expirado

### Las notificaciones push no llegan

1. Verifica que la Edge Function `send-push-notification` esté desplegada
2. Verifica que los usuarios tengan tokens de push registrados
3. Revisa los logs de ambas Edge Functions
4. Asegúrate de que los usuarios estén marcados como activos (`is_active = true`)

### Los emails no se envían

1. Verifica que `RESEND_API_KEY` esté configurada
2. Verifica que tu dominio esté verificado en Resend
3. Revisa los logs de la Edge Function `send-email`

## Monitoreo y Logs

Para monitorear el sistema:

1. **Logs de Edge Function**:
   - Ve a Supabase Dashboard → Edge Functions → whatsapp-webhook → Logs
   - Busca mensajes como "Order created" o errores

2. **Logs de Base de Datos**:
   - Verifica la tabla `orders` para ver pedidos creados
   - Verifica la tabla `notifications` para ver notificaciones

3. **Logs de WhatsApp**:
   - Ve a Meta for Developers → Tu App → WhatsApp → Webhooks
   - Revisa el historial de webhooks

## Seguridad

- ✅ Nunca compartas tu `WHATSAPP_ACCESS_TOKEN` o `RESEND_API_KEY`
- ✅ Mantén actualizado tu Verify Token
- ✅ Revisa regularmente los logs de las Edge Functions
- ✅ Implementa rate limiting si es necesario
- ✅ Usa HTTPS para todas las comunicaciones
- ✅ Valida todos los datos de entrada

## Mejoras Futuras

Posibles mejoras que puedes implementar:

1. **Catálogo de Productos**: Integrar con el catálogo de WhatsApp Business
2. **Imágenes**: Permitir que los clientes envíen imágenes de productos
3. **Ubicación**: Recibir ubicación del cliente para delivery
4. **Pagos**: Integrar pagos a través de WhatsApp
5. **Chatbot**: Respuestas automáticas a preguntas frecuentes
6. **Tracking**: Enviar actualizaciones de estado del pedido por WhatsApp

## Soporte

Si tienes problemas con la configuración:

1. Revisa los logs de las Edge Functions
2. Verifica que todas las variables de entorno estén configuradas
3. Prueba con diferentes formatos de mensaje
4. Contacta al equipo de soporte con los logs relevantes

## Recursos Adicionales

- [Documentación de WhatsApp Business API](https://developers.facebook.com/docs/whatsapp)
- [Documentación de Supabase Edge Functions](https://supabase.com/docs/guides/functions)
- [Documentación de Resend](https://resend.com/docs)

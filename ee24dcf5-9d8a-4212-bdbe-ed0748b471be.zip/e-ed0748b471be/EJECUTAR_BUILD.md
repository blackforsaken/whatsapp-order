
# 🚀 Guía de Ejecución Rápida - Build APK

## ⚡ Inicio Rápido

Elige una de las siguientes opciones según tus necesidades:

---

## Opción A: Build con EAS (Recomendado) ⭐

### Paso 1: Instalar EAS CLI

```bash
npm install -g eas-cli
```

### Paso 2: Login a Expo

```bash
eas login
```

Ingresa tus credenciales de Expo.

### Paso 3: Configurar Proyecto (Solo Primera Vez)

```bash
eas build:configure
```

### Paso 4: Construir APK

```bash
eas build -p android --profile preview
```

**Tiempo estimado:** 10-15 minutos

**Resultado:** Recibirás un link para descargar el APK cuando termine.

---

## Opción B: Build Local

### Requisitos Previos

- Android SDK instalado
- Java JDK 17 instalado
- Variables de ambiente configuradas (`ANDROID_HOME`, `JAVA_HOME`)

### Paso 1: Limpiar Proyecto

```bash
rm -rf android node_modules
npm install
```

### Paso 2: Generar Archivos Nativos

```bash
npx expo prebuild -p android --clean
```

**Tiempo estimado:** 2-3 minutos

### Paso 3: Construir APK

```bash
cd android
./gradlew assembleRelease
cd ..
```

**Tiempo estimado:** 5-10 minutos

### Paso 4: Ubicar el APK

El APK estará en:
```
android/app/build/outputs/apk/release/app-release.apk
```

---

## 🔍 Verificación Rápida

Después del prebuild, verifica que todo esté correcto:

```bash
# Verificar que el plugin se aplicó
cat android/settings.gradle | grep "react-native-gradle-plugin"

# Verificar repositorios
cat android/build.gradle | grep "mavenCentral"
```

Si ves las líneas correspondientes, ¡todo está bien! ✅

---

## 📱 Instalar APK en Dispositivo

### Vía ADB (Dispositivo Conectado por USB)

```bash
adb install android/app/build/outputs/apk/release/app-release.apk
```

### Vía Archivo

1. Copia el APK a tu dispositivo Android
2. Abre el archivo en tu dispositivo
3. Habilita "Instalar desde fuentes desconocidas" si se solicita
4. Sigue las instrucciones de instalación

---

## ❌ Si Encuentras Errores

### Error de Gradle

```bash
# Limpiar y reconstruir
rm -rf android
npx expo prebuild -p android --clean
```

### Error de Dependencias

```bash
# Limpiar caché y reinstalar
rm -rf node_modules
npm cache clean --force
npm install
```

### Error de Gradle Daemon

```bash
# Detener daemon y reconstruir
cd android
./gradlew --stop
cd ..
rm -rf android
npx expo prebuild -p android --clean
```

---

## 🎯 Comando Todo-en-Uno

Si quieres ejecutar todo de una vez (build local):

```bash
rm -rf android && npx expo prebuild -p android --clean && cd android && ./gradlew assembleRelease && cd .. && echo "✅ APK generado en: android/app/build/outputs/apk/release/app-release.apk"
```

---

## 📊 Progreso del Build

Durante el build verás:

1. **Prebuild:** Generación de archivos nativos (2-3 min)
2. **Gradle Sync:** Sincronización de dependencias (1-2 min)
3. **Compilation:** Compilación de código (3-5 min)
4. **ProGuard:** Optimización y ofuscación (1-2 min)
5. **Packaging:** Empaquetado del APK (1 min)

**Total:** ~10-15 minutos

---

## ✅ Checklist Post-Build

Después de generar el APK:

- [ ] El APK se generó sin errores
- [ ] El tamaño del APK es razonable (30-45 MB)
- [ ] El APK se instala en dispositivo Android
- [ ] La app se abre correctamente
- [ ] Login funciona
- [ ] Funcionalidades principales funcionan

---

## 🎉 ¡Listo para Construir!

Ejecuta uno de estos comandos para empezar:

### Para EAS Build (Recomendado):
```bash
eas build -p android --profile preview
```

### Para Build Local:
```bash
npx expo prebuild -p android --clean
```

---

## 📚 Documentación Adicional

- **BUILD_READY_CHECKLIST.md** - Checklist completo de preparación
- **APK_BUILD_COMPLETE_GUIDE.md** - Guía detallada paso a paso
- **RESUMEN_SOLUCION_GRADLE.md** - Explicación de la solución de Gradle
- **GRADLE_TROUBLESHOOTING.md** - Solución de problemas específicos

---

**¿Preguntas?** Revisa los archivos de documentación o ejecuta el build y reporta cualquier error específico.

¡Buena suerte! 🚀

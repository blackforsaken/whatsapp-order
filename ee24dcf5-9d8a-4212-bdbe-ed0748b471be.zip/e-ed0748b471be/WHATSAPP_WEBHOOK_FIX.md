
# 🔧 Solución: Error de Verificación del Webhook de WhatsApp

## Problema

El webhook de WhatsApp está devolviendo errores **401 Unauthorized** cuando Meta intenta verificarlo. Esto se debe a que la función Edge `whatsapp-webhook` tiene la verificación JWT activada.

## Causa

Meta no envía tokens JWT en sus solicitudes de verificación de webhook, pero Supabase está configurado para requerir JWT en todas las solicitudes a la función.

## Solución

### Paso 1: Desactivar la verificación JWT

1. **Accede al Dashboard de Supabase:**
   ```
   https://supabase.com/dashboard/project/stxrvyxkxclezgcijhio/functions/whatsapp-webhook
   ```

2. **En la configuración de la función:**
   - Busca la opción **"Verify JWT"**
   - **Desactívala** (debe estar en OFF o false)
   - Haz clic en **"Save"** o **"Update"**

### Paso 2: Configurar las variables de entorno

1. **Ve a la configuración de Edge Functions:**
   ```
   https://supabase.com/dashboard/project/stxrvyxkxclezgcijhio/settings/functions
   ```

2. **Agrega o verifica estas variables de entorno:**

   | Variable | Valor | Descripción |
   |----------|-------|-------------|
   | `WHATSAPP_VERIFY_TOKEN` | `mi_token_secreto_2025` | Token personalizado para verificar el webhook |
   | `WHATSAPP_ACCESS_TOKEN` | Tu token de Meta | Token de acceso de WhatsApp Business API |
   | `WHATSAPP_PHONE_NUMBER_ID` | Tu ID de número | ID del número de WhatsApp Business |

   **Importante:** El `WHATSAPP_VERIFY_TOKEN` debe coincidir exactamente con el token que configures en Meta for Developers.

### Paso 3: Probar la verificación

1. **Prueba en tu navegador:**
   ```
   https://stxrvyxkxclezgcijhio.supabase.co/functions/v1/whatsapp-webhook?hub.mode=subscribe&hub.verify_token=mi_token_secreto_2025&hub.challenge=TEST123
   ```

2. **Respuesta esperada:**
   ```
   TEST123
   ```

3. **Si recibes un error 401:**
   - Verifica que la verificación JWT esté desactivada
   - Espera 1-2 minutos para que los cambios se apliquen
   - Intenta nuevamente

### Paso 4: Configurar en Meta for Developers

1. **Accede a tu aplicación en Meta for Developers:**
   ```
   https://developers.facebook.com/apps
   ```

2. **Ve a WhatsApp > Configuration:**
   - **Callback URL:** `https://stxrvyxkxclezgcijhio.supabase.co/functions/v1/whatsapp-webhook`
   - **Verify Token:** `mi_token_secreto_2025`
   - Haz clic en **"Verify and Save"**

3. **Suscríbete a los eventos de webhook:**
   - ✅ `messages`
   - ✅ `message_status`

## Verificación Final

### ✅ Checklist de Verificación

- [ ] Verificación JWT desactivada en la función `whatsapp-webhook`
- [ ] Variables de entorno configuradas correctamente
- [ ] URL de prueba devuelve el challenge correctamente
- [ ] Webhook verificado exitosamente en Meta for Developers
- [ ] Eventos `messages` y `message_status` suscritos

### 🧪 Prueba de Extremo a Extremo

1. **Envía un mensaje de prueba** desde tu teléfono al número de WhatsApp Business:
   ```
   2 pizzas $10
   1 refresco $2
   ```

2. **Verifica que:**
   - El pedido aparece en la app
   - Recibes una notificación push
   - El cliente recibe un mensaje de confirmación en WhatsApp

## Logs y Depuración

### Ver logs de la función

1. **Accede a los logs:**
   ```
   https://supabase.com/dashboard/project/stxrvyxkxclezgcijhio/functions/whatsapp-webhook/logs
   ```

2. **Busca estos mensajes:**
   - ✅ `Webhook verification request:` - Solicitud de verificación recibida
   - ✅ `Webhook verified successfully` - Verificación exitosa
   - ✅ `Order created:` - Pedido creado correctamente
   - ❌ `Webhook verification failed:` - Error de verificación (revisa el token)

### Errores comunes

| Error | Causa | Solución |
|-------|-------|----------|
| 401 Unauthorized | JWT verification activada | Desactiva la verificación JWT |
| 403 Forbidden | Token de verificación incorrecto | Verifica que el token coincida exactamente |
| 500 Internal Server Error | Error en el código o variables de entorno faltantes | Revisa los logs de la función |

## Seguridad

Aunque la verificación JWT está desactivada para permitir las solicitudes de Meta, la función sigue siendo segura porque:

1. **Verificación de token personalizado:** La función verifica el `verify_token` en las solicitudes GET
2. **Validación de payload:** La función valida la estructura del payload de WhatsApp
3. **CORS configurado:** Solo permite solicitudes de orígenes específicos
4. **Variables de entorno:** Los tokens sensibles están almacenados de forma segura

## Recursos Adicionales

- [Documentación de WhatsApp Business API](https://developers.facebook.com/docs/whatsapp/cloud-api)
- [Configuración de Webhooks de WhatsApp](https://developers.facebook.com/docs/whatsapp/cloud-api/guides/set-up-webhooks)
- [Supabase Edge Functions](https://supabase.com/docs/guides/functions)
- [Logs de Supabase](https://supabase.com/dashboard/project/stxrvyxkxclezgcijhio/functions/whatsapp-webhook/logs)

## Soporte

Si sigues teniendo problemas:

1. Revisa los logs de la función en Supabase
2. Verifica que todas las variables de entorno estén configuradas
3. Asegúrate de que el token de verificación coincida exactamente
4. Prueba la URL de verificación en tu navegador antes de configurar en Meta

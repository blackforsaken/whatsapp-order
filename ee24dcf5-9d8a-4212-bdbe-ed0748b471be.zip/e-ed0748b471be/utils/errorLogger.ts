
import { Platform } from "react-native";
import Constants from 'expo-constants';

// Get environment from build configuration
const APP_ENV = Constants.expoConfig?.extra?.APP_ENV || 'production';
const isProduction = APP_ENV === 'production';

/**
 * Error severity levels
 */
export enum ErrorLevel {
  DEBUG = 'debug',
  INFO = 'info',
  WARN = 'warn',
  ERROR = 'error',
  FATAL = 'fatal',
}

/**
 * Error context interface
 */
interface ErrorContext {
  component?: string;
  action?: string;
  userId?: string;
  metadata?: Record<string, any>;
}

/**
 * Clear error after a delay
 */
export const clearErrorAfterDelay = (errorKey: string, delay: number = 5000) => {
  setTimeout(() => {
    if (!isProduction) {
      console.log(`Clearing error: ${errorKey}`);
    }
  }, delay);
};

/**
 * Send error to parent window (for web)
 */
export const sendErrorToParent = (level: string, message: string, data: any) => {
  if (Platform.OS === 'web' && typeof window !== 'undefined') {
    try {
      window.parent.postMessage(
        {
          type: 'error',
          level,
          message,
          data,
          timestamp: new Date().toISOString(),
          appVersion: Constants.expoConfig?.version,
        },
        '*'
      );
    } catch (error) {
      console.error('Failed to send error to parent:', error);
    }
  }
};

/**
 * Extract source location from stack trace
 */
export const extractSourceLocation = (stack: string): string => {
  try {
    const lines = stack.split('\n');
    if (lines.length > 1) {
      const match = lines[1].match(/\((.+):(\d+):(\d+)\)/);
      if (match) {
        return `${match[1]}:${match[2]}:${match[3]}`;
      }
    }
  } catch (error) {
    if (!isProduction) {
      console.error('Failed to extract source location:', error);
    }
  }
  return 'unknown';
};

/**
 * Get caller information
 */
export const getCallerInfo = (): string => {
  try {
    const stack = new Error().stack || '';
    return extractSourceLocation(stack);
  } catch (error) {
    if (!isProduction) {
      console.error('Failed to get caller info:', error);
    }
    return 'unknown';
  }
};

/**
 * Sanitize sensitive data from error messages
 */
const sanitizeErrorData = (data: any): any => {
  if (!data) return data;
  
  const sensitiveKeys = ['password', 'token', 'secret', 'key', 'authorization', 'access_token'];
  
  if (typeof data === 'object') {
    const sanitized = { ...data };
    for (const key of Object.keys(sanitized)) {
      if (sensitiveKeys.some(sensitive => key.toLowerCase().includes(sensitive))) {
        sanitized[key] = '[REDACTED]';
      } else if (typeof sanitized[key] === 'object') {
        sanitized[key] = sanitizeErrorData(sanitized[key]);
      }
    }
    return sanitized;
  }
  
  return data;
};

/**
 * Log error with context and severity
 */
export const errorLogger = (
  error: any, 
  context?: string | ErrorContext,
  level: ErrorLevel = ErrorLevel.ERROR
) => {
  const errorMessage = error?.message || String(error);
  const errorStack = error?.stack || '';
  const location = extractSourceLocation(errorStack);
  
  // Parse context
  const contextObj: ErrorContext = typeof context === 'string' 
    ? { component: context } 
    : (context || {});
  
  // Build error data
  const errorData = {
    message: errorMessage,
    level,
    location,
    context: contextObj,
    timestamp: new Date().toISOString(),
    platform: Platform.OS,
    appVersion: Constants.expoConfig?.version,
    environment: APP_ENV,
  };
  
  // Sanitize sensitive data in production
  const sanitizedData = isProduction ? sanitizeErrorData(errorData) : errorData;
  
  // Log to console (only in development or for errors/fatal)
  if (!isProduction || level === ErrorLevel.ERROR || level === ErrorLevel.FATAL) {
    const prefix = `[${level.toUpperCase()}]`;
    const contextStr = contextObj.component ? `${contextObj.component}: ` : '';
    
    console.error(`${prefix} ${contextStr}${errorMessage}`);
    console.error(`Location: ${location}`);
    
    if (errorStack && !isProduction) {
      console.error('Stack trace:', errorStack);
    }
    
    if (contextObj.metadata && !isProduction) {
      console.error('Metadata:', contextObj.metadata);
    }
  }
  
  // Send to parent window (web only)
  sendErrorToParent(level, errorMessage, sanitizedData);
  
  // In production, you could send to error tracking service here
  // Example: Sentry, Bugsnag, etc.
  if (isProduction && (level === ErrorLevel.ERROR || level === ErrorLevel.FATAL)) {
    // TODO: Integrate with error tracking service
    // Sentry.captureException(error, { contexts: { custom: sanitizedData } });
  }
  
  return sanitizedData;
};

/**
 * Log info message
 */
export const logInfo = (message: string, context?: ErrorContext) => {
  if (!isProduction) {
    console.log(`[INFO] ${message}`, context);
  }
};

/**
 * Log warning
 */
export const logWarning = (message: string, context?: ErrorContext) => {
  console.warn(`[WARN] ${message}`, context);
  
  if (isProduction) {
    sendErrorToParent(ErrorLevel.WARN, message, { context });
  }
};

/**
 * Log debug message (development only)
 */
export const logDebug = (message: string, data?: any) => {
  if (!isProduction) {
    console.log(`[DEBUG] ${message}`, data);
  }
};

export default errorLogger;

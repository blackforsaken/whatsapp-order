
import React, { createContext, useContext, useEffect, useState } from 'react';
import { useColorScheme } from 'react-native';
import { supabase } from '@/lib/supabase';
import { useAuth } from './AuthContext';

type ThemeMode = 'light' | 'dark' | 'system';

interface ThemeContextType {
  theme: 'light' | 'dark';
  themeMode: ThemeMode;
  setThemeMode: (mode: ThemeMode) => void;
  colors: typeof lightColors;
}

const lightColors = {
  background: '#F5F5F5',
  text: '#333333',
  textSecondary: '#777777',
  primary: '#007BFF',
  secondary: '#6C757D',
  accent: '#FFC107',
  card: '#FFFFFF',
  border: '#E0E0E0',
  highlight: '#E9ECEF',
  success: '#28A745',
  danger: '#DC3545',
  warning: '#FFC107',
  info: '#17A2B8',
};

const darkColors = {
  background: '#121212',
  text: '#FFFFFF',
  textSecondary: '#B0B0B0',
  primary: '#1E90FF',
  secondary: '#8E8E93',
  accent: '#FFD700',
  card: '#1E1E1E',
  border: '#2C2C2E',
  highlight: '#2C2C2E',
  success: '#34C759',
  danger: '#FF3B30',
  warning: '#FFD700',
  info: '#5AC8FA',
};

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const systemColorScheme = useColorScheme();
  const { user } = useAuth();
  const [themeMode, setThemeModeState] = useState<ThemeMode>('system');
  const [theme, setTheme] = useState<'light' | 'dark'>(systemColorScheme || 'light');

  // Load theme preference from database
  useEffect(() => {
    if (user?.id) {
      loadThemePreference();
    }
  }, [user?.id]);

  // Update theme when system theme or theme mode changes
  useEffect(() => {
    if (themeMode === 'system') {
      setTheme(systemColorScheme || 'light');
    } else {
      setTheme(themeMode);
    }
  }, [themeMode, systemColorScheme]);

  const loadThemePreference = async () => {
    try {
      const { data, error } = await supabase
        .from('user_settings')
        .select('dark_mode')
        .eq('user_id', user?.id)
        .maybeSingle();

      if (error && error.code !== 'PGRST116') {
        console.error('Error loading theme preference:', error);
        return;
      }

      if (data) {
        // If dark_mode is true, set to dark, otherwise use system
        setThemeModeState(data.dark_mode ? 'dark' : 'system');
      }
    } catch (error) {
      console.error('Error in loadThemePreference:', error);
    }
  };

  const setThemeMode = async (mode: ThemeMode) => {
    setThemeModeState(mode);

    // Save to database
    if (user?.id) {
      try {
        const { error } = await supabase
          .from('user_settings')
          .upsert({
            user_id: user.id,
            dark_mode: mode === 'dark',
            updated_at: new Date().toISOString(),
          });

        if (error) {
          console.error('Error saving theme preference:', error);
        }
      } catch (error) {
        console.error('Error in setThemeMode:', error);
      }
    }
  };

  const colors = theme === 'dark' ? darkColors : lightColors;

  return (
    <ThemeContext.Provider value={{ theme, themeMode, setThemeMode, colors }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  const context = useContext(ThemeContext);
  if (context === undefined) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
}

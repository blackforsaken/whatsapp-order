
import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import { Session, User } from '@supabase/supabase-js';
import { Database } from '@/types/database.types';
import { NotificationService } from '@/services/NotificationService';

type Profile = Database['public']['Tables']['profiles']['Row'];

interface AuthContextType {
  session: Session | null;
  user: User | null;
  profile: Profile | null;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<{ error: any }>;
  signUp: (email: string, password: string, fullName: string) => Promise<{ error: any }>;
  signOut: () => Promise<void>;
  refreshProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);

  const registerPushNotifications = async () => {
    try {
      await NotificationService.registerForPushNotifications();
    } catch (error) {
      console.error('Error registering push notifications:', error);
    }
  };

  const createProfileForUser = async (userId: string, retryCount = 0): Promise<boolean> => {
    try {
      console.log('Creating profile for user:', userId, 'retry:', retryCount);
      
      const { data: userData } = await supabase.auth.getUser();
      if (!userData.user) {
        console.error('No user data available');
        return false;
      }

      // Check if profile already exists
      const { data: existingProfile } = await supabase
        .from('profiles')
        .select('id')
        .eq('id', userId)
        .maybeSingle();

      if (existingProfile) {
        console.log('Profile already exists');
        return true;
      }

      // Create the profile
      const { data, error } = await supabase
        .from('profiles')
        .insert({
          id: userId,
          email: userData.user.email || '',
          full_name: userData.user.user_metadata?.full_name || '',
          role: userData.user.user_metadata?.role || 'viewer',
        })
        .select()
        .single();

      if (error) {
        console.error('Error creating profile:', error);
        
        // Retry up to 3 times with exponential backoff
        if (retryCount < 3) {
          const delay = Math.pow(2, retryCount) * 1000; // 1s, 2s, 4s
          console.log(`Retrying profile creation in ${delay}ms...`);
          await new Promise(resolve => setTimeout(resolve, delay));
          return createProfileForUser(userId, retryCount + 1);
        }
        
        return false;
      } else {
        console.log('Profile created successfully:', data);
        setProfile(data);
        return true;
      }
    } catch (error) {
      console.error('Error in createProfileForUser:', error);
      
      // Retry on exception
      if (retryCount < 3) {
        const delay = Math.pow(2, retryCount) * 1000;
        console.log(`Retrying profile creation after exception in ${delay}ms...`);
        await new Promise(resolve => setTimeout(resolve, delay));
        return createProfileForUser(userId, retryCount + 1);
      }
      
      return false;
    }
  };

  const fetchProfile = useCallback(async (userId: string, forceRefresh = false) => {
    try {
      console.log('Fetching profile for user:', userId, 'forceRefresh:', forceRefresh);
      
      // Use a simple select to avoid RLS recursion issues
      const { data, error } = await supabase
        .from('profiles')
        .select('id, email, full_name, role, phone, avatar_url, is_active, created_at, updated_at')
        .eq('id', userId)
        .maybeSingle();

      if (error) {
        console.error('Error fetching profile:', error);
        
        // If profile doesn't exist, try to create it
        if (error.code === 'PGRST116') {
          console.log('Profile not found, attempting to create...');
          const created = await createProfileForUser(userId);
          if (!created) {
            console.error('Failed to create profile after retries');
          }
        }
      } else if (data) {
        console.log('Profile fetched successfully:', {
          email: data.email,
          role: data.role,
          full_name: data.full_name
        });
        setProfile(data);
      } else {
        console.log('No profile found for user, attempting to create...');
        // Try to create profile if it doesn't exist
        await createProfileForUser(userId);
      }
    } catch (error) {
      console.error('Error in fetchProfile:', error);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    // Get initial session
    supabase.auth.getSession().then(({ data: { session }, error }) => {
      if (error) {
        console.error('Error getting session:', error);
      }
      console.log('Initial session:', session?.user?.email);
      setSession(session);
      setUser(session?.user ?? null);
      if (session?.user) {
        fetchProfile(session.user.id, true); // Force refresh on initial load
        // Register for push notifications on login
        registerPushNotifications();
      } else {
        setLoading(false);
      }
    });

    // Listen for auth changes
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      console.log('Auth state changed:', _event, session?.user?.email);
      setSession(session);
      setUser(session?.user ?? null);
      if (session?.user) {
        // Force refresh profile on sign in to get latest data
        fetchProfile(session.user.id, _event === 'SIGNED_IN');
        // Register for push notifications on login
        if (_event === 'SIGNED_IN') {
          registerPushNotifications();
        }
      } else {
        setProfile(null);
        setLoading(false);
      }
    });

    return () => subscription.unsubscribe();
  }, [fetchProfile]);

  const refreshProfile = async () => {
    if (user) {
      console.log('Manually refreshing profile for user:', user.email);
      await fetchProfile(user.id, true);
    }
  };

  const signIn = async (email: string, password: string) => {
    try {
      console.log('Signing in user:', email);
      const { data, error } = await supabase.auth.signInWithPassword({
        email: email.trim().toLowerCase(),
        password,
      });

      if (error) {
        console.error('Sign in error:', error);
      } else {
        console.log('Sign in successful:', data.user?.email);
      }

      return { error };
    } catch (error) {
      console.error('Unexpected error in signIn:', error);
      return { error };
    }
  };

  const signUp = async (email: string, password: string, fullName: string) => {
    try {
      console.log('Signing up user:', email);
      const { data, error } = await supabase.auth.signUp({
        email: email.trim().toLowerCase(),
        password,
        options: {
          emailRedirectTo: 'https://natively.dev/email-confirmed',
          data: {
            full_name: fullName,
            role: 'viewer', // Default role for new users
          },
        },
      });

      if (error) {
        console.error('Sign up error:', error);
        return { error };
      }

      console.log('Sign up successful:', data.user?.email);

      // If user was created but profile creation failed, try to create it manually
      if (data.user && !error) {
        // Wait a bit for the trigger to complete
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        // Check if profile was created
        const { data: profileData } = await supabase
          .from('profiles')
          .select('id')
          .eq('id', data.user.id)
          .maybeSingle();

        if (!profileData) {
          console.log('Profile not created by trigger, creating manually...');
          await createProfileForUser(data.user.id);
        }
      }

      return { error };
    } catch (error) {
      console.error('Unexpected error in signUp:', error);
      return { error };
    }
  };

  const signOut = async () => {
    try {
      console.log('Signing out user');
      
      // Remove push token before signing out
      if (user?.id) {
        await NotificationService.removePushToken(user.id);
      }
      
      await supabase.auth.signOut();
    } catch (error) {
      console.error('Error in signOut:', error);
    }
  };

  return (
    <AuthContext.Provider
      value={{
        session,
        user,
        profile,
        loading,
        signIn,
        signUp,
        signOut,
        refreshProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}

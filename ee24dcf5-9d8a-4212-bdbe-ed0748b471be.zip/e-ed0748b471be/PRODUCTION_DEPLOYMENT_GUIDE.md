
# Guía de Despliegue a Producción

Esta guía detalla los pasos necesarios para preparar y desplegar la aplicación de pedidos WhatsApp a producción.

## ✅ Checklist Pre-Producción

### 1. Seguridad de Base de Datos ✅
- [x] Políticas RLS optimizadas y consolidadas
- [x] Funciones de base de datos con `search_path` seguro
- [x] Índices agregados para claves foráneas
- [x] Índices no utilizados eliminados
- [x] Políticas múltiples consolidadas en la tabla `profiles`

### 2. Configuración de Supabase

#### 2.1 Habilitar Protección de Contraseñas Filtradas
1. Ve a **Authentication > Settings** en el dashboard de Supabase
2. Habilita **"Leaked Password Protection"**
3. Esto verificará las contraseñas contra la base de datos HaveIBeenPwned

#### 2.2 Verificar Edge Functions
- [x] `whatsapp-webhook`: JWT deshabilitado (requerido por Meta)
- [x] `send-email`: JWT habilitado
- [x] `send-push-notification`: JWT habilitado
- [x] `send-whatsapp-status`: JWT habilitado
- [x] `send-whatsapp-product-added`: JWT habilitado

#### 2.3 Variables de Entorno
Asegúrate de que todas las variables de entorno estén configuradas en Supabase:
```bash
# En Supabase Dashboard > Edge Functions > Settings
WHATSAPP_ACCESS_TOKEN=tu_token_de_acceso
WHATSAPP_PHONE_NUMBER_ID=tu_phone_number_id
WHATSAPP_VERIFY_TOKEN=tu_verify_token
RESEND_API_KEY=tu_resend_api_key
```

### 3. Configuración de la Aplicación

#### 3.1 Actualizar app.json ✅
- [x] Nombre de la app actualizado
- [x] Bundle identifiers configurados
- [x] Permisos de Android/iOS configurados
- [x] Configuración de notificaciones push
- [x] ProGuard habilitado para Android
- [x] Optimizaciones de recursos habilitadas

#### 3.2 Configurar EAS Build ✅
- [x] Perfiles de build configurados (development, preview, production)
- [x] Variables de entorno por ambiente
- [x] Configuración de submit para stores

### 4. Optimizaciones de Rendimiento ✅
- [x] Índices compuestos creados para consultas frecuentes
- [x] Políticas RLS optimizadas con `SELECT` wrapper
- [x] Rate limiting configurado en Realtime
- [x] PKCE flow habilitado para autenticación

### 5. Monitoreo y Logging ✅
- [x] Error logger mejorado con niveles de severidad
- [x] Sanitización de datos sensibles en producción
- [x] Logging condicional según ambiente
- [x] Preparado para integración con Sentry/Bugsnag

## 🚀 Pasos de Despliegue

### Paso 1: Verificar Migraciones
```bash
# Las migraciones ya fueron aplicadas:
# - production_security_hardening
# - optimize_rls_policies_performance
# - consolidate_profiles_rls_policies
```

### Paso 2: Configurar EAS Project
```bash
# Instalar EAS CLI si no lo tienes
npm install -g eas-cli

# Login a tu cuenta de Expo
eas login

# Configurar el proyecto
eas build:configure
```

### Paso 3: Build para Preview (Pruebas Internas)
```bash
# Android APK para pruebas
eas build --platform android --profile preview

# iOS para TestFlight
eas build --platform ios --profile preview
```

### Paso 4: Build para Producción
```bash
# Android App Bundle para Google Play
eas build --platform android --profile production

# iOS para App Store
eas build --platform ios --profile production
```

### Paso 5: Submit a las Stores
```bash
# Configurar credenciales primero
# Android: google-service-account.json
# iOS: Apple ID y Team ID en eas.json

# Submit a Google Play
eas submit --platform android --profile production

# Submit a App Store
eas submit --platform ios --profile production
```

## 🔒 Seguridad Adicional

### WhatsApp Webhook Security
El webhook de WhatsApp no puede usar JWT (Meta no lo soporta), pero implementa:
1. **Verify Token**: Validación en el handshake inicial
2. **Signature Verification**: Verifica la firma de Meta en cada request
3. **IP Whitelisting**: Considera agregar whitelist de IPs de Meta

### Recomendaciones de Seguridad
1. **Rotar Tokens Regularmente**: Cambia los tokens de acceso cada 3-6 meses
2. **Monitorear Logs**: Revisa los logs de Edge Functions regularmente
3. **Rate Limiting**: Implementa rate limiting en el webhook si es necesario
4. **Backup de Base de Datos**: Configura backups automáticos en Supabase

## 📊 Monitoreo Post-Despliegue

### Métricas a Monitorear
1. **Supabase Dashboard**:
   - Database performance
   - Edge Function invocations
   - Auth metrics
   - Storage usage

2. **Logs a Revisar**:
   ```bash
   # Ver logs de Edge Functions
   supabase functions logs whatsapp-webhook
   supabase functions logs send-whatsapp-status
   ```

3. **Advisors de Supabase**:
   - Ejecutar security advisor mensualmente
   - Ejecutar performance advisor semanalmente

### Alertas Recomendadas
1. Errores en Edge Functions > 5% de requests
2. Latencia de base de datos > 500ms
3. Fallos de autenticación > 10% de intentos
4. Uso de almacenamiento > 80%

## 🐛 Troubleshooting

### Problema: Pedidos no se imprimen automáticamente
- Verificar que `auto_print_enabled` esté en `true` en `user_settings`
- Verificar conexión Bluetooth con la impresora
- Revisar logs de `BluetoothPrinterService`

### Problema: Notificaciones push no llegan
- Verificar que el token push esté registrado en `push_tokens`
- Verificar permisos de notificaciones en el dispositivo
- Revisar logs de `send-push-notification` Edge Function

### Problema: WhatsApp webhook no recibe mensajes
- Verificar que el webhook esté configurado en Meta Developer Console
- Verificar que el `verify_token` coincida
- Revisar logs de `whatsapp-webhook` Edge Function

## 📱 Testing en Producción

### Checklist de Testing
- [ ] Crear pedido manual
- [ ] Recibir pedido por WhatsApp
- [ ] Imprimir pedido automáticamente
- [ ] Cambiar estado de pedido
- [ ] Enviar notificación de estado por WhatsApp
- [ ] Recibir notificación push
- [ ] Gestionar usuarios (admin)
- [ ] Configurar impresora Bluetooth
- [ ] Configurar WhatsApp

## 🔄 Actualizaciones Futuras

### OTA Updates con EAS Update
```bash
# Publicar actualización OTA
eas update --branch production --message "Fix: descripción del fix"
```

### Versionado
- **Major (1.x.x)**: Cambios que rompen compatibilidad
- **Minor (x.1.x)**: Nuevas funcionalidades
- **Patch (x.x.1)**: Bug fixes

## 📞 Soporte

### Recursos
- [Documentación de Expo](https://docs.expo.dev/)
- [Documentación de Supabase](https://supabase.com/docs)
- [WhatsApp Business API](https://developers.facebook.com/docs/whatsapp)

### Contacto
Para soporte técnico, contactar al equipo de desarrollo.

---

**Última actualización**: Enero 2025
**Versión de la app**: 1.0.0
**Estado**: ✅ Lista para producción

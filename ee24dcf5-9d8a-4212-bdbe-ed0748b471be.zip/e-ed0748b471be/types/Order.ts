
export type OrderStatus = 'pending' | 'preparing' | 'ready' | 'delivered' | 'cancelled';
export type OrderSource = 'manual' | 'whatsapp' | 'web';

export interface OrderItem {
  id: string;
  name: string;
  quantity: number;
  price: number;
  notes?: string;
}

export interface Order {
  id: string;
  orderNumber: string;
  customerName: string;
  customerPhone: string;
  customerAddress?: string;
  items: OrderItem[];
  totalAmount: number;
  status: OrderStatus;
  source?: OrderSource;
  createdAt: Date;
  notes?: string;
  whatsappMessageId?: string;
  printed?: boolean;
  printedAt?: Date;
}

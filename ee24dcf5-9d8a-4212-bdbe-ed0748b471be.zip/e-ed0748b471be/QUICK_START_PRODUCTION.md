
# 🚀 Inicio Rápido - Despliegue a Producción

## ⏱️ Tiempo Estimado: 2-4 horas

Esta guía te llevará desde el estado actual hasta tener la app en las stores en el menor tiempo posible.

## 📋 Pre-requisitos

- [ ] Cuenta de Expo/EAS
- [ ] Cuenta de Google Play Developer ($25 USD una vez)
- [ ] Cuenta de Apple Developer ($99 USD/año)
- [ ] Acceso al dashboard de Supabase
- [ ] Acceso a Meta Developer Console (WhatsApp)

## 🎯 Paso 1: Configuración de Supabase (15 min)

### 1.1 Habilitar Protección de Contraseñas
```
1. Ir a: https://supabase.com/dashboard/project/stxrvyxkxclezgcijhio
2. Authentication > Settings
3. Buscar "Password Protection"
4. Toggle ON "Check against HaveIBeenPwned database"
5. Guardar cambios
```

### 1.2 Verificar Edge Functions
```
1. Edge Functions > whatsapp-webhook
2. Verificar que JWT está deshabilitado ✅
3. Verificar que las demás funciones tienen JWT habilitado ✅
```

### 1.3 Rotar Tokens (Opcional pero Recomendado)
```
1. Meta Developer Console > WhatsApp > API Setup
2. Generar nuevo Access Token
3. Supabase > Edge Functions > Settings
4. Actualizar WHATSAPP_ACCESS_TOKEN
5. Actualizar WHATSAPP_VERIFY_TOKEN si cambió
```

## 🎯 Paso 2: Configuración de EAS (20 min)

### 2.1 Instalar EAS CLI
```bash
npm install -g eas-cli
```

### 2.2 Login a Expo
```bash
eas login
# Ingresa tus credenciales de Expo
```

### 2.3 Configurar Proyecto
```bash
# En el directorio del proyecto
eas build:configure

# Esto creará/actualizará eas.json
# Acepta los valores por defecto
```

### 2.4 Actualizar app.json con tu Project ID
```json
{
  "expo": {
    "extra": {
      "eas": {
        "projectId": "TU_PROJECT_ID_AQUI"
      }
    }
  }
}
```

Para obtener tu Project ID:
```bash
eas project:info
```

## 🎯 Paso 3: Documentos Legales (30 min)

### 3.1 Crear Política de Privacidad
Usa una plantilla como [PrivacyPolicies.com](https://www.privacypolicies.com/) o crea una simple:

```markdown
# Política de Privacidad

Última actualización: [FECHA]

## Información que Recopilamos
- Nombre y correo electrónico (para autenticación)
- Número de teléfono (para pedidos por WhatsApp)
- Información de pedidos

## Cómo Usamos la Información
- Procesar y gestionar pedidos
- Enviar notificaciones sobre el estado de pedidos
- Mejorar nuestro servicio

## Seguridad
Usamos Supabase para almacenar datos de forma segura con encriptación.

## Contacto
[TU_EMAIL]
```

### 3.2 Crear Términos de Servicio
```markdown
# Términos de Servicio

Última actualización: [FECHA]

## Uso del Servicio
Esta aplicación es para gestionar pedidos de tu negocio.

## Responsabilidades del Usuario
- Mantener credenciales seguras
- Usar la app de forma apropiada
- No compartir información sensible

## Limitación de Responsabilidad
La app se proporciona "tal cual" sin garantías.

## Contacto
[TU_EMAIL]
```

### 3.3 Publicar Documentos
Opción 1: Crear páginas en tu sitio web
Opción 2: Usar GitHub Pages
Opción 3: Usar Google Docs (público)

Actualiza los enlaces en `app/settings.tsx`:
```typescript
const openPrivacyPolicy = () => {
  Linking.openURL('https://tu-sitio.com/privacy');
};

const openTermsOfService = () => {
  Linking.openURL('https://tu-sitio.com/terms');
};
```

## 🎯 Paso 4: Preview Build (30 min)

### 4.1 Build para Android
```bash
eas build --platform android --profile preview
```

Esto tomará ~15-20 minutos. Recibirás un link para descargar el APK.

### 4.2 Build para iOS (Opcional)
```bash
eas build --platform ios --profile preview
```

Nota: Necesitas una cuenta de Apple Developer para iOS.

### 4.3 Instalar y Probar
1. Descargar APK del link que te envía EAS
2. Instalar en dispositivo Android
3. Probar todos los flujos:
   - Login
   - Crear pedido manual
   - Recibir pedido por WhatsApp
   - Imprimir pedido
   - Cambiar estado
   - Notificaciones

## 🎯 Paso 5: Production Build (30 min)

### 5.1 Preparar Assets para Stores

#### Screenshots Necesarios
**Android (Google Play):**
- Mínimo 2 screenshots
- Tamaño: 1080x1920 o 1080x2340
- Formato: PNG o JPG

**iOS (App Store):**
- Mínimo 3 screenshots por tamaño de dispositivo
- Tamaños: 6.5", 5.5", 12.9"
- Formato: PNG o JPG

#### Descripción de la App
```
Título: Pedidos WhatsApp - Gestión de Pedidos

Descripción Corta:
Gestiona pedidos de WhatsApp con impresión automática y notificaciones en tiempo real.

Descripción Larga:
Pedidos WhatsApp es la solución completa para gestionar pedidos de tu negocio:

✅ Recibe pedidos automáticamente por WhatsApp
✅ Imprime pedidos en impresoras Bluetooth de 80mm
✅ Notificaciones push en tiempo real
✅ Gestión de usuarios con diferentes roles
✅ Envía actualizaciones de estado por WhatsApp
✅ Interfaz intuitiva y fácil de usar

Características:
• Integración completa con WhatsApp Business API
• Impresión automática de pedidos nuevos
• Control de usuarios (Admin, Manager, Operator, Viewer)
• Notificaciones push para pedidos nuevos
• Historial completo de pedidos
• Cambio de estado de pedidos
• Envío de confirmaciones por WhatsApp

Ideal para:
• Verdulerías
• Tiendas de abarrotes
• Restaurantes
• Cualquier negocio que reciba pedidos por WhatsApp
```

### 5.2 Build de Producción

#### Android
```bash
eas build --platform android --profile production
```

Esto genera un App Bundle (.aab) para Google Play.

#### iOS
```bash
eas build --platform ios --profile production
```

Esto genera un archivo .ipa para App Store.

## 🎯 Paso 6: Submit a Stores (1-2 horas)

### 6.1 Google Play Console

1. **Crear App**
   - Ir a [Google Play Console](https://play.google.com/console)
   - Crear aplicación
   - Nombre: "Pedidos WhatsApp"
   - Idioma: Español
   - Tipo: App

2. **Configurar Ficha de Play Store**
   - Descripción corta y larga
   - Subir screenshots
   - Icono de la app (512x512)
   - Gráfico de funciones (1024x500)
   - Categoría: Productividad o Negocios

3. **Configurar Contenido**
   - Clasificación de contenido
   - Público objetivo
   - Política de privacidad (URL)

4. **Subir App Bundle**
   ```bash
   eas submit --platform android --profile production
   ```
   
   O manualmente:
   - Producción > Crear nueva versión
   - Subir el .aab generado por EAS
   - Completar notas de la versión

5. **Enviar a Revisión**
   - Revisar todo
   - Enviar a revisión (toma 1-3 días)

### 6.2 App Store Connect

1. **Crear App**
   - Ir a [App Store Connect](https://appstoreconnect.apple.com)
   - Mis Apps > + > Nueva App
   - Plataforma: iOS
   - Nombre: "Pedidos WhatsApp"
   - Idioma: Español
   - Bundle ID: com.pedidos.whatsapp
   - SKU: pedidos-whatsapp

2. **Configurar Información de la App**
   - Descripción
   - Palabras clave
   - URL de soporte
   - URL de marketing
   - Política de privacidad (URL)

3. **Subir Screenshots**
   - iPhone 6.5"
   - iPhone 5.5"
   - iPad Pro 12.9"

4. **Subir Build**
   ```bash
   eas submit --platform ios --profile production
   ```
   
   O usar Transporter app de Apple.

5. **Configurar Versión**
   - Seleccionar build subido
   - Completar información de versión
   - Configurar disponibilidad

6. **Enviar a Revisión**
   - Revisar todo
   - Enviar a revisión (toma 1-3 días)

## 🎯 Paso 7: Post-Despliegue (Continuo)

### 7.1 Monitoreo Inmediato (Primeras 48 horas)

```bash
# Ver logs de Edge Functions
supabase functions logs whatsapp-webhook --follow
supabase functions logs send-whatsapp-status --follow
```

### 7.2 Verificar Métricas
- Supabase Dashboard > Database > Performance
- Supabase Dashboard > Edge Functions > Invocations
- Google Play Console > Estadísticas
- App Store Connect > Analytics

### 7.3 Responder a Reviews
- Configurar alertas para nuevas reviews
- Responder en menos de 24 horas
- Agradecer feedback positivo
- Resolver problemas reportados

## ✅ Checklist Final

### Antes de Submit
- [ ] Leaked password protection habilitada
- [ ] Tokens rotados (opcional)
- [ ] EAS project configurado
- [ ] Política de privacidad publicada
- [ ] Términos de servicio publicados
- [ ] Preview build probado
- [ ] Screenshots preparados
- [ ] Descripción de la app escrita
- [ ] Icono de la app listo

### Durante Submit
- [ ] App Bundle/IPA generado
- [ ] Ficha de Play Store completa
- [ ] App Store Connect configurado
- [ ] Builds subidos
- [ ] Enviado a revisión

### Después de Submit
- [ ] Monitoreo activo
- [ ] Logs revisados
- [ ] Métricas verificadas
- [ ] Plan de soporte establecido

## 🆘 Troubleshooting Rápido

### Build Falla
```bash
# Limpiar caché
npm cache clean --force
rm -rf node_modules
npm install

# Intentar de nuevo
eas build --platform android --profile preview --clear-cache
```

### App Rechazada
- Leer cuidadosamente el motivo del rechazo
- Corregir el problema
- Incrementar version en app.json
- Rebuild y resubmit

### WhatsApp No Funciona
- Verificar tokens en Supabase Edge Functions
- Verificar webhook URL en Meta Developer Console
- Revisar logs de whatsapp-webhook

### Impresora No Conecta
- Verificar permisos Bluetooth
- Verificar que la impresora está encendida
- Probar con otra impresora
- Revisar logs de BluetoothPrinterService

## 📞 Recursos de Ayuda

- **Expo/EAS**: https://docs.expo.dev/
- **Supabase**: https://supabase.com/docs
- **Google Play**: https://support.google.com/googleplay/android-developer
- **App Store**: https://developer.apple.com/support/

## 🎉 ¡Éxito!

Si completaste todos los pasos, tu app está:
- ✅ Optimizada para producción
- ✅ Segura y con best practices
- ✅ En revisión en las stores
- ✅ Lista para recibir usuarios

**Tiempo total estimado**: 4-6 horas (sin contar tiempos de build y revisión de stores)

---

**Próximos pasos después de la aprobación**:
1. Anunciar el lanzamiento
2. Invitar a usuarios beta
3. Recopilar feedback
4. Planear próximas features
5. Mantener la app actualizada

¡Buena suerte con tu lanzamiento! 🚀

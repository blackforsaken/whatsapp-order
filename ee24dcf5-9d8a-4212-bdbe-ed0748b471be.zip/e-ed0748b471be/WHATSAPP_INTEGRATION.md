
# Integración de WhatsApp - Documentación Técnica

## Arquitectura General

La integración de WhatsApp permite recibir pedidos automáticamente a través de mensajes de WhatsApp y crearlos en la base de datos de la aplicación.

```
Cliente WhatsApp
    ↓
WhatsApp Business API
    ↓
Webhook (Edge Function)
    ↓
Parser de Mensajes
    ↓
Base de Datos (Supabase)
    ↓
Notificaciones Push
    ↓
Usuarios de la App
```

## Componentes

### 1. Edge Function: whatsapp-webhook

**Ubicación**: `supabase/functions/whatsapp-webhook/index.ts`

**Responsabilidades**:
- Recibir webhooks de WhatsApp Business API
- Verificar el webhook (GET request)
- Procesar mensajes entrantes (POST request)
- Parsear mensajes para extraer items del pedido
- Crear órdenes en la base de datos
- Enviar notificaciones a usuarios
- Enviar confirmación al cliente

**Endpoints**:
- `GET /functions/v1/whatsapp-webhook` - Verificación del webhook
- `POST /functions/v1/whatsapp-webhook` - Recepción de mensajes

### 2. Parser de Mensajes

**Función**: `parseOrderFromMessage(message: string): OrderItem[]`

**Patrones Soportados**:

1. **Pattern 1**: `2 pizzas $10` o `2x pizzas $10`
   - Regex: `/(\\d+)\\s*x?\\s*([^$\\n]+?)\\s*\\$\\s*(\\d+(?:\\.\\d{1,2})?)/gi`

2. **Pattern 2**: `pizzas: 2 $10` o `pizzas 2 $10`
   - Regex: `/([^:\\n\\d$]+?)\\s*:?\\s*(\\d+)\\s*\\$\\s*(\\d+(?:\\.\\d{1,2})?)/gi`

3. **Pattern 3**: `2 pizzas - $10` o `2 pizzas - 10`
   - Regex: `/(\\d+)\\s*([^-\\n$]+?)\\s*-\\s*\\$?\\s*(\\d+(?:\\.\\d{1,2})?)/gi`

4. **Pattern 4**: `pizzas $10 x2` o `pizzas $10 cantidad 2`
   - Regex: `/([^$\\n]+?)\\s*\\$\\s*(\\d+(?:\\.\\d{1,2})?)\\s*(?:x|cantidad)?\\s*(\\d+)/gi`

**Características**:
- Prueba múltiples patrones en orden
- Se detiene en el primer patrón exitoso
- Fallback a parsing línea por línea
- Fusiona items duplicados
- Normaliza nombres de productos

### 3. Creación de Órdenes

**Proceso**:

1. **Generar número de orden**:
   ```typescript
   const orderNumber = `WA-${Date.now()}`;
   ```

2. **Calcular total**:
   ```typescript
   const totalAmount = orderItems.reduce(
     (sum, item) => sum + item.price * item.quantity,
     0
   );
   ```

3. **Insertar orden**:
   ```typescript
   await supabaseClient.from('orders').insert({
     order_number: orderNumber,
     customer_name: customerName,
     customer_phone: customerPhone,
     status: 'pending',
     total_amount: totalAmount,
     whatsapp_message_id: messageId,
     notes: `Pedido recibido por WhatsApp\n\nMensaje original:\n${messageText}`,
   });
   ```

4. **Insertar items**:
   ```typescript
   await supabaseClient.from('order_items').insert(itemsToInsert);
   ```

### 4. Sistema de Notificaciones

**Notificaciones en Base de Datos**:
```typescript
const notifications = activeUsers.map((user) => ({
  user_id: user.id,
  type: 'new_order',
  title: 'Nuevo pedido de WhatsApp',
  message: `Pedido ${orderNumber} de ${customerName}`,
  order_id: order.id,
}));

await supabaseClient.from('notifications').insert(notifications);
```

**Push Notifications**:
```typescript
await supabaseClient.functions.invoke('send-push-notification', {
  body: {
    userIds,
    title: 'Nuevo pedido de WhatsApp',
    message: `Pedido ${orderNumber} de ${customerName}`,
    data: {
      type: 'new_order',
      orderId: order.id,
      orderNumber,
    },
  },
});
```

### 5. Confirmación al Cliente

**Mensaje de Confirmación**:
```typescript
await sendWhatsAppMessage(
  customerPhone,
  `✅ ¡Pedido recibido!\n\n` +
  `Número de pedido: ${orderNumber}\n\n` +
  `Resumen:\n${itemsList}\n\n` +
  `Total: $${totalAmount.toFixed(2)}\n\n` +
  `Gracias por tu pedido. Te notificaremos cuando esté listo.`
);
```

**Mensaje de Error**:
```typescript
await sendWhatsAppMessage(
  customerPhone,
  'No pude entender tu pedido. Por favor, envía tu pedido en el siguiente formato:\n\n' +
  'Ejemplo:\n' +
  '2 pizzas $10\n' +
  '1 refresco $2\n' +
  '3 hamburguesas $5'
);
```

## Flujo de Datos

### Recepción de Mensaje

```typescript
WhatsApp → Webhook → processWhatsAppMessage()
                          ↓
                    parseOrderFromMessage()
                          ↓
                    Crear orden en DB
                          ↓
                    Crear items en DB
                          ↓
                    Crear notificaciones
                          ↓
                    Enviar push notifications
                          ↓
                    Enviar confirmación WhatsApp
```

### Estructura de Datos

**Mensaje de WhatsApp (Entrada)**:
```json
{
  "entry": [{
    "changes": [{
      "value": {
        "messages": [{
          "from": "1234567890",
          "id": "wamid.xxx",
          "text": {
            "body": "2 pizzas $10\n1 refresco $2"
          }
        }],
        "contacts": [{
          "profile": {
            "name": "Juan Pérez"
          }
        }]
      }
    }]
  }]
}
```

**Orden Creada (Salida)**:
```json
{
  "id": "uuid",
  "order_number": "WA-1234567890",
  "customer_name": "Juan Pérez",
  "customer_phone": "1234567890",
  "status": "pending",
  "total_amount": 12,
  "whatsapp_message_id": "wamid.xxx",
  "notes": "Pedido recibido por WhatsApp...",
  "created_at": "2024-01-01T00:00:00Z"
}
```

**Items de Orden**:
```json
[
  {
    "id": "uuid",
    "order_id": "uuid",
    "name": "pizzas",
    "quantity": 2,
    "price": 10
  },
  {
    "id": "uuid",
    "order_id": "uuid",
    "name": "refresco",
    "quantity": 1,
    "price": 2
  }
]
```

## Variables de Entorno

| Variable | Descripción | Requerida |
|----------|-------------|-----------|
| `WHATSAPP_VERIFY_TOKEN` | Token para verificar el webhook | Sí |
| `WHATSAPP_ACCESS_TOKEN` | Token de acceso de WhatsApp Business API | Sí |
| `WHATSAPP_PHONE_NUMBER_ID` | ID del número de teléfono de WhatsApp | Sí |
| `SUPABASE_URL` | URL del proyecto de Supabase | Sí (auto) |
| `SUPABASE_SERVICE_ROLE_KEY` | Service role key de Supabase | Sí (auto) |

## Manejo de Errores

### Errores de Parsing

Si no se pueden extraer items del mensaje:
1. Se registra en logs: `"No se pudieron extraer items del mensaje"`
2. Se envía mensaje de ayuda al cliente
3. No se crea la orden

### Errores de Base de Datos

Si falla la creación de la orden:
1. Se registra el error en logs
2. Se envía mensaje de error al cliente
3. No se crean notificaciones

### Errores de Notificaciones

Si fallan las notificaciones push:
1. Se registra el error en logs
2. La orden se crea exitosamente
3. Las notificaciones en DB se crean
4. Solo fallan las push notifications

### Errores de Confirmación

Si falla el envío de confirmación:
1. Se registra el error en logs
2. La orden se crea exitosamente
3. Las notificaciones se envían
4. El cliente no recibe confirmación

## Seguridad

### Verificación del Webhook

```typescript
if (mode === 'subscribe' && token === verifyToken) {
  return new Response(challenge, {
    headers: { ...corsHeaders, 'Content-Type': 'text/plain' },
  });
}
```

### Autenticación

- Se usa `SUPABASE_SERVICE_ROLE_KEY` para operaciones de base de datos
- Se valida el `WHATSAPP_VERIFY_TOKEN` en la verificación del webhook
- Se usa `WHATSAPP_ACCESS_TOKEN` para enviar mensajes

### CORS

```typescript
const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};
```

## Testing

### Prueba Manual

1. Envía un mensaje de WhatsApp:
   ```
   2 pizzas $10
   1 refresco $2
   ```

2. Verifica en logs:
   ```
   Processing message from 1234567890: 2 pizzas $10...
   Order created: uuid
   Push notifications sent successfully
   WhatsApp message sent successfully
   Order processed successfully
   ```

3. Verifica en la app:
   - Aparece nuevo pedido
   - Notificación push recibida
   - Notificación en lista de notificaciones

### Prueba de Patrones

Prueba diferentes formatos:
```
2 pizzas $10
2x pizzas $10
pizzas: 2 $10
2 pizzas - $10
pizzas $10 x2
```

Todos deben crear el mismo item:
```json
{
  "name": "pizzas",
  "quantity": 2,
  "price": 10
}
```

## Monitoreo

### Métricas Clave

1. **Tasa de éxito de parsing**: % de mensajes parseados correctamente
2. **Tiempo de procesamiento**: Tiempo desde recepción hasta confirmación
3. **Tasa de error**: % de mensajes que fallan
4. **Órdenes creadas**: Número de órdenes por día/hora

### Logs Importantes

```typescript
console.log('Processing message from ${customerPhone}: ${messageText}');
console.log('Order created:', order.id);
console.log('Push notifications sent successfully');
console.log('WhatsApp message sent successfully');
console.log('Order processed successfully');
```

### Alertas

Configurar alertas para:
- Errores de base de datos
- Fallos de parsing frecuentes
- Errores de envío de mensajes
- Tiempo de procesamiento alto

## Optimizaciones

### Performance

1. **Parsing Paralelo**: Los patrones se prueban secuencialmente, pero se podría paralelizar
2. **Caché de Usuarios**: Cachear lista de usuarios activos
3. **Batch Notifications**: Agrupar notificaciones en un solo insert

### Escalabilidad

1. **Rate Limiting**: Implementar límite de mensajes por minuto
2. **Queue System**: Usar cola para procesar mensajes en orden
3. **Retry Logic**: Reintentar operaciones fallidas

### Mejoras Futuras

1. **Machine Learning**: Mejorar parsing con ML
2. **Catálogo**: Integrar con catálogo de productos
3. **Validación**: Validar productos contra inventario
4. **Precios Dinámicos**: Obtener precios de base de datos
5. **Multi-idioma**: Soportar múltiples idiomas

## Troubleshooting

### Problema: Webhook no recibe mensajes

**Solución**:
1. Verificar URL del webhook en Meta
2. Verificar que el token coincida
3. Revisar logs de Edge Function
4. Verificar que el webhook esté suscrito a eventos correctos

### Problema: Parsing falla

**Solución**:
1. Revisar formato del mensaje en logs
2. Agregar nuevo patrón si es necesario
3. Mejorar regex existente
4. Agregar logging más detallado

### Problema: Notificaciones no llegan

**Solución**:
1. Verificar que usuarios tengan tokens registrados
2. Verificar que Edge Function `send-push-notification` funcione
3. Revisar permisos de notificaciones en dispositivos
4. Verificar que usuarios estén activos

### Problema: Cliente no recibe confirmación

**Solución**:
1. Verificar `WHATSAPP_ACCESS_TOKEN`
2. Verificar `WHATSAPP_PHONE_NUMBER_ID`
3. Revisar logs de envío
4. Verificar que token no haya expirado

## Referencias

- [WhatsApp Business API Docs](https://developers.facebook.com/docs/whatsapp)
- [Supabase Edge Functions](https://supabase.com/docs/guides/functions)
- [Expo Push Notifications](https://docs.expo.dev/push-notifications/overview/)

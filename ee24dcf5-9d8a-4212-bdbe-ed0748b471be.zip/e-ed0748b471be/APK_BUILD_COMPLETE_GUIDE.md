
# Guía Completa para Construir APK - WhatsApp Order Printer

## 🔧 Solución al Error de react-native-gradle-plugin

El error que estabas experimentando se debe a problemas de resolución de dependencias de Gradle con el plugin `react-native-gradle-plugin`. He implementado las siguientes correcciones:

### ✅ Cambios Realizados

1. **Plugin de Configuración Mejorado** (`plugins/withCustomGradle.js`)
   - Configuración automática de `settings.gradle` para resolver correctamente el plugin
   - Configuración de repositorios Maven con HTTPS
   - Manejo de errores mejorado con logging

2. **Configuración de App Actualizada** (`app.config.js`)
   - Configuración unificada entre `app.json` y `app.config.js`
   - Propiedades de build optimizadas para Android
   - Plugins correctamente ordenados

## 📋 Pasos para Construir el APK

### Paso 1: Limpiar el Proyecto

Antes de construir, limpia todos los archivos de build anteriores:

```bash
# Eliminar carpeta android si existe
rm -rf android

# Limpiar caché de npm
npm cache clean --force

# Limpiar caché de Expo
npx expo start --clear
```

### Paso 2: Verificar Dependencias

Asegúrate de que todas las dependencias estén instaladas correctamente:

```bash
# Reinstalar dependencias
rm -rf node_modules
npm install

# Verificar que react-native esté instalado
ls -la node_modules/react-native/react-native-gradle-plugin
```

### Paso 3: Ejecutar Prebuild

Genera los archivos nativos de Android:

```bash
npx expo prebuild -p android --clean
```

Este comando:
- Elimina la carpeta `android/` existente
- Genera una nueva carpeta `android/` con la configuración correcta
- Aplica todos los plugins de configuración (incluyendo `withCustomGradle`)

### Paso 4: Verificar la Configuración de Gradle

Después del prebuild, verifica que los archivos de Gradle se hayan generado correctamente:

```bash
# Verificar settings.gradle
cat android/settings.gradle | grep "react-native-gradle-plugin"

# Verificar build.gradle
cat android/build.gradle | grep "mavenCentral"
```

### Paso 5: Construir el APK Localmente (Opcional)

Si quieres construir localmente para probar:

```bash
cd android
./gradlew clean
./gradlew assembleRelease
cd ..
```

El APK se generará en: `android/app/build/outputs/apk/release/app-release.apk`

### Paso 6: Construir con EAS Build (Recomendado)

Para producción, usa EAS Build:

```bash
# Instalar EAS CLI si no lo tienes
npm install -g eas-cli

# Login a tu cuenta de Expo
eas login

# Configurar el proyecto (si es la primera vez)
eas build:configure

# Construir APK para preview
eas build -p android --profile preview

# O construir para producción
eas build -p android --profile production
```

## 🔍 Solución de Problemas

### Error: "Could not find com.facebook.react:react-native-gradle-plugin"

**Solución:** Este error ya está resuelto con el nuevo plugin. Si persiste:

1. Verifica que `react-native` esté en `package.json`
2. Ejecuta `npm install` nuevamente
3. Elimina la carpeta `android/` y ejecuta `npx expo prebuild -p android --clean`

### Error: "Could not read script '/' as it is a directory"

**Solución:** Este error ocurre cuando `settings.gradle` tiene rutas incorrectas. El nuevo plugin lo previene.

### Error: Gradle daemon desaparece o se congela

**Solución:**

```bash
cd android
./gradlew --stop
cd ..
rm -rf android
npx expo prebuild -p android --clean
```

### Error: Repositorios inseguros (HTTP en lugar de HTTPS)

**Solución:** El nuevo plugin automáticamente configura todos los repositorios con HTTPS.

## 📱 Probar el APK

Una vez construido el APK:

1. **Transferir a dispositivo Android:**
   ```bash
   adb install android/app/build/outputs/apk/release/app-release.apk
   ```

2. **O descargar desde EAS Build:**
   - Ve a https://expo.dev
   - Navega a tu proyecto
   - Descarga el APK desde la sección de builds

3. **Habilitar instalación de fuentes desconocidas** en tu dispositivo Android

4. **Instalar y probar** todas las funcionalidades:
   - Login de usuarios
   - Recepción de pedidos por WhatsApp
   - Impresión Bluetooth
   - Notificaciones push

## 🚀 Optimizaciones Incluidas

El APK está configurado con:

- ✅ ProGuard habilitado (reduce tamaño y ofusca código)
- ✅ Shrink resources habilitado (elimina recursos no usados)
- ✅ Compilación optimizada para Android 14 (SDK 34)
- ✅ Soporte mínimo para Android 6.0 (SDK 23)
- ✅ Permisos de Bluetooth correctamente configurados
- ✅ Notificaciones push configuradas

## 📊 Tamaño Esperado del APK

- **Debug APK:** ~50-70 MB
- **Release APK (con ProGuard):** ~30-45 MB
- **AAB (Android App Bundle):** ~25-35 MB

## 🔐 Antes de Publicar en Play Store

1. **Generar keystore para firma:**
   ```bash
   keytool -genkeypair -v -storetype PKCS12 -keystore my-release-key.keystore -alias my-key-alias -keyalg RSA -keysize 2048 -validity 10000
   ```

2. **Configurar credenciales en EAS:**
   ```bash
   eas credentials
   ```

3. **Construir AAB en lugar de APK:**
   ```bash
   eas build -p android --profile production
   ```
   (Asegúrate de que `buildType` sea `"app-bundle"` en `eas.json` para producción)

## 📝 Checklist Final

Antes de considerar el APK listo para producción:

- [ ] El APK se construye sin errores
- [ ] La app se instala correctamente en dispositivos Android
- [ ] Login funciona correctamente
- [ ] Integración con WhatsApp funciona
- [ ] Impresora Bluetooth se conecta y imprime
- [ ] Notificaciones push se reciben
- [ ] Todas las pantallas se ven correctamente
- [ ] No hay crashes al usar la app
- [ ] Permisos se solicitan correctamente
- [ ] La app funciona sin conexión a internet (funcionalidades offline)

## 🆘 Soporte Adicional

Si encuentras algún error durante el build:

1. **Revisa los logs completos:**
   ```bash
   npx expo prebuild -p android --clean 2>&1 | tee build.log
   ```

2. **Verifica la versión de Gradle:**
   ```bash
   cd android
   ./gradlew --version
   ```

3. **Limpia completamente y reconstruye:**
   ```bash
   rm -rf android node_modules
   npm install
   npx expo prebuild -p android --clean
   ```

## ✨ Próximos Pasos

Una vez que el APK funcione correctamente:

1. Prueba exhaustivamente en múltiples dispositivos Android
2. Configura el build de producción con firma de código
3. Prepara los assets para la Play Store (screenshots, descripción, etc.)
4. Sube a Play Store en modo de prueba interna primero
5. Realiza pruebas beta con usuarios reales
6. Publica en producción

---

**Nota:** Todos los cambios realizados son compatibles con Expo 54 y React Native 0.81.4. El plugin personalizado se ejecuta automáticamente durante el prebuild, por lo que no necesitas modificar manualmente ningún archivo de Gradle.

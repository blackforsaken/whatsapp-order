
# ✅ Checklist de Verificación del Webhook de WhatsApp

Usa esta lista para verificar que todo esté configurado correctamente antes de intentar verificar el webhook en Meta.

## 📋 Paso 1: Verificar Supabase Edge Function

### 1.1 Edge Function Desplegada
- [ ] Ve a: https://supabase.com/dashboard/project/stxrvyxkxclezgcijhio/functions
- [ ] Verifica que existe la función `whatsapp-webhook`
- [ ] El estado debe ser "Active" o "Deployed"
- [ ] Si no existe, despliégala primero

### 1.2 Variables de Entorno Configuradas
- [ ] Ve a: https://supabase.com/dashboard/project/stxrvyxkxclezgcijhio/settings/functions
- [ ] Haz clic en "Secrets" o "Environment Variables"
- [ ] Verifica que existan estas variables:

```
✅ WHATSAPP_VERIFY_TOKEN
✅ WHATSAPP_ACCESS_TOKEN (opcional para verificación, pero necesario después)
✅ WHATSAPP_PHONE_NUMBER_ID (opcional para verificación, pero necesario después)
```

### 1.3 Valor del Token de Verificación
- [ ] El valor de `WHATSAPP_VERIFY_TOKEN` NO está vacío
- [ ] El valor NO contiene espacios al inicio o al final
- [ ] Copia el valor exacto (lo necesitarás para Meta)
- [ ] Guárdalo en un lugar seguro

**Ejemplo de valor válido**:
```
mi_token_secreto_2024
```

**Ejemplos de valores inválidos**:
```
❌ (vacío)
❌ " mi_token_secreto_2024" (espacio al inicio)
❌ "mi_token_secreto_2024 " (espacio al final)
```

## 📋 Paso 2: Probar el Webhook Manualmente

### 2.1 Prueba con curl

Abre una terminal y ejecuta:

```bash
curl "https://stxrvyxkxclezgcijhio.supabase.co/functions/v1/whatsapp-webhook?hub.mode=subscribe&hub.verify_token=TU_TOKEN_AQUI&hub.challenge=TEST123"
```

**Reemplaza `TU_TOKEN_AQUI` con tu token real**

### 2.2 Verificar Respuesta

**✅ Respuesta correcta**:
```
TEST123
```

Si recibes `TEST123`, ¡tu webhook está funcionando! Continúa al Paso 3.

**❌ Respuesta incorrecta**:
```
Forbidden
```

Si recibes `Forbidden`, el token no coincide. Verifica:
1. Que el token en el comando curl sea exactamente el mismo que en Supabase
2. Que no haya espacios adicionales
3. Que las mayúsculas/minúsculas coincidan

### 2.3 Verificar Logs

- [ ] Ve a: https://supabase.com/dashboard/project/stxrvyxkxclezgcijhio/functions/whatsapp-webhook/logs
- [ ] Deberías ver un log reciente que diga: "Webhook verification request"
- [ ] Si el token coincide, verás: "Webhook verified successfully"
- [ ] Si no coincide, verás: "Webhook verification failed"

## 📋 Paso 3: Configurar en Meta for Developers

### 3.1 Acceder a la Configuración

- [ ] Ve a: https://developers.facebook.com/apps
- [ ] Selecciona tu aplicación
- [ ] En el menú lateral, busca "WhatsApp"
- [ ] Haz clic en "Configuration" o "Configuración"

### 3.2 Configurar Webhook

- [ ] Busca la sección "Webhook"
- [ ] Haz clic en "Edit" o "Configure"

### 3.3 Ingresar URL del Webhook

En el campo "Callback URL", ingresa EXACTAMENTE:

```
https://stxrvyxkxclezgcijhio.supabase.co/functions/v1/whatsapp-webhook
```

**Verifica**:
- [ ] Comienza con `https://` (no `http://`)
- [ ] No hay espacios al inicio o al final
- [ ] El ID del proyecto es: `stxrvyxkxclezgcijhio`
- [ ] Termina en: `/whatsapp-webhook`
- [ ] No hay caracteres adicionales

### 3.4 Ingresar Token de Verificación

En el campo "Verify Token", ingresa el MISMO token que configuraste en Supabase.

**Verifica**:
- [ ] Es exactamente el mismo valor que `WHATSAPP_VERIFY_TOKEN` en Supabase
- [ ] No hay espacios al inicio o al final
- [ ] Las mayúsculas/minúsculas coinciden
- [ ] No hay caracteres adicionales

### 3.5 Verificar

- [ ] Haz clic en "Verify and Save"
- [ ] Espera la respuesta de Meta
- [ ] Deberías ver un mensaje de éxito ✅

## 📋 Paso 4: Suscribirse a Eventos

### 4.1 Seleccionar Eventos

Después de verificar el webhook:

- [ ] En la misma página, busca "Webhook fields"
- [ ] Marca la casilla de `messages`
- [ ] Marca la casilla de `message_status` (opcional)
- [ ] Haz clic en "Subscribe" o "Save"

### 4.2 Verificar Suscripción

- [ ] Los eventos deben mostrar un estado "Subscribed" o "Suscrito"
- [ ] Si no aparece, intenta suscribirte nuevamente

## 📋 Paso 5: Configurar Tokens de Acceso

### 5.1 Obtener Token de Acceso

- [ ] En Meta for Developers, ve a WhatsApp → Configuration
- [ ] Busca "Access Token" o "Token de Acceso"
- [ ] Copia el token (puede ser temporal o permanente)
- [ ] Guárdalo en un lugar seguro

### 5.2 Obtener Phone Number ID

- [ ] En la misma página, busca "Phone Number ID"
- [ ] Copia el ID del número de teléfono
- [ ] Guárdalo en un lugar seguro

### 5.3 Configurar en Supabase

- [ ] Ve a: https://supabase.com/dashboard/project/stxrvyxkxclezgcijhio/settings/functions
- [ ] Actualiza o agrega:

```
WHATSAPP_ACCESS_TOKEN=tu_token_de_acceso_aqui
WHATSAPP_PHONE_NUMBER_ID=tu_phone_number_id_aqui
```

### 5.4 Configurar en la App

- [ ] Abre la app
- [ ] Ve a Perfil → Configuración de WhatsApp
- [ ] Ingresa los mismos valores
- [ ] Haz clic en "Guardar Configuración"
- [ ] Deberías ver un mensaje de éxito

## 📋 Paso 6: Probar el Sistema Completo

### 6.1 Enviar Mensaje de Prueba

Desde tu teléfono personal, envía un mensaje al número de WhatsApp Business:

```
2 pizzas $10
1 refresco $2
```

### 6.2 Verificar Recepción

- [ ] Recibes un mensaje de confirmación en WhatsApp (en menos de 5 segundos)
- [ ] El mensaje incluye el número de pedido
- [ ] El mensaje incluye el resumen de items
- [ ] El mensaje incluye el total

### 6.3 Verificar en la App

- [ ] Abre la app
- [ ] Ve a la pantalla principal
- [ ] Deberías ver el nuevo pedido
- [ ] El pedido tiene estado "Pendiente"
- [ ] Los items están correctos
- [ ] El total es correcto

### 6.4 Verificar Notificaciones

- [ ] Recibes una notificación push (si estás en dispositivo físico)
- [ ] La notificación dice "Nuevo Pedido"
- [ ] Al tocar la notificación, se abre el pedido

### 6.5 Verificar Logs

- [ ] Ve a: https://supabase.com/dashboard/project/stxrvyxkxclezgcijhio/functions/whatsapp-webhook/logs
- [ ] Deberías ver logs recientes que incluyan:
  - "Processing message"
  - "Order created"
  - "WhatsApp message sent successfully"
  - "Push notifications sent successfully"

## 🎯 Resumen de Estados

### ✅ Todo Funciona Correctamente

Si todos estos puntos están marcados:
- ✅ Webhook verificado en Meta
- ✅ Eventos suscritos
- ✅ Variables de entorno configuradas
- ✅ Mensaje de prueba enviado
- ✅ Confirmación recibida en WhatsApp
- ✅ Pedido aparece en la app
- ✅ Notificación recibida

**¡Felicitaciones! Tu integración está funcionando perfectamente.** 🎉

### ⚠️ Problemas Comunes

Si algo no funciona, revisa:

1. **Webhook no verifica**:
   - Token de verificación no coincide
   - Edge Function no desplegada
   - URL incorrecta

2. **No recibe mensajes**:
   - Eventos no suscritos
   - Webhook no verificado
   - Edge Function con errores

3. **No crea pedidos**:
   - Formato de mensaje incorrecto
   - Error en base de datos
   - Permisos RLS

4. **No envía confirmación**:
   - `WHATSAPP_ACCESS_TOKEN` no configurado
   - `WHATSAPP_PHONE_NUMBER_ID` no configurado
   - Token expirado

5. **No envía notificaciones**:
   - No hay usuarios activos
   - Usuarios sin token de push
   - Edge Function `send-push-notification` no desplegada

## 📞 Obtener Ayuda

Si después de completar este checklist aún tienes problemas:

1. **Revisa los logs**:
   - Edge Function logs en Supabase
   - Webhook logs en Meta for Developers
   - Console logs en la app

2. **Documenta el problema**:
   - ¿Qué paso del checklist falló?
   - ¿Qué mensaje de error recibes?
   - ¿Qué ves en los logs?

3. **Información a incluir**:
   - Logs de la Edge Function (últimas 50 líneas)
   - Mensaje de prueba que enviaste
   - Respuesta que recibiste (si alguna)
   - Capturas de pantalla de errores

## 🔗 Enlaces Rápidos

- [Supabase Functions](https://supabase.com/dashboard/project/stxrvyxkxclezgcijhio/functions)
- [Supabase Secrets](https://supabase.com/dashboard/project/stxrvyxkxclezgcijhio/settings/functions)
- [Meta for Developers](https://developers.facebook.com/apps)
- [WhatsApp Webhook Logs](https://supabase.com/dashboard/project/stxrvyxkxclezgcijhio/functions/whatsapp-webhook/logs)

## 💡 Consejos Finales

1. **Paciencia**: Los cambios en variables de entorno pueden tardar 30-60 segundos
2. **Precisión**: Los tokens son sensibles a mayúsculas/minúsculas
3. **Logs**: Siempre revisa los logs cuando algo no funciona
4. **Pruebas**: Usa mensajes simples para probar (ej: "2 pizzas $10")
5. **Documentación**: Guarda tus tokens en un lugar seguro

¡Buena suerte! 🚀

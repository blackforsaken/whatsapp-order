
# Guía de Construcción de APK

## Problemas Corregidos

Se han corregido los siguientes problemas en la configuración:

1. ✅ **Package name unificado**: Ahora usa `com.pedidos.whatsapp` en Android e iOS
2. ✅ **Configuración EAS simplificada**: Removidos placeholders y URLs inválidas
3. ✅ **Configuración de Gradle optimizada**: Comandos específicos para cada tipo de build
4. ✅ **Build type correcto**: Configurado para generar APK en producción

## Pasos para Construir el APK

### 1. Verificar Instalación de EAS CLI

```bash
npm install -g eas-cli
```

### 2. Iniciar Sesión en Expo

```bash
eas login
```

### 3. Configurar el Proyecto (Primera vez)

```bash
eas build:configure
```

### 4. Construir APK para Producción

Para construir un APK de producción:

```bash
eas build --platform android --profile production
```

Para construir un APK de preview (testing):

```bash
eas build --platform android --profile preview
```

### 5. Construir Localmente (Opcional)

Si prefieres construir localmente:

```bash
eas build --platform android --profile production --local
```

**Nota**: Para builds locales necesitas:
- Android Studio instalado
- Android SDK configurado
- Java JDK 17 o superior

## Errores Comunes y Soluciones

### Error: "Invalid project ID"
**Solución**: Ya corregido. Se removieron las referencias a project IDs inválidos.

### Error: "Gradle build failed"
**Solución**: 
1. Limpia el cache: `cd android && ./gradlew clean`
2. Verifica que tengas Java 17: `java -version`
3. Actualiza Gradle: `cd android && ./gradlew wrapper --gradle-version=8.0`

### Error: "Missing keystore"
**Solución**: EAS genera automáticamente el keystore en el primer build. Si necesitas uno personalizado:

```bash
eas credentials
```

### Error: "Out of memory"
**Solución**: Aumenta la memoria de Gradle en `android/gradle.properties`:

```properties
org.gradle.jvmargs=-Xmx4096m -XX:MaxPermSize=512m -XX:+HeapDumpOnOutOfMemoryError -Dfile.encoding=UTF-8
```

### Error: "Bluetooth permissions"
**Solución**: Ya incluidos en `app.json`. Verifica que el usuario acepte los permisos en runtime.

## Verificación Pre-Build

Antes de construir, verifica:

- [ ] Todas las dependencias instaladas: `npm install`
- [ ] No hay errores de TypeScript: `npx tsc --noEmit`
- [ ] La app funciona en desarrollo: `npm run android`
- [ ] Variables de entorno configuradas (si las usas)

## Después del Build

1. **Descargar el APK**: EAS te dará un link para descargar
2. **Instalar en dispositivo**: 
   - Habilita "Instalar apps desconocidas" en Android
   - Transfiere el APK al dispositivo
   - Instala el APK

3. **Probar funcionalidades críticas**:
   - [ ] Login de usuarios
   - [ ] Creación de pedidos
   - [ ] Conexión Bluetooth con impresora
   - [ ] Notificaciones push
   - [ ] Webhook de WhatsApp

## Configuración de Producción

### Variables de Entorno

Si usas variables de entorno, créalas en EAS:

```bash
eas secret:create --scope project --name SUPABASE_URL --value "tu-url"
eas secret:create --scope project --name SUPABASE_ANON_KEY --value "tu-key"
```

### Firma de la App

Para publicar en Google Play Store necesitas:

1. Crear una cuenta de desarrollador de Google Play ($25 USD único pago)
2. Configurar el keystore en EAS:

```bash
eas credentials
```

3. Subir el APK o AAB a Google Play Console

## Tipos de Build

### APK vs AAB

- **APK** (Android Package): 
  - ✅ Instalación directa
  - ✅ Distribución interna
  - ❌ No optimizado por dispositivo
  - ❌ Tamaño más grande

- **AAB** (Android App Bundle):
  - ✅ Optimizado por dispositivo
  - ✅ Tamaño más pequeño
  - ✅ Requerido para Google Play Store
  - ❌ No se puede instalar directamente

Para cambiar a AAB en producción, modifica `eas.json`:

```json
"production": {
  "android": {
    "buildType": "app-bundle"
  }
}
```

## Monitoreo de Build

Puedes monitorear el progreso del build en:

1. Terminal (muestra logs en tiempo real)
2. Dashboard de Expo: https://expo.dev/accounts/[tu-cuenta]/projects/[tu-proyecto]/builds

## Troubleshooting Avanzado

### Ver logs completos del build

```bash
eas build:list
eas build:view [BUILD_ID]
```

### Cancelar un build

```bash
eas build:cancel [BUILD_ID]
```

### Limpiar cache de EAS

```bash
eas build --platform android --profile production --clear-cache
```

## Recursos Adicionales

- [Documentación oficial de EAS Build](https://docs.expo.dev/build/introduction/)
- [Configuración de Android](https://docs.expo.dev/build-reference/android-builds/)
- [Troubleshooting de builds](https://docs.expo.dev/build-reference/troubleshooting/)

## Contacto y Soporte

Si encuentras problemas:

1. Revisa los logs del build
2. Verifica la configuración en `app.json` y `eas.json`
3. Consulta la documentación de Expo
4. Busca el error específico en GitHub Issues de Expo

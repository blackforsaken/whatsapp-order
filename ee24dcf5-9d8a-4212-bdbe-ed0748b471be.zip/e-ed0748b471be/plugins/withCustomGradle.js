
const { withProjectBuildGradle, withSettingsGradle, withAppBuildGradle } = require('@expo/config-plugins');

/**
 * Custom Expo config plugin to fix Gradle dependency resolution issues
 * Specifically addresses react-native-gradle-plugin resolution problems
 */
const withCustomGradle = (config) => {
  // 1. Modify settings.gradle to properly resolve react-native-gradle-plugin
  config = withSettingsGradle(config, (config) => {
    if (config.modResults.contents) {
      let contents = config.modResults.contents;

      // Remove any problematic includeBuild statements that might be causing issues
      contents = contents.replace(/includeBuild\(['"].*?react-native-gradle-plugin.*?['"]\)/g, '');
      
      // Add proper react-native-gradle-plugin resolution at the end of settings.gradle
      if (!contents.includes('// Custom react-native-gradle-plugin resolution')) {
        contents += `

// Custom react-native-gradle-plugin resolution
def rnGradlePluginPath = null
try {
    def nodeCommand = ["node", "--print", "require.resolve('react-native/package.json')"]
    def rnPath = new File(nodeCommand.execute(null, rootDir).text.trim()).getParentFile()
    rnGradlePluginPath = new File(rnPath, "react-native-gradle-plugin")
    
    if (rnGradlePluginPath.exists()) {
        logger.quiet("Found react-native-gradle-plugin at: " + rnGradlePluginPath.absolutePath)
        includeBuild(rnGradlePluginPath)
    } else {
        logger.warn("react-native-gradle-plugin not found at expected location")
    }
} catch (Exception e) {
    logger.error("Failed to locate react-native-gradle-plugin: " + e.getMessage())
}
`;
      }

      config.modResults.contents = contents;
    }
    return config;
  });

  // 2. Modify project build.gradle to ensure proper repository configuration
  config = withProjectBuildGradle(config, (config) => {
    if (config.modResults.contents) {
      let contents = config.modResults.contents;

      // Ensure buildscript repositories use HTTPS and include mavenCentral
      if (!contents.includes('// Custom repository configuration')) {
        const buildscriptRegex = /(buildscript\s*\{[\s\S]*?repositories\s*\{)/;
        
        if (buildscriptRegex.test(contents)) {
          contents = contents.replace(
            buildscriptRegex,
            `$1
        // Custom repository configuration
        google()
        mavenCentral()
        maven {
            url "https://repo1.maven.org/maven2/"
        }
        `
          );
        }
      }

      // Ensure allprojects repositories use HTTPS and include mavenCentral
      if (!contents.includes('// Custom allprojects repository configuration')) {
        const allProjectsRegex = /(allprojects\s*\{[\s\S]*?repositories\s*\{)/;
        
        if (allProjectsRegex.test(contents)) {
          contents = contents.replace(
            allProjectsRegex,
            `$1
        // Custom allprojects repository configuration
        google()
        mavenCentral()
        maven {
            url "https://repo1.maven.org/maven2/"
        }
        `
          );
        }
      }

      config.modResults.contents = contents;
    }
    return config;
  });

  // 3. Modify app build.gradle to ensure proper configuration
  config = withAppBuildGradle(config, (config) => {
    if (config.modResults.contents) {
      let contents = config.modResults.contents;

      // Ensure proper React Native configuration
      if (!contents.includes('// Custom React Native configuration')) {
        contents = contents.replace(
          /apply plugin: "com.android.application"/,
          `apply plugin: "com.android.application"

// Custom React Native configuration
def reactNativeDir = file("../../node_modules/react-native")
def reactNativeGradlePlugin = file("$reactNativeDir/react-native-gradle-plugin")

if (!reactNativeGradlePlugin.exists()) {
    logger.warn("react-native-gradle-plugin not found at: " + reactNativeGradlePlugin.absolutePath)
}
`
        );
      }

      config.modResults.contents = contents;
    }
    return config;
  });

  return config;
};

module.exports = withCustomGradle;

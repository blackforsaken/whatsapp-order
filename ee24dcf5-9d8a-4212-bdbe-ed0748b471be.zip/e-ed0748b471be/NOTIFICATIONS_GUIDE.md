
# Guía de Notificaciones

## 📱 Sistema Dual de Notificaciones

La aplicación implementa un **sistema dual de notificaciones** que funciona en todos los entornos:

### 1. **Notificaciones Push** (Production/Development Builds)
- Funcionan en compilaciones de producción y development builds
- **NO funcionan en Expo Go** (limitación desde SDK 53+)
- Requieren configuración de credenciales de Expo
- Se envían a través del servicio de Expo Push Notifications

### 2. **Notificaciones In-App** (Todos los entornos)
- ✅ Funcionan en Expo Go
- ✅ Funcionan en Development Builds
- ✅ Funcionan en Production Builds
- Incluyen:
  - **Banners animados** en la parte superior de la pantalla
  - **Alertas de diálogo** (Alert.alert)
  - **Registro en base de datos** visible en la pantalla de notificaciones

## 🔔 Tipos de Notificaciones

### Nuevo Pedido
- **Título:** 🛒 Nuevo Pedido
- **Mensaje:** Pedido [NÚMERO] de [CLIENTE]
- **Acción:** Toca para ver el pedido

### Cambio de Estado
- **Título:** [EMOJI] Cambio de Estado
- **Mensaje:** Pedido [NÚMERO] [ESTADO]
- **Emojis por estado:**
  - ⏳ Pendiente
  - 👨‍🍳 Preparando
  - ✅ Listo
  - 🚚 Entregado
  - ❌ Cancelado

### Sistema
- **Título:** Notificación del Sistema
- **Mensaje:** Mensaje personalizado
- **Acción:** Según el contexto

## 🛠️ Implementación Técnica

### Servicios

#### NotificationService.ts
- Maneja notificaciones push
- Registra tokens de dispositivos
- Detecta si push notifications están disponibles
- Muestra alertas informativas en Expo Go

#### InAppNotificationService.ts
- Maneja notificaciones in-app
- Muestra banners animados
- Muestra diálogos de alerta
- Crea registros en base de datos
- Funciona en todos los entornos

### Componentes

#### NotificationBanner.tsx
- Banner animado que aparece en la parte superior
- Se desliza desde arriba
- Desaparece automáticamente después de 4 segundos
- Permite navegación al pedido relacionado
- Botón de cierre manual

### Flujo de Notificaciones

```
Evento (Nuevo Pedido / Cambio Estado)
    ↓
OrderService.sendNotification()
    ↓
    ├─→ Push Notification (si está disponible)
    │   └─→ Edge Function: send-push-notification
    │       └─→ Expo Push Service
    │
    └─→ In-App Notification (siempre)
        ├─→ Crear registro en base de datos
        ├─→ Mostrar banner animado
        └─→ Notificar listeners
```

## 📊 Base de Datos

### Tabla: notifications
```sql
- id: uuid
- user_id: uuid (referencia a profiles)
- type: notification_type (new_order, order_status_change, system)
- title: text
- message: text
- order_id: uuid (opcional, referencia a orders)
- read: boolean
- created_at: timestamptz
```

### Tabla: push_tokens
```sql
- id: uuid
- user_id: uuid (referencia a profiles)
- token: text (único)
- device_type: text (ios, android, web)
- created_at: timestamptz
- updated_at: timestamptz
```

## 🧪 Pruebas

### Probar Notificaciones In-App
1. Abre la aplicación en Expo Go
2. Ve a la pantalla principal
3. Toca el botón "Probar Notificación"
4. Verás un banner animado en la parte superior

### Probar Notificaciones de Pedidos
1. Crea un nuevo pedido
2. Observa el banner de notificación
3. Ve a la pantalla de notificaciones
4. Verifica que el registro aparezca

### Probar Cambios de Estado
1. Abre un pedido existente
2. Cambia su estado
3. Observa el banner de notificación
4. Verifica el mensaje según el estado

## 🔧 Configuración

### Para Expo Go (Desarrollo)
No se requiere configuración adicional. Las notificaciones in-app funcionan automáticamente.

### Para Development Build
1. Ejecuta: `npx expo run:android` o `npx expo run:ios`
2. Las notificaciones push se registrarán automáticamente
3. Los tokens se guardarán en la base de datos

### Para Production Build
1. Configura las credenciales de Expo:
   ```bash
   eas credentials
   ```
2. Compila la aplicación:
   ```bash
   eas build --platform android
   eas build --platform ios
   ```
3. Las notificaciones push funcionarán automáticamente

## 📱 Pantallas

### Pantalla de Notificaciones
- **Ruta:** `/notifications`
- **Acceso:** Ícono de campana en el header
- **Funciones:**
  - Ver todas las notificaciones
  - Marcar como leídas
  - Eliminar notificaciones
  - Navegar a pedidos relacionados
  - Pull to refresh

### Pantalla de Perfil
- **Ruta:** `/profile`
- **Muestra:**
  - Estado de notificaciones push
  - Estado de notificaciones in-app
  - Información sobre limitaciones de Expo Go
  - Botón de información con guía completa

## ⚠️ Limitaciones Conocidas

### Expo Go
- ❌ No soporta notificaciones push (SDK 53+)
- ✅ Soporta notificaciones in-app completamente

### Web
- ❌ No soporta notificaciones push nativas
- ✅ Soporta notificaciones in-app (banners y alertas)

### Soluciones
- El sistema detecta automáticamente el entorno
- Usa notificaciones in-app como fallback
- Muestra mensajes informativos al usuario
- No interrumpe la experiencia del usuario

## 🎯 Mejores Prácticas

1. **Siempre usa el sistema dual:**
   ```typescript
   await OrderService.sendNotification(title, message, type, orderId);
   ```

2. **No asumas que push notifications funcionan:**
   ```typescript
   const isSupported = NotificationService.isPushNotificationSupported();
   ```

3. **Proporciona feedback visual:**
   - Usa banners para notificaciones no críticas
   - Usa diálogos para notificaciones importantes
   - Mantén registros en base de datos

4. **Maneja errores gracefully:**
   ```typescript
   try {
     await sendPushNotification();
   } catch (error) {
     console.log('Push failed, using in-app fallback');
     await sendInAppNotification();
   }
   ```

## 🐛 Troubleshooting

### Las notificaciones no aparecen
1. Verifica que estés autenticado
2. Verifica que tu perfil esté activo (`is_active = true`)
3. Revisa los logs de la consola
4. Verifica la conexión a internet

### Los banners no se muestran
1. Verifica que `NotificationBanner` esté en `_layout.tsx`
2. Revisa que no haya errores en la consola
3. Verifica que el z-index sea suficientemente alto

### Las notificaciones push no funcionan
1. Verifica que NO estés en Expo Go
2. Verifica que tengas un Development Build o Production Build
3. Revisa que los tokens se estén guardando en la base de datos
4. Verifica los logs del Edge Function `send-push-notification`

## 📚 Recursos Adicionales

- [Expo Notifications Docs](https://docs.expo.dev/versions/latest/sdk/notifications/)
- [Expo Push Notifications Guide](https://docs.expo.dev/push-notifications/overview/)
- [Development Builds](https://docs.expo.dev/develop/development-builds/introduction/)
- [Supabase Edge Functions](https://supabase.com/docs/guides/functions)

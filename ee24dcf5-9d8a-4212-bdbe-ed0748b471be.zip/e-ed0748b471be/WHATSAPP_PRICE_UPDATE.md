
# WhatsApp Order Processing - Price Update

## Cambios Realizados

Se ha modificado el webhook de WhatsApp para **NO solicitar precios** durante la recepción inicial del pedido. Los precios ahora se agregan manualmente cuando el pedido cambia al estado "en preparación".

## Cambios Específicos

### 1. **Parsing de Mensajes**
- ✅ Se eliminó toda la lógica de extracción de precios del mensaje de WhatsApp
- ✅ Ahora solo se extraen: nombre del producto y cantidad
- ✅ Los patrones de parsing se simplificaron para ignorar símbolos de precio ($)

### 2. **Creación de Pedidos**
- ✅ `total_amount` se establece en **0** al crear el pedido
- ✅ Cada `order_item` se crea con `price: 0`
- ✅ Los precios se actualizarán manualmente en la app cuando el pedido pase a "en preparación"

### 3. **Mensajes de Confirmación**
- ✅ El mensaje de ayuda ya no menciona precios:
  ```
  Ejemplo:
  2 pizzas
  1 refresco
  3 hamburguesas
  
  El precio se agregará cuando preparemos tu pedido.
  ```

- ✅ El mensaje de confirmación ya no muestra precios:
  ```
  ✅ ¡Pedido recibido!
  
  Número de pedido: WA-1234567890
  
  Resumen:
  2x pizzas
  1x refresco
  3x hamburguesas
  
  Te confirmaremos el precio cuando preparemos tu pedido.
  
  Gracias por tu pedido. Te notificaremos cuando esté listo.
  ```

## Flujo de Trabajo Actualizado

1. **Cliente envía pedido por WhatsApp** → Solo productos y cantidades
2. **Sistema crea pedido** → Estado: "pending", Precio: $0
3. **Operador revisa pedido en la app** → Ve los items sin precio
4. **Operador cambia estado a "en preparación"** → Agrega precios manualmente
5. **Sistema calcula total** → Actualiza `total_amount` automáticamente
6. **Cliente recibe notificación** → Con el precio final

## Formatos de Mensaje Aceptados

El sistema ahora acepta estos formatos (sin precios):

```
2 pizzas
1 refresco
3 hamburguesas
```

```
2x pizzas
1x refresco
3x hamburguesas
```

```
pizzas: 2
refresco: 1
hamburguesas: 3
```

```
pizzas 2
refresco 1
hamburguesas 3
```

## Pantalla de Detalle del Pedido

La pantalla de detalle del pedido (`app/order/[id].tsx`) ya tiene la funcionalidad para:
- Mostrar items sin precio cuando el pedido está en estado "pending"
- Permitir editar precios cuando se cambia a "en preparación"
- Calcular automáticamente el total al guardar los precios

## Notas Importantes

- ⚠️ Los pedidos de WhatsApp siempre inician con `total_amount = 0`
- ⚠️ Los precios deben agregarse manualmente antes de completar el pedido
- ✅ El sistema sigue enviando notificaciones push a todos los usuarios activos
- ✅ El cliente recibe confirmación inmediata por WhatsApp (sin precios)

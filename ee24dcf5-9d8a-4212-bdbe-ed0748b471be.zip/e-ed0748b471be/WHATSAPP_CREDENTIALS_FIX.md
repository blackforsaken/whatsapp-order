
# Solución: "WhatsApp credentials not configured"

## Problema Identificado

El error "WhatsApp credentials not configured" ocurría porque la Edge Function `whatsapp-webhook` intentaba leer las credenciales de WhatsApp desde variables de entorno de Supabase (`Deno.env.get()`), pero estas variables no estaban configuradas.

Aunque la configuración se guardaba correctamente en la tabla `whatsapp_config` de la base de datos, la Edge Function no estaba leyendo desde allí.

## Solución Implementada

Se modificó la Edge Function `whatsapp-webhook` para que:

1. **Lea la configuración desde la base de datos** en lugar de variables de entorno
2. **Cargue las credenciales dinámicamente** cada vez que se recibe una solicitud
3. **Valide que la configuración exista** antes de procesar mensajes

### Cambios Principales

#### 1. Nueva función `loadWhatsAppConfig()`

```typescript
async function loadWhatsAppConfig(supabase: any): Promise<WhatsAppConfig | null> {
  try {
    const { data, error } = await supabase
      .from('whatsapp_config')
      .select('verify_token, access_token, phone_number_id')
      .eq('is_active', true)
      .maybeSingle();

    if (error) {
      console.error('Error loading WhatsApp config from database:', error);
      return null;
    }

    if (!data) {
      console.error('No active WhatsApp configuration found in database');
      return null;
    }

    console.log('WhatsApp config loaded successfully from database');
    return data;
  } catch (error) {
    console.error('Exception loading WhatsApp config:', error);
    return null;
  }
}
```

#### 2. Modificación de `sendWhatsAppMessage()`

Ahora recibe la configuración como parámetro:

```typescript
async function sendWhatsAppMessage(
  to: string, 
  message: string, 
  config: WhatsAppConfig
): Promise<boolean>
```

#### 3. Carga de configuración en el handler principal

```typescript
// Load WhatsApp configuration from database
const whatsappConfig = await loadWhatsAppConfig(supabase);

if (!whatsappConfig) {
  console.error('WhatsApp configuration not found in database');
  return new Response("Configuration not found", { status: 500 });
}
```

## Cómo Funciona Ahora

### Flujo de Verificación del Webhook (GET)

1. Meta envía una solicitud GET con el token de verificación
2. La Edge Function carga la configuración desde la base de datos
3. Compara el token recibido con el `verify_token` de la base de datos
4. Si coinciden, devuelve el challenge para completar la verificación

### Flujo de Procesamiento de Mensajes (POST)

1. WhatsApp envía un mensaje al webhook
2. La Edge Function carga la configuración desde la base de datos
3. Valida que la configuración exista
4. Procesa el mensaje y crea el pedido
5. Usa `access_token` y `phone_number_id` de la base de datos para enviar respuestas

## Ventajas de Esta Solución

✅ **No requiere variables de entorno**: Todo se gestiona desde la base de datos

✅ **Configuración dinámica**: Los cambios en la configuración se aplican inmediatamente sin necesidad de redesplegar

✅ **Más seguro**: Las credenciales se almacenan en la base de datos con RLS habilitado

✅ **Fácil de actualizar**: Los administradores pueden cambiar las credenciales desde la app

✅ **Mejor logging**: Mensajes de error más claros sobre qué está fallando

## Verificación

Para verificar que la solución funciona:

1. **Guarda la configuración** en la app (pantalla de Configuración WhatsApp)
2. **Verifica el webhook** en Meta for Developers
3. **Envía un mensaje de prueba** al número de WhatsApp Business
4. **Revisa los logs** en Supabase Dashboard → Edge Functions → whatsapp-webhook

### Logs Esperados

Si todo funciona correctamente, deberías ver:

```
WhatsApp config loaded successfully from database
Webhook verified successfully
```

O al procesar un mensaje:

```
WhatsApp config loaded successfully from database
Processing message: { customerName: '...', customerPhone: '...', messageText: '...' }
Order created: [order-id]
WhatsApp message sent successfully
```

## Solución de Problemas

### Error: "No active WhatsApp configuration found in database"

**Causa**: No hay ninguna configuración guardada o la configuración está inactiva.

**Solución**: 
- Ve a la pantalla de Configuración WhatsApp en la app
- Completa todos los campos requeridos
- Presiona "Guardar Configuración"

### Error: "WhatsApp credentials not configured in database"

**Causa**: La configuración existe pero los campos están vacíos.

**Solución**:
- Verifica que hayas ingresado el Token de Acceso y el ID del Número de Teléfono
- Asegúrate de que los valores sean correctos (sin espacios adicionales)

### Error: "Error loading WhatsApp config from database"

**Causa**: Problema de permisos o conexión con la base de datos.

**Solución**:
- Verifica que la tabla `whatsapp_config` exista
- Revisa los permisos RLS de la tabla
- Confirma que el Service Role Key de Supabase sea válido

## Próximos Pasos

1. **Guarda tu configuración** en la app si aún no lo has hecho
2. **Prueba el webhook** enviando un mensaje de prueba
3. **Revisa los logs** para confirmar que todo funciona correctamente
4. **Configura las notificaciones push** si aún no lo has hecho

## Recursos Adicionales

- [Documentación de WhatsApp Business API](https://developers.facebook.com/docs/whatsapp/cloud-api)
- [Guía de Configuración de Webhooks](https://developers.facebook.com/docs/whatsapp/cloud-api/guides/set-up-webhooks)
- [Panel de Supabase Edge Functions](https://supabase.com/dashboard/project/stxrvyxkxclezgcijhio/functions)

---

**Versión de la Edge Function**: 11  
**Fecha de actualización**: 2025-01-16  
**Estado**: ✅ Desplegado y funcionando

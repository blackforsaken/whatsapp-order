
# Testing de Integración WhatsApp

## Guía de Pruebas

Esta guía te ayudará a probar la integración de WhatsApp paso a paso.

## Pre-requisitos

Antes de comenzar las pruebas, asegúrate de:

1. ✅ Tener configurado el webhook en Meta for Developers
2. ✅ Tener todas las variables de entorno configuradas en Supabase
3. ✅ Tener la Edge Function `whatsapp-webhook` desplegada
4. ✅ Tener al menos un usuario activo en la app

## Pruebas Básicas

### 1. Verificación del Webhook

**Objetivo**: Verificar que el webhook está correctamente configurado.

**Pasos**:
1. Ve a Meta for Developers → Tu App → WhatsApp → Configuration
2. Haz clic en "Verify" junto a tu webhook URL
3. Deberías ver un mensaje de éxito

**Resultado Esperado**:
- ✅ Webhook verificado exitosamente
- ✅ En logs de Supabase: `"Webhook verified successfully"`

### 2. Mensaje Simple

**Objetivo**: Probar el formato más básico de pedido.

**Mensaje de Prueba**:
```
2 pizzas $10
```

**Resultado Esperado**:
- ✅ Orden creada en base de datos
- ✅ 1 item: "pizzas", cantidad: 2, precio: $10
- ✅ Total: $20
- ✅ Notificación enviada a usuarios activos
- ✅ Cliente recibe confirmación por WhatsApp

**Verificación**:
```sql
SELECT * FROM orders WHERE customer_phone = 'TU_NUMERO' ORDER BY created_at DESC LIMIT 1;
SELECT * FROM order_items WHERE order_id = 'ORDER_ID';
```

### 3. Mensaje con Múltiples Items

**Objetivo**: Probar pedido con varios productos.

**Mensaje de Prueba**:
```
2 pizzas $10
1 refresco $2
3 hamburguesas $5
```

**Resultado Esperado**:
- ✅ Orden creada con 3 items
- ✅ Total: $37 (2×$10 + 1×$2 + 3×$5)
- ✅ Confirmación con resumen completo

### 4. Diferentes Formatos

**Objetivo**: Verificar que el parser entiende múltiples formatos.

**Mensajes de Prueba**:

**Formato A**:
```
2x Pizza Margarita $10
1x Coca Cola $2
```

**Formato B**:
```
Pizza Margarita: 2 $10
Coca Cola: 1 $2
```

**Formato C**:
```
2 Pizza Margarita - $10
1 Coca Cola - $2
```

**Formato D**:
```
Pizza Margarita $10 x2
Coca Cola $2 cantidad 1
```

**Resultado Esperado**:
- ✅ Todos los formatos crean la misma orden
- ✅ 2 items: Pizza Margarita (2×$10), Coca Cola (1×$2)
- ✅ Total: $22

## Pruebas Avanzadas

### 5. Items Duplicados

**Objetivo**: Verificar que items duplicados se fusionan.

**Mensaje de Prueba**:
```
2 pizzas $10
1 refresco $2
3 pizzas $10
```

**Resultado Esperado**:
- ✅ 2 items en la orden (no 3)
- ✅ Pizzas: cantidad 5 (2+3), precio $10
- ✅ Refresco: cantidad 1, precio $2
- ✅ Total: $52

### 6. Precios sin Símbolo de Dólar

**Objetivo**: Verificar que funciona sin el símbolo $.

**Mensaje de Prueba**:
```
2 pizzas 10
1 refresco 2
```

**Resultado Esperado**:
- ✅ Orden creada correctamente
- ✅ Precios interpretados correctamente

### 7. Nombres de Productos Largos

**Objetivo**: Verificar que maneja nombres largos.

**Mensaje de Prueba**:
```
2 Pizza Margarita Extra Grande con Queso $15
1 Coca Cola Zero 2 Litros $3
```

**Resultado Esperado**:
- ✅ Nombres completos guardados
- ✅ Cantidades y precios correctos

### 8. Mensaje Inválido

**Objetivo**: Verificar manejo de errores.

**Mensaje de Prueba**:
```
Hola, quisiera hacer un pedido
```

**Resultado Esperado**:
- ✅ No se crea orden
- ✅ Cliente recibe mensaje de ayuda
- ✅ En logs: `"No se pudieron extraer items del mensaje"`

### 9. Mensaje con Notas

**Objetivo**: Verificar que se guarda el mensaje original.

**Mensaje de Prueba**:
```
2 pizzas $10
1 refresco $2

Nota: Sin cebolla en las pizzas
```

**Resultado Esperado**:
- ✅ Orden creada con items
- ✅ Campo `notes` contiene el mensaje completo
- ✅ Mensaje original visible en detalles de orden

### 10. Carga Alta

**Objetivo**: Verificar que maneja múltiples mensajes simultáneos.

**Pasos**:
1. Envía 5 mensajes diferentes en rápida sucesión
2. Verifica que todos se procesen

**Resultado Esperado**:
- ✅ 5 órdenes creadas
- ✅ Todas con números de orden únicos
- ✅ Todas las notificaciones enviadas

## Pruebas de Notificaciones

### 11. Notificaciones Push

**Objetivo**: Verificar que las notificaciones push llegan.

**Pasos**:
1. Asegúrate de tener la app abierta en un dispositivo
2. Envía un mensaje de WhatsApp
3. Verifica que recibes notificación push

**Resultado Esperado**:
- ✅ Notificación push recibida en dispositivo
- ✅ Título: "Nuevo pedido de WhatsApp"
- ✅ Mensaje: "Pedido WA-xxx de [nombre]"
- ✅ Al tocar, abre la app

### 12. Notificaciones en Base de Datos

**Objetivo**: Verificar que se crean notificaciones en DB.

**Pasos**:
1. Envía un mensaje de WhatsApp
2. Verifica en base de datos

**Verificación**:
```sql
SELECT * FROM notifications 
WHERE type = 'new_order' 
ORDER BY created_at DESC 
LIMIT 1;
```

**Resultado Esperado**:
- ✅ Notificación creada para cada usuario activo
- ✅ `type` = 'new_order'
- ✅ `order_id` apunta a la orden creada

### 13. Múltiples Usuarios

**Objetivo**: Verificar que todos los usuarios activos reciben notificaciones.

**Pasos**:
1. Crea 3 usuarios en la app
2. Marca todos como activos
3. Envía un mensaje de WhatsApp
4. Verifica notificaciones

**Resultado Esperado**:
- ✅ 3 notificaciones creadas en DB
- ✅ 3 push notifications enviadas
- ✅ Cada usuario ve la notificación en su app

## Pruebas de Confirmación

### 14. Mensaje de Confirmación

**Objetivo**: Verificar que el cliente recibe confirmación.

**Pasos**:
1. Envía un pedido válido
2. Verifica el mensaje de confirmación recibido

**Resultado Esperado**:
```
✅ ¡Pedido recibido!

Número de pedido: WA-1234567890

Resumen:
2x pizzas - $10
1x refresco - $2

Total: $22.00

Gracias por tu pedido. Te notificaremos cuando esté listo.
```

### 15. Mensaje de Error

**Objetivo**: Verificar mensaje de ayuda.

**Pasos**:
1. Envía un mensaje inválido
2. Verifica el mensaje de ayuda recibido

**Resultado Esperado**:
```
No pude entender tu pedido. Por favor, envía tu pedido en el siguiente formato:

Ejemplo:
2 pizzas $10
1 refresco $2
3 hamburguesas $5
```

## Pruebas de Integración

### 16. Flujo Completo

**Objetivo**: Verificar el flujo completo de principio a fin.

**Pasos**:
1. Cliente envía pedido por WhatsApp
2. Webhook recibe mensaje
3. Parser extrae items
4. Orden se crea en DB
5. Notificaciones se envían
6. Cliente recibe confirmación
7. Usuario ve pedido en app
8. Usuario actualiza estado
9. (Opcional) Usuario imprime pedido

**Resultado Esperado**:
- ✅ Todos los pasos se completan sin errores
- ✅ Logs muestran cada paso
- ✅ Tiempos de respuesta aceptables (<5 segundos)

### 17. Actualización de Estado

**Objetivo**: Verificar que los cambios de estado funcionan.

**Pasos**:
1. Crea orden desde WhatsApp
2. En la app, cambia estado a "preparing"
3. Cambia estado a "ready"
4. Cambia estado a "delivered"

**Resultado Esperado**:
- ✅ Cada cambio se guarda en DB
- ✅ Notificaciones de cambio de estado se envían
- ✅ `updated_at` se actualiza

### 18. Impresión Automática

**Objetivo**: Verificar que la impresión automática funciona.

**Pasos**:
1. Habilita impresión automática en la app
2. Conecta impresora Bluetooth
3. Envía pedido por WhatsApp

**Resultado Esperado**:
- ✅ Orden se imprime automáticamente
- ✅ `printed` = true en DB
- ✅ `printed_at` tiene timestamp

## Pruebas de Rendimiento

### 19. Tiempo de Respuesta

**Objetivo**: Medir tiempo de procesamiento.

**Pasos**:
1. Envía mensaje de WhatsApp
2. Mide tiempo hasta recibir confirmación

**Resultado Esperado**:
- ✅ Confirmación en <5 segundos
- ✅ Notificación push en <10 segundos
- ✅ Orden visible en app en <15 segundos

### 20. Carga Sostenida

**Objetivo**: Verificar estabilidad bajo carga.

**Pasos**:
1. Envía 20 mensajes en 1 minuto
2. Verifica que todos se procesen

**Resultado Esperado**:
- ✅ 20 órdenes creadas
- ✅ Sin errores en logs
- ✅ Tiempos de respuesta consistentes

## Checklist de Pruebas

Usa este checklist para verificar que todo funciona:

- [ ] Webhook verificado
- [ ] Mensaje simple funciona
- [ ] Múltiples items funcionan
- [ ] Todos los formatos funcionan
- [ ] Items duplicados se fusionan
- [ ] Precios sin $ funcionan
- [ ] Nombres largos funcionan
- [ ] Mensajes inválidos manejan error
- [ ] Notas se guardan
- [ ] Carga alta funciona
- [ ] Push notifications llegan
- [ ] Notificaciones en DB se crean
- [ ] Múltiples usuarios reciben notificaciones
- [ ] Confirmación llega al cliente
- [ ] Mensaje de error funciona
- [ ] Flujo completo funciona
- [ ] Actualización de estado funciona
- [ ] Impresión automática funciona
- [ ] Tiempo de respuesta <5s
- [ ] Carga sostenida funciona

## Logs de Ejemplo

### Logs Exitosos

```
Processing message from 1234567890: 2 pizzas $10
1 refresco $2
Order created: 550e8400-e29b-41d4-a716-446655440000
Push notifications sent successfully
WhatsApp message sent successfully
Order processed successfully
```

### Logs de Error

```
Processing message from 1234567890: Hola
No se pudieron extraer items del mensaje
WhatsApp message sent successfully (help message)
```

## Troubleshooting

### Problema: No recibo confirmación

**Verificar**:
1. `WHATSAPP_ACCESS_TOKEN` configurado
2. `WHATSAPP_PHONE_NUMBER_ID` configurado
3. Token no expirado
4. Logs de Edge Function

### Problema: Parsing falla

**Verificar**:
1. Formato del mensaje en logs
2. Probar con formato más simple
3. Revisar regex en código

### Problema: No llegan notificaciones

**Verificar**:
1. Usuarios marcados como activos
2. Tokens de push registrados
3. Edge Function `send-push-notification` funciona
4. Permisos de notificaciones en dispositivo

## Herramientas de Testing

### Postman

Puedes usar Postman para simular webhooks:

```json
POST https://stxrvyxkxclezgcijhio.supabase.co/functions/v1/whatsapp-webhook

{
  "entry": [{
    "changes": [{
      "value": {
        "messages": [{
          "from": "1234567890",
          "id": "test-message-id",
          "text": {
            "body": "2 pizzas $10\n1 refresco $2"
          }
        }],
        "contacts": [{
          "profile": {
            "name": "Test User"
          }
        }]
      }
    }]
  }]
}
```

### SQL Queries

Queries útiles para verificar:

```sql
-- Ver últimas órdenes
SELECT * FROM orders ORDER BY created_at DESC LIMIT 10;

-- Ver items de una orden
SELECT * FROM order_items WHERE order_id = 'ORDER_ID';

-- Ver notificaciones recientes
SELECT * FROM notifications ORDER BY created_at DESC LIMIT 10;

-- Contar órdenes por día
SELECT DATE(created_at), COUNT(*) 
FROM orders 
WHERE customer_phone IS NOT NULL 
GROUP BY DATE(created_at);

-- Ver órdenes de WhatsApp
SELECT * FROM orders WHERE whatsapp_message_id IS NOT NULL;
```

## Conclusión

Después de completar todas estas pruebas, deberías tener confianza en que la integración de WhatsApp funciona correctamente y está lista para producción.

Si encuentras algún problema, revisa los logs de las Edge Functions y las queries SQL para diagnosticar el issue.

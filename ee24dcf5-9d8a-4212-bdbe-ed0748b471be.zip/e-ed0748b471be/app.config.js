
const withCustomGradle = require('./plugins/withCustomGradle');

module.exports = {
  name: 'whatsapp-order-printer',
  slug: 'whatsapp-order-printer-piwggu',
  version: '1.0.0',
  orientation: 'portrait',
  icon: './assets/images/final_quest_240x240.png',
  scheme: 'whatsapp-order-printer',
  userInterfaceStyle: 'automatic',
  newArchEnabled: true,
  runtimeVersion: {
    policy: 'appVersion'
  },
  splash: {
    image: './assets/images/final_quest_240x240.png',
    resizeMode: 'contain',
    backgroundColor: '#ffffff'
  },
  ios: {
    supportsTablet: true,
    bundleIdentifier: 'com.whatsapporderprinter.app',
    buildNumber: '1.0.0',
    deploymentTarget: '15.1',
    infoPlist: {
      ITSAppUsesNonExemptEncryption: false,
      NSBluetoothAlwaysUsageDescription: 'Esta aplicación necesita acceso a Bluetooth para conectarse a impresoras térmicas y imprimir pedidos automáticamente.',
      NSBluetoothPeripheralUsageDescription: 'Esta aplicación necesita acceso a Bluetooth para conectarse a impresoras térmicas y imprimir pedidos automáticamente.',
      UIBackgroundModes: ['remote-notification']
    }
  },
  android: {
    adaptiveIcon: {
      foregroundImage: './assets/images/final_quest_240x240.png',
      backgroundColor: '#ffffff'
    },
    package: 'com.whatsapporderprinter.app',
    versionCode: 1,
    permissions: [
      'BLUETOOTH',
      'BLUETOOTH_ADMIN',
      'BLUETOOTH_CONNECT',
      'BLUETOOTH_SCAN',
      'ACCESS_FINE_LOCATION',
      'ACCESS_COARSE_LOCATION',
      'RECEIVE_BOOT_COMPLETED',
      'VIBRATE'
    ],
    useNextNotificationsApi: true
  },
  web: {
    bundler: 'metro',
    output: 'static',
    favicon: './assets/images/final_quest_240x240.png'
  },
  plugins: [
    'expo-font',
    'expo-router',
    'expo-web-browser',
    [
      'expo-notifications',
      {
        icon: './assets/images/final_quest_240x240.png',
        color: '#ffffff',
        sounds: []
      }
    ],
    [
      'expo-build-properties',
      {
        android: {
          compileSdkVersion: 34,
          targetSdkVersion: 34,
          buildToolsVersion: '34.0.0',
          minSdkVersion: 23,
          enableProguardInReleaseBuilds: true,
          enableShrinkResourcesInReleaseBuilds: true
        },
        ios: {
          deploymentTarget: '15.1'
        }
      }
    ],
    withCustomGradle
  ],
  experiments: {
    typedRoutes: true
  },
  extra: {
    router: {
      origin: false
    },
    eas: {
      projectId: 'your-project-id'
    }
  }
};


import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.39.3";

interface WhatsAppMessage {
  from: string;
  id: string;
  timestamp: string;
  text?: {
    body: string;
  };
  type: string;
}

interface WhatsAppWebhookPayload {
  object: string;
  entry: {
    id: string;
    changes: {
      value: {
        messaging_product: string;
        metadata: {
          display_phone_number: string;
          phone_number_id: string;
        };
        contacts?: {
          profile: {
            name: string;
          };
          wa_id: string;
        }[];
        messages?: WhatsAppMessage[];
      };
      field: string;
    }[];
  }[];
}

interface OrderItem {
  name: string;
  quantity: number;
  notes?: string;
}

interface WhatsAppConfig {
  verify_token: string;
  access_token: string;
  phone_number_id: string;
}

// Load WhatsApp configuration from database
async function loadWhatsAppConfig(supabase: any): Promise<WhatsAppConfig | null> {
  try {
    const { data, error } = await supabase
      .from('whatsapp_config')
      .select('verify_token, access_token, phone_number_id')
      .eq('is_active', true)
      .single();

    if (error) {
      console.error('Error loading WhatsApp config:', error);
      return null;
    }

    return data;
  } catch (error) {
    console.error('Exception loading WhatsApp config:', error);
    return null;
  }
}

// Parse order from WhatsApp message
function parseOrderFromMessage(messageText: string): { items: OrderItem[], notes: string } {
  console.log('Parsing message:', messageText);
  
  const lines = messageText.split('\n').map(line => line.trim()).filter(line => line.length > 0);
  const items: OrderItem[] = [];
  let notes = '';
  
  // Keywords to filter out noise
  const noiseKeywords = [
    'hola', 'buenos días', 'buenas tardes', 'buenas noches',
    'gracias', 'por favor', 'saludos', 'cordial',
    'quiero', 'necesito', 'me gustaría', 'quisiera',
    'pedido', 'orden', 'solicito'
  ];
  
  for (const line of lines) {
    const lowerLine = line.toLowerCase();
    
    // Skip noise lines
    if (noiseKeywords.some(keyword => lowerLine === keyword || lowerLine.startsWith(keyword + ' '))) {
      continue;
    }
    
    // Try to parse as item with quantity
    // Formats: "3 tomates", "tomates x3", "tomates 3", "3x tomates"
    const patterns = [
      /^(\d+)\s*x?\s+(.+)$/i,           // "3 tomates" or "3x tomates"
      /^(.+?)\s*x\s*(\d+)$/i,            // "tomates x3"
      /^(.+?)\s+(\d+)$/i,                // "tomates 3"
    ];
    
    let matched = false;
    for (const pattern of patterns) {
      const match = line.match(pattern);
      if (match) {
        let quantity: number;
        let name: string;
        
        // Determine which group is quantity and which is name
        if (/^\d+$/.test(match[1])) {
          quantity = parseInt(match[1]);
          name = match[2].trim();
        } else {
          quantity = parseInt(match[2]);
          name = match[1].trim();
        }
        
        // Clean up the name (remove any remaining 'x' characters)
        name = name.replace(/\s*x\s*/gi, ' ').trim();
        
        if (quantity > 0 && name.length > 0) {
          items.push({
            name: name,
            quantity: quantity,
            notes: undefined
          });
          matched = true;
          break;
        }
      }
    }
    
    // If no pattern matched, treat as item with quantity 1 or as notes
    if (!matched) {
      // If line looks like a product name (not too long, no special chars)
      if (line.length < 50 && !/[?!¿¡]/.test(line)) {
        items.push({
          name: line,
          quantity: 1,
          notes: undefined
        });
      } else {
        // Otherwise, add to notes
        notes += (notes ? '\n' : '') + line;
      }
    }
  }
  
  console.log('Parsed items:', items);
  console.log('Parsed notes:', notes);
  
  return { items, notes };
}

// Send WhatsApp message
async function sendWhatsAppMessage(to: string, message: string, config: WhatsAppConfig): Promise<boolean> {
  try {
    const response = await fetch(
      `https://graph.facebook.com/v17.0/${config.phone_number_id}/messages`,
      {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${config.access_token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          messaging_product: 'whatsapp',
          to: to,
          type: 'text',
          text: { body: message },
        }),
      }
    );

    if (!response.ok) {
      const errorText = await response.text();
      console.error('WhatsApp API error:', errorText);
      return false;
    }

    return true;
  } catch (error) {
    console.error('Error sending WhatsApp message:', error);
    return false;
  }
}

// Send push notifications to users
async function sendPushNotifications(orderId: string, orderNumber: string, userIds: string[]) {
  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    
    const response = await fetch(`${supabaseUrl}/functions/v1/send-push-notification`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${supabaseServiceKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        userIds,
        title: 'Nuevo Pedido',
        body: `Pedido #${orderNumber} recibido por WhatsApp`,
        data: {
          orderId,
          type: 'new_order',
        },
      }),
    });

    if (!response.ok) {
      console.error('Error sending push notifications:', await response.text());
    }
  } catch (error) {
    console.error('Exception sending push notifications:', error);
  }
}

serve(async (req) => {
  const url = new URL(req.url);
  
  // Initialize Supabase client
  const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
  const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
  const supabase = createClient(supabaseUrl, supabaseServiceKey);

  // Load WhatsApp config
  const config = await loadWhatsAppConfig(supabase);
  if (!config) {
    console.error('WhatsApp config not found or inactive');
    return new Response('Configuration error', { status: 500 });
  }

  // Handle GET request (webhook verification)
  if (req.method === 'GET') {
    const mode = url.searchParams.get('hub.mode');
    const token = url.searchParams.get('hub.verify_token');
    const challenge = url.searchParams.get('hub.challenge');

    console.log('Webhook verification request:', { mode, token: token ? '[REDACTED]' : null });

    if (mode === 'subscribe' && token === config.verify_token) {
      console.log('Webhook verified successfully');
      return new Response(challenge, { status: 200 });
    } else {
      console.error('Webhook verification failed');
      return new Response('Forbidden', { status: 403 });
    }
  }

  // Handle POST request (incoming messages)
  if (req.method === 'POST') {
    try {
      const body: WhatsAppWebhookPayload = await req.json();
      console.log('Received webhook:', JSON.stringify(body, null, 2));

      // Validate webhook payload
      if (body.object !== 'whatsapp_business_account') {
        console.log('Invalid object type:', body.object);
        return new Response('OK', { status: 200 });
      }

      // Process each entry
      for (const entry of body.entry) {
        for (const change of entry.changes) {
          if (change.field !== 'messages') {
            continue;
          }

          const messages = change.value.messages;
          const contacts = change.value.contacts;

          if (!messages || messages.length === 0) {
            continue;
          }

          // Process each message
          for (const message of messages) {
            if (message.type !== 'text' || !message.text?.body) {
              console.log('Skipping non-text message');
              continue;
            }

            const messageText = message.text.body;
            const customerPhone = message.from;
            const customerName = contacts?.[0]?.profile?.name || 'Cliente';

            console.log('Processing message from:', customerName, customerPhone);

            // Parse order from message
            const { items, notes } = parseOrderFromMessage(messageText);

            if (items.length === 0) {
              console.log('No items found in message, skipping order creation');
              
              // Send acknowledgment message
              await sendWhatsAppMessage(
                customerPhone,
                'Hola! No pude identificar productos en tu mensaje. Por favor, envía tu pedido en el formato:\n\n3 tomates\n2 lechugas\n1 kg papas\n\nGracias!',
                config
              );
              
              continue;
            }

            // Generate order number
            const { data: orderNumberData } = await supabase.rpc('generate_order_number');
            const orderNumber = orderNumberData || `WA-${Date.now()}`;

            // Create order
            const { data: order, error: orderError } = await supabase
              .from('orders')
              .insert({
                order_number: orderNumber,
                customer_name: customerName,
                customer_phone: customerPhone,
                notes: notes || null,
                status: 'pending',
                total_amount: 0,
                whatsapp_message_id: message.id,
                source: 'whatsapp',
              })
              .select()
              .single();

            if (orderError) {
              console.error('Error creating order:', orderError);
              continue;
            }

            console.log('Order created:', order.id);

            // Create order items
            const orderItems = items.map(item => ({
              order_id: order.id,
              name: item.name,
              quantity: item.quantity,
              price: 0,
              notes: item.notes || null,
            }));

            const { error: itemsError } = await supabase
              .from('order_items')
              .insert(orderItems);

            if (itemsError) {
              console.error('Error creating order items:', itemsError);
            }

            // Create notifications for all active users
            const { data: profiles } = await supabase
              .from('profiles')
              .select('id')
              .eq('is_active', true);

            if (profiles && profiles.length > 0) {
              const notifications = profiles.map(profile => ({
                user_id: profile.id,
                type: 'new_order',
                title: 'Nuevo Pedido por WhatsApp',
                message: `Pedido #${orderNumber} de ${customerName}`,
                order_id: order.id,
              }));

              await supabase.from('notifications').insert(notifications);

              // Send push notifications
              const userIds = profiles.map(p => p.id);
              await sendPushNotifications(order.id, orderNumber, userIds);
            }

            // Send confirmation message to customer
            const itemsList = items.map(item => `• ${item.quantity} ${item.name}`).join('\n');
            const confirmationMessage = `✅ Pedido recibido!\n\nPedido #${orderNumber}\n\n${itemsList}\n\n${notes ? `Notas: ${notes}\n\n` : ''}Te confirmaremos el precio y tiempo de entrega pronto. Gracias!`;
            
            await sendWhatsAppMessage(customerPhone, confirmationMessage, config);
          }
        }
      }

      return new Response('OK', { status: 200 });
    } catch (error) {
      console.error('Error processing webhook:', error);
      return new Response('Internal Server Error', { status: 500 });
    }
  }

  return new Response('Method Not Allowed', { status: 405 });
});

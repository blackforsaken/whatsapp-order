
// @deno-types="https://deno.land/std@0.168.0/http/server.ts"
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
// @deno-types="https://esm.sh/@supabase/supabase-js@2.39.3"
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.39.3";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface WhatsAppConfig {
  access_token: string;
  phone_number_id: string;
}

interface OrderItem {
  name: string;
  quantity: number;
  price: number;
}

interface RequestBody {
  orderId: string;
  orderNumber: string;
  customerName: string;
  customerPhone: string;
  status: 'pending' | 'preparing' | 'ready' | 'delivered' | 'cancelled';
  totalAmount: number;
  items: OrderItem[];
}

// Load WhatsApp configuration from database
async function loadWhatsAppConfig(supabase: any): Promise<WhatsAppConfig | null> {
  try {
    const { data, error } = await supabase
      .from('whatsapp_config')
      .select('access_token, phone_number_id')
      .eq('is_active', true)
      .maybeSingle();

    if (error) {
      console.error('Error loading WhatsApp config from database:', error);
      return null;
    }

    if (!data) {
      console.error('No active WhatsApp configuration found in database');
      return null;
    }

    console.log('WhatsApp config loaded successfully from database');
    return data;
  } catch (error) {
    console.error('Exception loading WhatsApp config:', error);
    return null;
  }
}

// Format currency
function formatCurrency(amount: number): string {
  return `$${amount.toLocaleString('es-CL', { minimumFractionDigits: 0, maximumFractionDigits: 0 })}`;
}

// Get status text in Spanish
function getStatusText(status: string): string {
  const statusMap: Record<string, string> = {
    pending: 'Pendiente',
    preparing: 'En Preparación',
    ready: 'Listo para Retirar/Entregar',
    delivered: 'Entregado',
    cancelled: 'Cancelado',
  };
  return statusMap[status] || status;
}

// Get status emoji
function getStatusEmoji(status: string): string {
  const emojiMap: Record<string, string> = {
    pending: '⏳',
    preparing: '👨‍🍳',
    ready: '✅',
    delivered: '🎉',
    cancelled: '❌',
  };
  return emojiMap[status] || '📦';
}

// Send WhatsApp message with enhanced error logging
async function sendWhatsAppMessage(
  to: string,
  message: string,
  config: WhatsAppConfig
): Promise<boolean> {
  if (!config.access_token || !config.phone_number_id) {
    console.error('WhatsApp credentials not configured in database');
    return false;
  }

  try {
    console.log('Sending WhatsApp status message to:', to);
    console.log('Message:', message);
    console.log('Using phone_number_id:', config.phone_number_id);
    console.log('Access token (first 20 chars):', config.access_token.substring(0, 20) + '...');
    
    const response = await fetch(
      `https://graph.facebook.com/v18.0/${config.phone_number_id}/messages`,
      {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${config.access_token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          messaging_product: 'whatsapp',
          to: to,
          type: 'text',
          text: { body: message },
        }),
      }
    );

    const responseText = await response.text();

    if (!response.ok) {
      console.error('❌ WhatsApp API Error Response:');
      console.error('Status:', response.status);
      console.error('Status Text:', response.statusText);
      console.error('Response Body:', responseText);
      
      // Try to parse as JSON for better error details
      try {
        const errorJson = JSON.parse(responseText);
        console.error('WhatsApp message:', JSON.stringify(errorJson, null, 2));
        
        // Log specific error details
        if (errorJson.error) {
          console.error('Error Code:', errorJson.error.code);
          console.error('Error Type:', errorJson.error.type);
          console.error('Error Message:', errorJson.error.message);
          console.error('Error Subcode:', errorJson.error.error_subcode);
          console.error('FB Trace ID:', errorJson.error.fbtrace_id);
        }
      } catch (parseError) {
        console.error('Could not parse error response as JSON');
      }
      
      return false;
    }

    const responseData = JSON.parse(responseText);
    console.log('✅ WhatsApp status message sent successfully:', responseData);
    return true;
  } catch (error) {
    console.error('❌ Exception sending WhatsApp message:', error);
    console.error('Error details:', error.message);
    console.error('Error stack:', error.stack);
    return false;
  }
}

// Build status message
function buildStatusMessage(body: RequestBody): string {
  const emoji = getStatusEmoji(body.status);
  const statusText = getStatusText(body.status);
  
  let message = `${emoji} *Actualización de Pedido*\n\n`;
  message += `Hola ${body.customerName},\n\n`;
  message += `Tu pedido *${body.orderNumber}* ha cambiado de estado:\n\n`;
  message += `📊 *Estado:* ${statusText}\n\n`;

  // Add specific message based on status
  switch (body.status) {
    case 'preparing':
      message += `Estamos preparando tu pedido con mucho cuidado.\n\n`;
      
      // Show items and prices if available
      if (body.items && body.items.length > 0 && body.totalAmount > 0) {
        message += `📦 *Detalle del pedido:*\n`;
        body.items.forEach(item => {
          const itemTotal = item.quantity * item.price;
          message += `• ${item.quantity}x ${item.name} - ${formatCurrency(itemTotal)}\n`;
        });
        message += `\n💰 *Total:* ${formatCurrency(body.totalAmount)}\n\n`;
      }
      
      message += `Te avisaremos cuando esté listo. ⏰`;
      break;

    case 'ready':
      message += `¡Tu pedido está listo! 🎉\n\n`;
      
      if (body.totalAmount > 0) {
        message += `💰 *Total a pagar:* ${formatCurrency(body.totalAmount)}\n\n`;
      }
      
      message += `Puedes pasar a recogerlo o esperar la entrega.\n`;
      message += `¡Gracias por tu preferencia! 😊`;
      break;

    case 'delivered':
      message += `¡Tu pedido ha sido entregado! 🎉\n\n`;
      message += `Esperamos que disfrutes tus productos frescos.\n\n`;
      message += `¡Gracias por tu compra! Esperamos verte pronto. 😊`;
      break;

    case 'cancelled':
      message += `Lamentablemente tu pedido ha sido cancelado. 😔\n\n`;
      message += `Si tienes alguna pregunta, no dudes en contactarnos.\n`;
      message += `Disculpa las molestias.`;
      break;

    default:
      message += `Te mantendremos informado sobre el progreso de tu pedido.`;
  }

  return message;
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    // Initialize Supabase client
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Parse request body
    const body: RequestBody = await req.json();
    console.log('Received request to send WhatsApp status notification:', body);

    // Validate required fields
    if (!body.orderId || !body.orderNumber || !body.customerPhone || !body.status) {
      return new Response(
        JSON.stringify({ error: 'Missing required fields' }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    // Load WhatsApp configuration
    const whatsappConfig = await loadWhatsAppConfig(supabase);
    
    if (!whatsappConfig) {
      console.error('WhatsApp configuration not found');
      return new Response(
        JSON.stringify({ error: 'WhatsApp configuration not found' }),
        {
          status: 500,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    // Build message
    const message = buildStatusMessage(body);
    console.log('Sending message:', message);

    // Send WhatsApp message
    const sent = await sendWhatsAppMessage(
      body.customerPhone,
      message,
      whatsappConfig
    );

    if (sent) {
      return new Response(
        JSON.stringify({ success: true, message: 'WhatsApp notification sent' }),
        {
          status: 200,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    } else {
      return new Response(
        JSON.stringify({ error: 'Failed to send WhatsApp message' }),
        {
          status: 500,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }
  } catch (error) {
    console.error('Error processing request:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});

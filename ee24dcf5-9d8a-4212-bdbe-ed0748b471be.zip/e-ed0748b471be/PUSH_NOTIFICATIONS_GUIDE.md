
# Guía de Configuración de Notificaciones Push

Esta guía explica cómo funcionan las notificaciones push en la aplicación y cómo configurarlas correctamente.

## 📋 Tabla de Contenidos

1. [Descripción General](#descripción-general)
2. [Arquitectura](#arquitectura)
3. [Configuración](#configuración)
4. [Uso](#uso)
5. [Solución de Problemas](#solución-de-problemas)

## 🎯 Descripción General

El sistema de notificaciones push permite enviar alertas en tiempo real a los usuarios sobre:

- **Nuevos pedidos**: Cuando se crea un pedido nuevo
- **Cambios de estado**: Cuando un pedido cambia de estado (pendiente, preparando, listo, entregado, cancelado)
- **Notificaciones del sistema**: Mensajes administrativos

## 🏗️ Arquitectura

### Componentes Principales

1. **NotificationService** (`services/NotificationService.ts`)
   - Maneja el registro de tokens de dispositivos
   - Gestiona permisos de notificaciones
   - Envía notificaciones locales
   - Interactúa con la Edge Function para enviar push notifications

2. **Edge Function** (`send-push-notification`)
   - Recibe solicitudes para enviar notificaciones
   - Obtiene tokens de dispositivos desde la base de datos
   - Envía notificaciones a través de Expo Push Notification Service
   - Guarda registros de notificaciones en la base de datos

3. **Base de Datos**
   - Tabla `push_tokens`: Almacena tokens de dispositivos
   - Tabla `notifications`: Registra todas las notificaciones enviadas

### Flujo de Trabajo

```
Usuario inicia sesión
    ↓
AuthContext registra token de dispositivo
    ↓
Token guardado en tabla push_tokens
    ↓
Evento ocurre (nuevo pedido, cambio de estado)
    ↓
OrderService invoca Edge Function
    ↓
Edge Function obtiene tokens y envía notificaciones
    ↓
Notificaciones guardadas en tabla notifications
    ↓
Usuario recibe notificación push
```

## ⚙️ Configuración

### 1. Configuración de Expo

Para que las notificaciones push funcionen, necesitas configurar tu proyecto en Expo:

```bash
# Instalar EAS CLI si no lo tienes
npm install -g eas-cli

# Iniciar sesión en Expo
eas login

# Configurar el proyecto
eas build:configure
```

### 2. Variables de Entorno

La Edge Function necesita acceso a las siguientes variables de entorno (ya configuradas en Supabase):

- `SUPABASE_URL`: URL de tu proyecto Supabase
- `SUPABASE_SERVICE_ROLE_KEY`: Clave de servicio de Supabase
- `EXPO_ACCESS_TOKEN` (opcional): Token de acceso de Expo para mayor límite de notificaciones

Para configurar el token de Expo (opcional pero recomendado):

1. Ve a https://expo.dev/accounts/[tu-cuenta]/settings/access-tokens
2. Crea un nuevo token de acceso
3. Agrega el token a las variables de entorno de Supabase:

```bash
supabase secrets set EXPO_ACCESS_TOKEN=tu_token_aqui
```

### 3. Permisos de Dispositivo

#### iOS

Agrega lo siguiente a tu `app.json`:

```json
{
  "expo": {
    "ios": {
      "infoPlist": {
        "UIBackgroundModes": ["remote-notification"]
      }
    },
    "notification": {
      "icon": "./assets/notification-icon.png",
      "color": "#007BFF"
    }
  }
}
```

#### Android

Los permisos ya están configurados automáticamente por Expo.

### 4. Configuración de app.json

Asegúrate de que tu `app.json` incluya:

```json
{
  "expo": {
    "plugins": [
      [
        "expo-notifications",
        {
          "icon": "./assets/notification-icon.png",
          "color": "#007BFF",
          "sounds": ["./assets/notification-sound.wav"]
        }
      ]
    ]
  }
}
```

## 📱 Uso

### Registro Automático

El registro de notificaciones push ocurre automáticamente cuando:

1. El usuario inicia sesión
2. La aplicación se inicia con una sesión activa

El proceso es manejado por `AuthContext` y `NotificationService`.

### Envío de Notificaciones

#### Desde el Código

```typescript
import { NotificationService } from '@/services/NotificationService';

// Enviar a un usuario específico
await NotificationService.sendPushNotification(
  userId,
  'Título',
  'Mensaje',
  { orderId: '123', type: 'new_order' }
);
```

#### Desde la Edge Function

```typescript
const { data, error } = await supabase.functions.invoke('send-push-notification', {
  body: {
    userId: 'user-uuid',
    // O para múltiples usuarios:
    // userIds: ['user-uuid-1', 'user-uuid-2'],
    title: 'Nuevo pedido',
    message: 'Pedido ORD-123 de Juan Pérez',
    data: {
      type: 'new_order',
      orderId: 'order-uuid',
    },
  },
});
```

### Visualización de Notificaciones

Los usuarios pueden ver sus notificaciones en:

1. **Pantalla de Perfil**: Muestra el contador de notificaciones no leídas
2. **Pantalla de Notificaciones** (`/notifications`): Lista completa de notificaciones

### Manejo de Notificaciones

```typescript
// Marcar como leída
await NotificationService.markAsRead(notificationId);

// Marcar todas como leídas
await NotificationService.markAllAsRead();

// Eliminar notificación
await NotificationService.deleteNotification(notificationId);

// Obtener contador de no leídas
const count = await NotificationService.getUnreadCount();
```

## 🔧 Solución de Problemas

### Las notificaciones no llegan

1. **Verifica que el dispositivo sea físico**
   - Las notificaciones push NO funcionan en simuladores/emuladores
   - Usa un dispositivo físico para probar

2. **Verifica los permisos**
   ```typescript
   const { status } = await Notifications.getPermissionsAsync();
   console.log('Permission status:', status);
   ```

3. **Verifica el token**
   ```typescript
   const token = await NotificationService.registerForPushNotifications();
   console.log('Push token:', token);
   ```

4. **Verifica la base de datos**
   ```sql
   -- Ver tokens registrados
   SELECT * FROM push_tokens;
   
   -- Ver notificaciones enviadas
   SELECT * FROM notifications ORDER BY created_at DESC LIMIT 10;
   ```

### Error: "No project ID found"

Asegúrate de que tu `app.json` incluya:

```json
{
  "expo": {
    "extra": {
      "eas": {
        "projectId": "tu-project-id"
      }
    }
  }
}
```

### Las notificaciones no se muestran en primer plano

Esto es el comportamiento esperado. Por defecto, las notificaciones solo se muestran cuando la app está en segundo plano. Para mostrarlas en primer plano, el `NotificationService` ya está configurado con:

```typescript
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: true,
  }),
});
```

### Error en Edge Function

Verifica los logs de la Edge Function:

```bash
supabase functions logs send-push-notification
```

O desde el código:

```typescript
const { data, error } = await supabase.functions.invoke('send-push-notification', {
  body: { ... }
});

if (error) {
  console.error('Edge Function error:', error);
}
```

## 📊 Monitoreo

### Ver estadísticas de notificaciones

```sql
-- Notificaciones por tipo
SELECT type, COUNT(*) as count
FROM notifications
GROUP BY type;

-- Notificaciones no leídas por usuario
SELECT u.email, COUNT(*) as unread_count
FROM notifications n
JOIN profiles u ON n.user_id = u.id
WHERE n.read = false
GROUP BY u.email;

-- Tokens activos por plataforma
SELECT device_type, COUNT(*) as count
FROM push_tokens
GROUP BY device_type;
```

## 🔒 Seguridad

### Row Level Security (RLS)

Las tablas `push_tokens` y `notifications` tienen RLS habilitado:

```sql
-- Los usuarios solo pueden ver sus propios tokens
CREATE POLICY "Users can view own tokens"
  ON push_tokens FOR SELECT
  USING (auth.uid() = user_id);

-- Los usuarios solo pueden ver sus propias notificaciones
CREATE POLICY "Users can view own notifications"
  ON notifications FOR SELECT
  USING (auth.uid() = user_id);
```

### Mejores Prácticas

1. **No almacenar información sensible en el payload de notificaciones**
2. **Validar permisos antes de enviar notificaciones**
3. **Limpiar tokens antiguos periódicamente**
4. **Monitorear el uso de la API de Expo**

## 📚 Referencias

- [Expo Notifications Documentation](https://docs.expo.dev/versions/latest/sdk/notifications/)
- [Expo Push Notification Service](https://docs.expo.dev/push-notifications/overview/)
- [Supabase Edge Functions](https://supabase.com/docs/guides/functions)

## 🆘 Soporte

Si tienes problemas con las notificaciones push:

1. Revisa los logs de la aplicación
2. Verifica los logs de la Edge Function
3. Consulta la tabla de notificaciones en la base de datos
4. Asegúrate de estar usando un dispositivo físico

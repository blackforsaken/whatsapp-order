
# Guía de Configuración de Bluetooth para Android

## Problema Resuelto

El error "BluetoothManager is not available" ocurría porque:

1. **Librería antigua**: La librería `react-native-thermal-receipt-printer-image-qr` (v0.1.12) es muy antigua y no es compatible con Expo 54
2. **Falta de configuración nativa**: La librería no estaba correctamente vinculada en el build nativo
3. **Permisos insuficientes**: Faltaban configuraciones específicas de Android

## Cambios Realizados

### 1. Nueva Librería de Bluetooth
- ✅ Instalada: `react-native-bluetooth-escpos-printer` (más moderna y mantenida)
- ✅ Mejor compatibilidad con Expo 54 y React Native 0.81.4
- ✅ Soporte mejorado para impresoras ESC/POS

### 2. Configuración de app.json
- ✅ Agregado plugin `expo-build-properties`
- ✅ Configurado minSdkVersion: 23
- ✅ Configurado targetSdkVersion: 34
- ✅ Permisos de Bluetooth actualizados con formato completo

### 3. Servicio de Bluetooth Mejorado
- ✅ Mejor manejo de errores con emojis para fácil identificación
- ✅ Logs más detallados para debugging
- ✅ Verificación de disponibilidad de la librería
- ✅ Manejo robusto de conexiones

## Pasos para Probar

### Opción 1: Build de Desarrollo (Recomendado para pruebas)

```bash
# 1. Limpiar caché
npx expo start -c

# 2. Generar archivos nativos
npx expo prebuild --clean

# 3. Construir APK de desarrollo
cd android
./gradlew assembleDebug

# 4. El APK estará en: android/app/build/outputs/apk/debug/app-debug.apk
```

### Opción 2: Build con EAS (Para producción)

```bash
# 1. Instalar EAS CLI si no lo tienes
npm install -g eas-cli

# 2. Login en EAS
eas login

# 3. Configurar el proyecto
eas build:configure

# 4. Construir APK
eas build --platform android --profile preview
```

### Opción 3: Build Local con EAS

```bash
# Construir localmente (requiere Android Studio)
eas build --platform android --profile development --local
```

## Verificación de Funcionamiento

### 1. Logs de Inicio
Cuando abras la app, deberías ver en los logs:
```
✅ Bluetooth library loaded successfully
BluetoothManager available: true
BluetoothEscposPrinter available: true
```

### 2. En la Pantalla de Configuración de Impresora
- Deberías poder ver el botón "Escanear Impresoras"
- Al presionarlo, deberías ver:
  ```
  🔄 Initializing Bluetooth...
  ✅ Bluetooth initialized successfully
  🔍 Scanning for Bluetooth printers...
  ✅ Found X printer(s)
  ```

### 3. Al Conectar una Impresora
```
🔄 Connecting to printer: [Nombre] ( [Dirección] )
✅ Successfully connected to printer: [Nombre]
```

### 4. Al Imprimir
```
🖨️ Printing order: [Número de Pedido]
✅ Order printed successfully
```

## Solución de Problemas

### Si aún ves "Bluetooth library not available"

1. **Verifica que instalaste el APK correcto**
   - No uses Expo Go
   - Debe ser un build standalone (APK generado)

2. **Limpia completamente el proyecto**
   ```bash
   # Eliminar node_modules y reinstalar
   rm -rf node_modules
   npm install
   
   # Limpiar caché de Expo
   npx expo start -c
   
   # Eliminar carpeta android y regenerar
   rm -rf android
   npx expo prebuild --clean
   ```

3. **Verifica los permisos en tiempo de ejecución**
   - Android 12+ requiere permisos de ubicación para Bluetooth
   - La app debe solicitar estos permisos al usuario
   - Ve a Configuración > Aplicaciones > Tu App > Permisos
   - Asegúrate de que "Ubicación" y "Dispositivos cercanos" estén permitidos

4. **Verifica que Bluetooth esté habilitado**
   - Activa Bluetooth en tu dispositivo Android
   - Empareja la impresora manualmente primero (Configuración > Bluetooth)

### Si la impresora no aparece en el escaneo

1. **Empareja la impresora manualmente primero**
   - Ve a Configuración de Android > Bluetooth
   - Empareja tu impresora térmica
   - Luego vuelve a la app y escanea

2. **Verifica que la impresora esté encendida**
   - Asegúrate de que la impresora esté encendida y en modo de emparejamiento

3. **Verifica los permisos de ubicación**
   - Android requiere permisos de ubicación para escanear dispositivos Bluetooth
   - Otorga el permiso cuando la app lo solicite

### Si la impresión falla

1. **Verifica la conexión**
   - Asegúrate de que la impresora esté conectada (icono de Bluetooth en la app)
   - Intenta desconectar y reconectar

2. **Prueba con la impresión de prueba**
   - Usa el botón "Imprimir Prueba" en la configuración
   - Esto te ayudará a identificar si el problema es con la conexión o con el formato

3. **Revisa los logs**
   - Conecta tu dispositivo por USB
   - Ejecuta: `adb logcat | grep -i bluetooth`
   - Busca mensajes de error específicos

## Características de la Nueva Implementación

### Logs Mejorados
- ✅ Emojis para identificar rápidamente el estado
- ✅ Mensajes en español
- ✅ Información detallada de errores

### Manejo de Errores
- ✅ Verificación de disponibilidad de la librería
- ✅ Verificación de estado de Bluetooth
- ✅ Reconexión automática si se pierde la conexión
- ✅ Mensajes de error claros para el usuario

### Compatibilidad
- ✅ Android 6.0+ (API 23+)
- ✅ Soporte para Android 12+ con nuevos permisos de Bluetooth
- ✅ Compatible con impresoras ESC/POS estándar de 80mm

## Próximos Pasos

1. **Construye un nuevo APK** usando uno de los métodos anteriores
2. **Instala el APK** en tu dispositivo Android
3. **Verifica los logs** para confirmar que la librería se carga correctamente
4. **Prueba la conexión** con tu impresora Bluetooth
5. **Prueba la impresión** con un pedido de prueba

## Notas Importantes

- ⚠️ **NO uses Expo Go**: La funcionalidad de Bluetooth requiere código nativo y no funcionará en Expo Go
- ⚠️ **Permisos de ubicación**: Android requiere permisos de ubicación para escanear dispositivos Bluetooth, aunque no uses GPS
- ⚠️ **Emparejamiento previo**: Es recomendable emparejar la impresora manualmente en la configuración de Android antes de usar la app
- ⚠️ **Impresoras compatibles**: Esta implementación funciona con impresoras térmicas ESC/POS estándar de 80mm

## Soporte

Si sigues teniendo problemas después de seguir esta guía:

1. Comparte los logs completos de la app
2. Indica el modelo de tu impresora Bluetooth
3. Indica la versión de Android de tu dispositivo
4. Describe exactamente en qué paso falla
